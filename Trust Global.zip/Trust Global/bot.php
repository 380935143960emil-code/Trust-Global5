<?php

define('FastCore', true);

// Подключаем файлы с классами config
require_once 'core/config.php'; 

$botToken = '8145198582:AAEZz_eWFn58pPXl779L1n9YTiRzf3UJraE';
$channelUsername = '@luckgalaxy';

$update = json_decode(file_get_contents('php://input'), true);

// Функция отправки ошибки
function sendErrorMessage($message) {
    global $botToken, $update;
    $chatId = $update['message']['from']['id'];
    $url = "https://api.telegram.org/bot$botToken/sendMessage?chat_id=$chatId&text=" . urlencode("Ошибка: " . $message);
    file_get_contents($url);
}

// Проверка подписки
function checkSubscription($id, $botToken, $channelUsername) {
    $url = "https://api.telegram.org/bot$botToken/getChatMember?chat_id=$channelUsername&user_id=$id";
    $response = file_get_contents($url);
    if ($response === FALSE) {
        sendErrorMessage("Ошибка при обращении к API: $url");
        return false;
    }
    $response = json_decode($response, true);

    if (isset($response['result']['status']) && in_array($response['result']['status'], ['member', 'administrator', 'creator'])) {
        return true;
    } else {
        return false;
    }
}

// Обработка /start
if (isset($update['message']['text']) && strpos($update['message']['text'], "/start") === 0) {
    $command = explode(" ", $update['message']['text']);
    $startId = isset($command[1]) ? intval($command[1]) : null;

    if ($startId && $startId > 0) {
        $query = "SELECT * FROM db_bonus_tg WHERE uid = '$startId'";
        $dbQuery = $db->query($query);
        $rowCount = $dbQuery->numRows();

        if ($rowCount > 0) {
            $dbResult = $dbQuery->fetchArray();

            $message = "Здравствуйте, чтобы получить бонус, вам нужно подписаться на наш чат $channelUsername затем вернуться сюда и нажать кнопку ниже <b>Я подписался</b>";

            $keyboard = [
                'inline_keyboard' => [
                    [['text' => 'Я подписался', 'callback_data' => 'subscribe_' . $startId]]
                ]
            ];

            $userId = $update['message']['from']['id'];
            $url = "https://api.telegram.org/bot$botToken/sendMessage?chat_id=$userId&text=" . urlencode($message) . "&parse_mode=HTML&reply_markup=" . urlencode(json_encode($keyboard));
            @file_get_contents($url);
        } else {
            file_put_contents('telegram_log.txt', "Не найдена запись для UID $startId" . PHP_EOL, FILE_APPEND);
        }
    } else {
        $message = "Ошибка: Бонус можно получить только через сайт!";
        $userId = $update['message']['from']['id'];
        $url = "https://api.telegram.org/bot$botToken/sendMessage?chat_id=$userId&text=" . urlencode($message);
        @file_get_contents($url);
    }
}

// Обработка нажатия кнопки "Я подписался"
if (isset($update['callback_query']['data']) && strpos($update['callback_query']['data'], 'subscribe_') === 0) {
    $callbackData = $update['callback_query']['data'];
    $userId = $update['callback_query']['from']['id'];
    $startId = intval(str_replace('subscribe_', '', $callbackData));

    $isSubscribed = checkSubscription($userId, $botToken, $channelUsername);

    if ($isSubscribed) {
        $query = "SELECT * FROM db_bonus_tg WHERE uid = '$startId'";
        $dbResult = $db->query($query)->fetchArray();

        if ($dbResult) {
            $uid = $dbResult['uid'];

            if ($dbResult['status'] == 1) {
                $message = "Вы уже получили бонус! Спасибо за участие.";
                $url = "https://api.telegram.org/bot$botToken/sendMessage?chat_id=$userId&text=" . urlencode($message);
                @file_get_contents($url);
            } else {
                $sum = 1.00;
                $db->query("UPDATE db_users SET money_b = money_b + ? WHERE id = ?", $sum, $uid);
                $db->query("UPDATE db_bonus_tg SET status = 1 WHERE uid = ?", $uid);

                // Получаем ID пользователя
                $telegramId = $update['callback_query']['from']['id'];

                // Проверяем, существует ли уже telegram_id в базе данных
                if (empty($dbResult['telegram_id']) || $dbResult['telegram_id'] == 0) {
                    // Записываем ID пользователя Telegram
                    $db->query("UPDATE db_bonus_tg SET telegram_id = ? WHERE uid = ?", $telegramId, $uid);
                    file_put_contents('telegram_log.txt', "Записан telegram_id для UID $uid: $telegramId" . PHP_EOL, FILE_APPEND);
                }

                $message = "Спасибо за подписку! Вы получили бонус 1.00 руб.";
                $keyboard = [
                    'inline_keyboard' => [
                        [['text' => '🔙 Вернуться на сайт', 'url' => 'https://luckgalaxy.site']]
                    ]
                ];

                $url = "https://api.telegram.org/bot$botToken/sendMessage?chat_id=$userId&text=" . urlencode($message) . "&reply_markup=" . urlencode(json_encode($keyboard));
                @file_get_contents($url);
            }
        }
    } else {
        $message = "Вы не подписаны в чате. Пожалуйста, подпишитесь, чтобы получить бонус.";
        $url = "https://api.telegram.org/bot$botToken/sendMessage?chat_id=$userId&text=" . urlencode($message);
        @file_get_contents($url);
    }
}
?>
