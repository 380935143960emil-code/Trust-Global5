<?php if(!defined('FastCore')){ exit('Oops!'); }

# База данных
const dbHost = 'kn507873.mysql.tools'; // localhost
const dbUser = 'kn507873_prodaja';
const dbPass = '*5#t88pGpH';
const dbName = 'kn507873_prodaja';   

# Подключение к БД
include('classes/db.php');
$db = new db(dbHost, dbUser, dbPass, dbName);

class config {

	# Настройки сайта
	public $start_time = '1749330999';
	public $sitename = 'Trust Global'; // Название
	public $email = 'support@trustglobal.site'; // Почта
	public $telegram = '@TrustMintSupportbot'; // Почта

	# Админка 
	public $adm_dir = 'M9868dE8kfG9lpM1'; // Директория
	public $adm_name = 'M9868dE8kfG9lpM1'; // Логин
	public $adm_pass = 'M9868dE8kfG9lpM1'; // Пароль
	
	# PAYEER
	public $py_shop = '2231208445'; // ID магазина
	public $py_secret = 'tmA7D9ImmOdOm59T'; // SECRET ключ магазина
	
	public $py_NUM = 'P1121530924'; // Номер кошелька
	public $py_apiID = '1111111'; // API ID
	public $py_apiKEY = '1111111';// API KEY

	# FREEKASSA
	public $fk_id = '61725'; // ID магазина FK
	public $fk_key = '&QL*2ZDUnWF3hQa'; // SECRET 1
	public $fk_key2 = 'frnDSNe+CX^OOIA'; // SECRET 2
	
	#Azvox
	public $az_shop = '382998'; // ID Сайта из раздела Ваши сайты
	public $az_secret = 'k25HLZcZ*4b#&iH'; // Секретный ключ из раздела Ваши сайты
	
	# Автовывод Azvox
	public $az_NUM = 'W100796'; // Номер кошелька
	public $az_apiID = '120844'; // API ID
	public $az_apiKEY = 'bwZN5PZn*XBS_MB';// Пароль для доступа к API	
	 
	# ePayCore выплаты
	public $epc_api_id = '1111'; // идентификатор API
	public $epc_api_secret = '11111'; //пароль API
	public $sci_id = '104289'; // ID магазина
	public $sci_pass = 'UvaYtD1sSKRbdRy3'; // SECRET ключ магазина
	 
	 #kassify.pro
        public $sciKassifyMerchantId = '2076';
        public $sciKassifySecretKey = '4e9719d42d742368c591574520037a8c';

    	# FAUCETPAY
public $fp_username = 'sardaryan'; // Name API merchant
public $fp_api_key = 'e44234cd6493360164412d3cdcee8747681ac88809afb5e21b34746c45304e86'; // Faucet API Key 	
}

?>