<?php

class cAzvox{
	private $url = 'https://azvox.cash/api/v3.6/';
	private $agent = 'API CLIENT/3.6 (Windows NT 6.1; rv:12.0) Gecko/20100101 Firefox/12.0';

	private $authData = array();

	public $errors;

	public function __construct($account, $apiId, $apiPass){
		$arr = array(
			'account' => $account,
			'apiId' => $apiId,
			'apiPass' => $apiPass,
		);
		$this->authData = $arr;
	}

	public function doReset(){
		$this->errors = false;
	}

	public function getErrors(){
		return $this->errors;
	}

	public function isAuth(){
		if (!empty($this->authData)) return true;
		return false;
	}

	private function getResponse($arPost){
		$this->errors = false;
		if (!function_exists('curl_init')){
		   die('curl library not installed');
		   return false;
		}

		if ($this->isAuth()){
			$arPost = array_merge($arPost, $this->authData);
		}else{
			$this->errors = array($arPost["action"], "No Auth Data");
			return false;
		}

		$data = array();
		foreach ($arPost as $k => $v){
			$data[] = urlencode($k) . '=' . urlencode($v);
		}
		$data = implode('&', $data);

		$handler  = curl_init();
		
		if (!$handler){$this->errors = array("error", "curl_error", "Please check connection and try later.");return false;}
		
		curl_setopt($handler, CURLOPT_URL, $this->url);
		curl_setopt($handler, CURLOPT_HEADER, 0);

		$headers = array("");
		$headers[] = "Content-Type: application/x-www-form-urlencoded";
		curl_setopt($handler, CURLOPT_FOLLOWLOCATION, 0);

		curl_setopt($handler, CURLOPT_POST, true);
		curl_setopt($handler, CURLOPT_POSTFIELDS, $data);
		curl_setopt($handler, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($handler, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($handler, CURLOPT_USERAGENT, $this->agent);
		curl_setopt($handler, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($handler, CURLOPT_TIMEOUT, 5);

		curl_setopt($handler, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
		$content = curl_exec($handler);

		if ($content === false) {
			curl_setopt($handler, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V6);
			$content = curl_exec($handler);
		}
		
		if (curl_errno($handler) > 0){
			$this->errors = array("error", "curl_error", "cURL Error[".curl_errno($handler)."]: ".curl_error($handler));
			curl_close($handler);
			return false;
		}

		curl_close($handler);

		$content = json_decode($content, true);

		if ( ($content == "") || (!isset($content["status"])) || ($content["status"] != "ok") ){
			if (isset($content['error'])){
				if (is_array($content['error'])){
					$this->errors = array_merge(array($arPost["action"]), $content['error']);
				}else{
					$this->errors = array($arPost["action"], $content['error']);
				}
			}else{
				$this->errors = array("error", "empty_answer", "Please try later.");
			}
		}

		return $content;
	}

	public function isWalletExists($wallet){
		$this->doReset();
		$arPost = array(
			'action' => 'check_wallet',
			'wallet' => $wallet,
		);
		$response = $this->getResponse($arPost);
		if (isset($response["data"])){return ($response["data"] == "wallet_ok")?"ok":"fail";}
		return false;
	}

	public function getBalance(){
		$this->doReset();
		$arPost = array(
			'action' => 'get_balance',
		);
		$response = $this->getResponse($arPost);
		if (isset($response["data"])){return $response["data"];}
		return false;
	}

	public function getNotifications(){
		$this->doReset();
		$arPost = array(
			'action' => 'get_notifications',
		);
		$response = $this->getResponse($arPost);
		if (isset($response["data"])){return $response["data"];}
		return false;
	}

	public function transfer($to_wallet, $amount, $cur, $comment=""){
		$this->doReset();
		$arPost['action'] = 'transfer';
		$arPost['to_wallet'] = $to_wallet;
		$arPost['amount'] = $amount;
		$arPost['cur'] = $cur;
		$arPost['comment'] = $comment;
		$response = $this->getResponse($arPost);
		if (isset($response["data"])){return $response["data"];}
		return false;
	}

	public function exchange($amount, $from_cur, $to_cur){
		$this->doReset();
		$arPost['action'] = 'exchange';
		$arPost['amount'] = $amount;
		$arPost['from_cur'] = $from_cur;
		$arPost['to_cur'] = $to_cur;
		$response = $this->getResponse($arPost);
		if (isset($response["data"])){return $response["data"];}
		return false;
	}

	public function getHistoryDetails($history_operation_id){
		$this->doReset();
		$arPost['action'] = 'history_details';
		$arPost['history_operation_id'] = $history_operation_id;
		$response = $this->getResponse($arPost);
		if (isset($response["data"])){return $response["data"];}
		return false;
	}

	public function getInvoice($invoiceid){
		$this->doReset();
		$arPost['action'] = 'get_invoice';
		$arPost['invoiceid'] = $invoiceid;
		$response = $this->getResponse($arPost);
		if (isset($response["data"])){return $response["data"];}
		return false;
	}

	public function getLastHistory($count=10, $afterId=0){
		$this->doReset();
		$arPost['action'] = 'get_history';
		$arPost['count'] = $count;
		$arPost['after_id'] = $afterId;
		$response = $this->getResponse($arPost);
		if (isset($response["data"])){return $response["data"];}
		return false;
	}

	public function createInvoice($arPost){
		$this->doReset();
		$data['action'] = 'new_invoice';
		
		$data["m_shop"] = $arPost["m_shop"];
		$data["m_orderid"] = $arPost["m_orderid"];
		$data["m_amount"] = $arPost["m_amount"];
		$data["m_curr"] = $arPost["m_curr"];
		$data["m_desc"] = $arPost["m_desc"];
		$data["m_params"] = $arPost["m_params"];

		$response = $this->getResponse($data);
		if (isset($response["data"])){return $response["data"];}
		return false;
	}
}
?>