<?php if(!defined('FastCore')){echo ('Выявлена попытка взлома!');exit();}

class wallets {

    # Payeer фильтрация
    public function payeer_wallet($purse){
        if (empty($purse)) return false;
        if (substr($purse, 0, 1) != "P") return false;
        if (!preg_match("#^[0-9]{7,15}$#", substr($purse, 1))) return false;
        return $purse;
    }

    # YooMoney фильтрация
    public function yandex_wallet($purse){       
        if (empty($purse)) return false;
        if (substr($purse, 0, 1) != "4") return false;
        if (!preg_match("#^[0-9]{15,16}$#", $purse)) return false;
        return $purse;
    }

    # Azvox фильтрация
    public function azvox_wallet($purse) {
        if (empty($purse)) return false;
        if (substr($purse, 0, 1) != "W") return false;
        if (!preg_match("#^[0-9]{5,15}$#", substr($purse, 1))) return false;
        return $purse;
    }
}
?>
