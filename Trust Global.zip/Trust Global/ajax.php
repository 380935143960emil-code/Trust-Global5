<?php
header("Content-type: text/html; charset=utf-8");

ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
ini_set('error_reporting', 0);

define("FastCore", true);
define('BASE_DIR', $_SERVER['DOCUMENT_ROOT']);

$action = filter_var($_GET['action'],FILTER_SANITIZE_STRING);

$arr = ['surf' => 'surf','surfv' => 'surfv', 'task' => 'task'];

$ajax = $arr[$action];

if($ajax != NULL) {

if (strpos($action, ".") !== false) {
echo "Unknown request";
} else {

if(file_exists(BASE_DIR.'/ajax/'.$ajax.'.php')) {

session_start();

# Система
spl_autoload_register(function ($name) {
require (BASE_DIR.'/core/'.$name.'.php');
});

$config = new config;
$func = new func;

include(BASE_DIR.'/ajax/'.$ajax.'.php');

  }  else { echo 'Unknown request'; }
 }
} else { echo 'Unknown request'; }