<?php
 
define('FastCore', true);

// Подключаем файлы с классами config 
require_once 'core/config.php'; 

$botToken = '8145198582:AAEZz_eWFn58pPXl779L1n9YTiRzf3UJraE';
$channelUsername = '@luckgalaxy';
  
function checkSubscription($id, $botToken, $channelUsername) {
    $url = "https://api.telegram.org/bot$botToken/getChatMember?chat_id=$channelUsername&user_id=$id";
    $response = file_get_contents($url);
    if ($response === FALSE) {
        return null;
    }

    $response = json_decode($response, true);
    if (isset($response['result']['status'])) {
        return in_array($response['result']['status'], ['member', 'administrator']);
    }
    return false;
}
 
// Запрос к базе данных, выбираем пользователей с бонусами
$result = $db->query("SELECT * FROM `db_bonus_tg` WHERE `status` = 1");
$userData = $result->fetchAll();

// Обработка каждого пользователя
foreach ($userData as $user) {
    if (empty($user['te'])) continue;

    $userId = $user['telegram_id'];  // заменили 'tid' на 'telegram_id'
    $uid = $user['uid'];  // оставили 'uid'

    $isSubscribed = checkSubscription($userId, $botToken, $channelUsername);

    if ($isSubscribed === false) {
        // Если отписался от канала, списываем бонус
        $db->query("UPDATE `db_users` SET `money_b` = `money_b` - 2.00 WHERE `id` = ?", $uid);
        $db->query("UPDATE `db_bonus_tg` SET `status` = 2 WHERE `uid` = ?", $uid);

        $msg = "Вы отписались от чата, поэтому бонус 2.00 руб был списан.";
        $url = "https://api.telegram.org/bot$botToken/sendMessage?chat_id=$userId&text=" . urlencode($msg);
        @file_get_contents($url);
    }
}

echo "Check complete.";

file_put_contents('cron_log.txt', date('Y-m-d H:i:s') . " - запустился\n", FILE_APPEND);
?>
