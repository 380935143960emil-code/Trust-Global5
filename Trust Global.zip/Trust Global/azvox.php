<?PHP

ini_set('error_reporting', E_ALL);
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
 
# Старт сессии
session_start();

# Константа для Include
define('FastCore',true);

# Подгрузка классов
spl_autoload_register(function ($lfc) {
    require 'core/'.$lfc.'.php';
});

# Класс конфига
$config = new config;

# Функции
$func = new func;

	if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) $_SERVER['REMOTE_ADDR'] = $_SERVER['HTTP_CF_CONNECTING_IP'];

	if (isset($_POST['m_status']) && isset($_POST['m_shop']) && isset($_POST['m_orderid']) && isset($_POST['m_operation_id']) && isset($_POST['m_sign'])){
		
		$testOnly = isset($_POST["testOnly"])?true:false;
		
		$m_key = $config->az_secret;
		$m_shop = $config->az_shop;

		$arHash = array(
			$_POST['m_status'],
			$_POST['m_operation_id'],
			$_POST['m_operation_amount'],
			$_POST['m_operation_curr'],
			$_POST['m_operation_timestamp'],
			$_POST['m_wallet'],
			$_POST['m_shop'],
			$_POST['m_orderid'],
			$_POST['m_amount'],
			$_POST['m_curr'],
			$_POST['m_desc'],
			$_POST['m_params'],
			$m_key
		);

		// Генерируем подпись
		$sign_hash = strtoupper(hash('sha256', implode(':', $arHash)));

		$m_status = $_POST['m_status'];
		$m_shopid = (int)$_POST['m_shop'];
		
		// Сверяем подпись и остальные параметры
		if ($_POST['m_sign'] == $sign_hash && ($m_shopid == $m_shop) && ( ($m_status == 'success') || ($m_status == 'fail') )){
			
			if ($m_status == 'fail'){
				echo $m_orderid.'|success';// сообщаем Azvox, что запрос обработан и Azvox может больше не отправлять запросы по этому order_id
				exit;
			}

			$operation_id = $_POST['m_operation_id'];
			$operation_amount = $_POST['m_operation_amount'];
			$operation_curr = $_POST['m_operation_curr'];
			$real_pay_date = $_POST['m_operation_timestamp'];
			$m_wallet = $_POST['m_wallet'];

			$m_orderid = (int)$_POST['m_orderid'];
			$id = $m_orderid;
			$m_amount = $_POST['m_amount'];
			$m_curr = $_POST['m_curr'];
			$m_desc = $_POST['m_desc'];
			$m_params = $_POST['m_params'];
			
			$m_desc = base64_decode($m_desc);
			$m_params = json_decode(base64_decode($m_params), true);

			$num = $db->query("SELECT * FROM `db_insert` WHERE `id` = '$m_orderid'")->numRows();

			if($num == 0) {	echo $m_orderid.'|error'; exit(); }

			$data = $db->query("SELECT * FROM `db_insert` WHERE `id` = '$m_orderid'")->fetchArray();

			if($data['status'] == 1){ exit($m_orderid.'|success');}
			if($data['sum'] != $_POST['m_amount']){ exit($m_orderid.'|error');}

			$uid = $data['uid'];
			$sum = $data['sum'];
			$time = time();

			# Начисление с бонусом
			$bonx = $db->query("SELECT * FROM `db_percent` WHERE `type` = '1' ORDER BY `sum_a` BETWEEN {$sum} AND {$sum} OR {$sum} BETWEEN `sum_a` AND `sum_b`")->fetchArray();

    	    $bonus = $bonx['sum_x'];
    		$sum_x = ($sum + ($sum * $bonus));
    
    		# Формируем реферер
    		$us_data = $db->query("SELECT rid FROM db_users WHERE id = '$uid' LIMIT 1")->fetchArray();
    		$rid = $us_data["rid"];
    		$income = ($sum * 0.06);
    
    		 # Обновляем реферера
    		$db->query("UPDATE `db_users` SET `money_p` = `money_p` + '$income', `income` = `income` + '$income' WHERE `id` = '$rid'");
    		
    		 # Обновляем пользователя
    		$db->query("UPDATE `db_users` SET `sum_in` = `sum_in` + '$sum', `ref_to` = `ref_to` + '$income', `money_b` = `money_b` + '$sum_x' WHERE `id` = '$uid'");
    		
    		# Пишем в статистику
    		$db->query("UPDATE `db_insert` SET `status` = '1',  `sum_x` = '$sum_x',  `end` = '$time'  WHERE `id` = '$id'");
    		$db->query("UPDATE `db_stats` SET `inserts` = `inserts` + '$sum' WHERE `id` = '1'");
    			
			echo $m_orderid.'|success';
			exit;
		}
		echo $m_orderid.'|error';
		exit;
	}
	echo "ERROR";
	exit;
?>