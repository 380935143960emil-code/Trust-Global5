<?php
header("Content-type: text/plain; charset=utf-8");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);

if (!defined('FastCore') || FastCore !== true) { Header('Location: /404'); return; }
if (!isset($_SESSION['uid'])) { exit(); }

if (!empty($_POST['surf_id'])) {
    $surf_id = filter_var($_POST['surf_id'], FILTER_VALIDATE_INT);
    $moneySurf = round(filter_var($_POST['money'], FILTER_VALIDATE_FLOAT), 2); // Округлим сразу
    $amount = filter_var($_POST['balance'], FILTER_VALIDATE_FLOAT);

    if (empty($data)) {
        $numb = $db->query("SELECT `uid` FROM `db_surf` WHERE `id` = '$surf_id'")->numRows();
        if ($numb > 0) {
            $data_surf = $db->query("SELECT `uid`, `balance` FROM `db_surf` WHERE `id` = '$surf_id'")->fetchArray();
            $owner = $data_surf['uid'];
            if ($uid != $data_surf['uid'] && $uid != 1) {
                $data['error'] = "Ссылка вам не принадлежит!";
            }
        } else {
            $data['error'] = 'Ссылка не существует!';
        }
    }

    $user = $db->query("SELECT * FROM `db_users` WHERE `id` = '$uid'")->fetchArray();

    if ($surf_id === false) {
        $data['error'] = 'Неверные данные!';
    }
    if ($moneySurf === false || $moneySurf <= 0) {
        $data['error'] = 'Сумма не может быть 0 или отрицательной!';
        $data['id'] = 'money';
    }

    // Проверка с точностью: округляем и сравниваем
    $user_balance = round($user['money_b'], 2);
    if ($user_balance < $moneySurf) {
        $data['error'] = 'У вас недостаточно средств!';
    }

    if (!empty($data)) {
        $data['status'] = 'error';
        $data['title'] = 'Ошибка!';
        $data['redirect'] = '';
    }

    if (empty($data)) {
        // Финальное округление
        $moneySurf = round($moneySurf, 2);

        $db->query('UPDATE db_surf SET balance = balance + ? WHERE id = ?', $moneySurf, $surf_id);
        $db->query('UPDATE db_users SET money_b = money_b - ? WHERE id = ?', $moneySurf, $uid);

        $data['balance'] = number_format($data_surf['balance'] + $moneySurf, 2, '.', '');
        $data['status'] = 'success';
        $data['title'] = 'Успешно';
        $data['error'] = 'Серфинг пополнен на ' . number_format($moneySurf, 2, '.', '') . ' руб.';
        $data['redirect'] = '/user/surf/links';
    }
} else {
    $data['status'] = 'error';
    $data['title'] = 'Ошибка';
    $data['error'] = 'Ошибка данных';
    $data['redirect'] = '';
}

echo json_encode($data);
 