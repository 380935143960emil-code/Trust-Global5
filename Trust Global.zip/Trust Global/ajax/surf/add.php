<?php
header("Content-type: text/plain; charset=utf-8");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);

if (!defined('FastCore') || FastCore !== true) { Header('Location: /404'); return; }
if (!isset($_SESSION['uid'])) { exit(); }

$csrfCheck = $func->csrfVerify();
if(isset($_POST['add']) && $csrfCheck == TRUE) {

	$title = filter_var($_POST['title'], FILTER_SANITIZE_STRING);
	$url = $func->validUrl(trim($_POST['url']));
	
	$timers = filter_var($_POST['timer'], FILTER_SANITIZE_NUMBER_INT);
	$wind = filter_var($_POST['wind'], FILTER_SANITIZE_NUMBER_INT);
	$reply = filter_var($_POST['reply'], FILTER_SANITIZE_NUMBER_INT);
	$timeAdd = time();

	if ($title === FALSE) {
		$data['error'] = 'Неверно указано название!';
		$data['id'] = 'title';
	}
	if ($url === FALSE && empty($data)) {
		$data['error'] = 'Неверно указана ссылка!';
		$data['id'] = 'url';
	}
	if (iconv_strlen($title) > 65) {
		$data['error'] = 'В поле Названия можно написать только 65 символов!';
		$data['id'] = '';
	}
	if (strlen($url) > 255) {
		$data['error'] = 'В поле URL можно написать только 255 символов!';
		$data['id'] = '';
	}
	if ($timers === FALSE || $wind === FALSE || $reply === FALSE && empty($data)) {
		$data['error'] = 'Не удалось определить значение!';
		$data['id'] = '';
	}
	if (intval($wind > 1) || intval($reply > 1)) {
		$data['error'] = 'Такого значения не существует!';
		$data['id'] = '';
	}
	if (!empty($data)) {
		$data['status'] = 'error';
		$data['title'] = 'Ошибка';
		$data['redirect'] = '';
	}

	if (empty($data)) {

		$surf = $db->query('SELECT * FROM db_surf_config WHERE id = ?', array(1))->fetchArray();
	
		$timer = isset($_POST['timer']) ? (int)$_POST['timer'] : $surf['timer'];
		$timerArr = array($timer, $timer*2, $timer*3, $timer*4, $timer*5, $timer*6);

		$buyTimer = 0;
		$selTimer = $timer;

		if ($timer == 10) { $buyTimer += $surf['timer_pay']; }
		if ($timer == 20) { $buyTimer += ($surf['timer_pay'] * 2); }
		if ($timer == 30) { $buyTimer += ($surf['timer_pay'] * 3); }
		if ($timer == 40) { $buyTimer += ($surf['timer_pay'] * 4); }
		if ($timer == 50) { $buyTimer += ($surf['timer_pay'] * 5); }
		if ($timer == 60) { $buyTimer += ($surf['timer_pay'] * 6); }

		$priceTimer = number_format($buyTimer, 2, '.', ''); // Цена таймера
		$timerAd = $selTimer; // Таймер

		$priceWind = ($wind == 1) ? $surf['wind'] : 0.00;
		$period = ($reply == 1) ? 12 : 24;

		$priceAd = $surf['price_click'] + $priceTimer + $priceWind;
		$perAd = $surf['per_click'] + $priceTimer + $priceWind;

		$addSurfing = $db->query(
			"INSERT INTO db_surf (uid, title, url, timer, wind, vip, reply, price_click, per_click, date_add, status)
			VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
			$uid, $title, $url, $timerAd, $wind, 0, $period, $priceAd, $perAd, $timeAdd, '2'
		);
		$addSurfing->affectedRows();

		$data['status'] = 'success';
		$data['title'] = 'Успешно';
		$data['error'] = 'Вы успешно добавили ссылку!';
		$data['redirect'] = '/user/surf/links';
	}
} else {
	$data['status'] = 'error';
	$data['title'] = 'Ошибка';
	$data['error'] = 'Ошибка данных';
	$data['redirect'] = '';
}
echo json_encode($data);
