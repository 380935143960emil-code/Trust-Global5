<?php
header("Content-type: text/html; charset=utf-8");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);

session_start();

define('FastCore', true);
define('TIME', time());
define('BASE_DIR', $_SERVER['DOCUMENT_ROOT']);

if (!isset($_SESSION['uid'])) {
    exit('1');
}

if (isset($_POST['cnt'], $_POST['num'], $_SESSION['view']) && $_POST['cnt'] == $_SESSION['view']['cnt']) {
    $num = (int)$_POST['num'];

    if ($num) {
        $minus = TIME - $_SESSION['view']['timestart'];
        if ($minus < $_SESSION['view']['timer']) exit('2');

        // Сравнение напрямую
        if ($num == $_SESSION['view']['captcha']) {

            // Система
            spl_autoload_register(function ($lfc) {
                require_once(BASE_DIR . '/core/' . $lfc . '.php');
            });

            $config = new config;
            $func = new func;

            $time = time();
            $usid = $_SESSION['uid'];
            $user_info = $db->query('SELECT * FROM db_users WHERE id = ?', $usid)->fetchArray();
            $rid = $user_info['rid'];
            $is_vip = $user_info['is_vip'];  // Проверяем, является ли пользователь VIP

            $num_rows = $db->query("SELECT * FROM db_surf WHERE id = ? AND balance >= price_click AND status = '1' LIMIT 1", $_SESSION['view']['id'])->numRows();
            if ($num_rows > 0) {

                $num24 = $db->query('SELECT link, time_end FROM db_surf_views WHERE link = ? AND uid = ? AND time_end > ?', $_SESSION['view']['id'], $_SESSION['uid'], $time)->numRows();
                if ($num24 >= 1) exit('<div class="blockerror">Повторный просмотр пока не доступен!</div>');

                $result = $db->query("SELECT * FROM db_surf WHERE id = ? AND balance >= price_click LIMIT 1", $_SESSION['view']['id'])->fetchArray();
                $move = $result['url'];
                $id = $result['id'];

                if ($id != $_SESSION['view']['id']) exit('<div class="blockerror">ERROR!!!</div>');

                $params = $db->query('SELECT * FROM db_surf WHERE id = ? LIMIT 1', $id)->fetchArray();
                $timend = time() + 60 * 60 * $params['reply'];

                $price = number_format($result['price_click'], 2);
              
                // Если пользователь VIP, умножаем доход с серфинга в 2 раза и даем 20% с рефералов
                if ($is_vip) {
                    $payUser = number_format($result['per_click'] * 2, 2);  // x2 для серфинга
                    $payRef = number_format($payUser * 0.2, 3);  // 20% для рефералов
                } else {
                    $payUser = number_format($result['per_click'], 2);
                    $payRef = number_format($payUser * 0.0, 3);  // 10% для обычных пользователей
                }
                
                $adEarn = $price - $payUser;

                // Записываем просмотр
                $db->query("INSERT INTO db_surf_views (`link`, `time_add`, `time_end`, `uid`) VALUES (?, ?, ?, ?)", [
                    $id, $time, $timend, $_SESSION['uid']
                ]);

                // Обновляем пользователя
                $db->query('UPDATE db_users SET surf_view = surf_view + 1, money_p = money_p + ?, surf_earn = surf_earn + ? WHERE id = ?', $payUser, $payUser, $usid);

                // Обновляем реферала
                $db->query('UPDATE db_users SET money_p = money_p + ?, income = income + ?, ref_views = ref_views + 1 WHERE id = ?', $payRef, $payRef, $rid);

                // Обновляем площадку
                $db->query('UPDATE db_surf SET views = views + 1, balance = balance - ? WHERE id = ?', $price, $id);

                // Статистика
                $db->query("UPDATE db_stats SET views = views + 1 WHERE id = '1'");

                unset($_SESSION['view']);
                exit('OK;' . $payUser . ';' . $move);
            } else {
                exit('<div class="blockerror">Ошибка!<br /><span>Недостаточный баланс или площадка отключена.</span></div>');
            }

        } else {
            exit('<div class="blockerror">Ошибка!<br /><span>Неверно решена задача!</span></div>');
        }

    } else if ($num == 0) {
        $rand = rand(1000000, 9999999);
        ?>
        <div class="clocktable">
            <div class="captcha-code" nowrap="nowrap">
                <?php
                $img_array = range(1, 25);

                $selectedKeys = array_rand(array_flip($img_array), 4);
                $targetIndex = array_rand($selectedKeys);
                $targetImageKey = $selectedKeys[$targetIndex];
                $_SESSION['view']['captcha'] = $targetImageKey;
                $correctImagePath = "/assets/captcha/{$targetImageKey}.png";
                ?>
                <div class="captcha-container text-center">
                    <span>Выберите изображение:</span>
                    <div class="captcha-image">
                        <img src="<?php echo $correctImagePath; ?>" title="Captcha">
                    </div>
                </div>

                <div class="dozerchas">
                    <?php
                    foreach ($selectedKeys as $key) {
                        $imgPath = "/assets/captcha/{$key}.png";
                        ?>
                        <div class="dozercha">
                            <span class="serfnum" onclick="vernum(<?php echo $key; ?>);">
                                <img src="<?php echo $imgPath; ?>" title="<?php echo $img_array_names[$key - 1]; ?>">
                            </span>
                        </div>
                        <?php
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php
    } else {
        exit('4');
    }
} else {
    exit('5');
}
?>
