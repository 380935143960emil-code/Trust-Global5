<?php if(!defined('FastCore')){ exit('Oops!');}

/**
 * Маршрутизатор (правила маршрутизации страниц).
 */

$GLOBALS['routes'] = array (
'_404' => '404.php', // 404
'/' => 'home.php', // Главная
'/i/([0-9]+)?' => '/home.php', // Реф-ссылка
'/view/([0-9]+)?' => '/inc/view.php', // Iframe
'/viewyt/([0-9]+)?' => '/inc/viewyt.php', // Iframe youtube
'/stats' => 'stats.php', // Статистика
'/signup' => 'reg.php', // Регистрация
'/login' => 'login.php', // Регистрация
'/recovery' => 'restore.php', // Сброс пароля
'/contest' => 'contest.php', // Конкурсы
'/rules' => 'terms.php', // Правила
'/help' => 'help.php', // Поддержка
'/add-ad' => 'add-ad.php', // Добавить реклама 
'/add-468' => 'add-468.php', // Добавить реклама
'/add-200' => 'add-200.php', // Добавить реклама
'/go/([0-9]+)?' => 'go.php', // Переход по ссылке
'/go-468/([0-9]+)?' => 'go-468.php', // Переход по ссылке
'/go-200/([0-9]+)?' => 'go-468.php', // Переход по ссылке
'/reviews' => 'reviews.php', // Отзывы
'/reviews/add' => 'reviews.php', // Отзывы
'/reviews/p/([0-9]+)?' => 'reviews.php',
 '/faucet' => 'faucet.php',
'/links' => 'links.php', // Статистика

# Аккаунт
'/user/dashboard' => 'dashboard.php', // Профиль
'/user/telegram' => 'bonus_telegram.php', // Бонусы
'/user/bonus' => 'bonus.php', // Бонусы
'/bann/([0-9]+)?' => 'bann.php',
'/bannerstena' => 'bannerstena.php',
'/user/cards' => 'cards.php',
'/user/mycards' => 'mycards.php',
'/user/rewards' => 'rewards.php', // Награда Юзер
'/user/surfing' => 'surf/surf.php', // Серфинг
'/user/surf/add' => 'surf/add.php', // Серфинг добавить
'/user/surf/edit' => 'surf/edit.php', // Серфинг редактирование
'/user/surf/links' => 'surf/links.php', // Серфинг кабинет
//'/user/vsurf' => 'surfv/surf.php', // Серфинг v
//'/user/vsurf/add' => 'surfv/add.php', // Серфинг v добавить
//'/user/vsurf/edit' => 'surfv/edit.php', // Серфинг v редактирование
//'/user/vsurf/links' => 'surfv/links.php', // Серфинг v кабинет
//'/user/autoref' => 'autoref.php', // Инвест
//'/user/refbuy' => 'refbuy.php', // Инвест
'/user/hero' => 'hero.php', // Инвест
'/user/mysites' => 'mysites.php',
'/user/vip_person' => 'vip.php', // Инвест
'/user/insert' => 'insert.php', // Пополнить
'/user/insert/faucetpay' => 'insert_faucetpay.php', // Пополнить
'/user/insertts' => 'insertts.php', // Пополнить
'/user/paymentes' => 'paymentes.php', // Спобом заказа выплаты
'/user/pay' => 'pay.php', // Спобом заказа выплаты
'/user/pap' => 'pap.php', 
'/user/pap/([^/]+)' => 'pap.php',
'/user/refs' => 'referals.php', // Рефералы
'/user/mysites' => 'mysites.php', // Рефералыmysites
'/user/settings' => 'settings.php', // Настройки
'/user/success' => 'status_success.php', // Success
'/user/fail' => 'status_fail.php', // Fail
'/user/logout' => 'dashboard.php', // Выход
'/user/add-468' => 'add-468.php', // Добавить реклама
'/user/add-200' => 'add-200.php', // Добавить реклама
'/user/promocode' => 'promocode.php', // Добавить реклама
'/user/ticket' => 'ticket.php', // ticket
'/user/ticket/add' => 'ticket.php', // ticket
'/user/ticket/mess/([0-9]+)?' => 'ticket.php', // tick
'/user/ship' => 'ship.php', // FastBox
//'/user/links' => 'links.php', // Цепочка
//'/user/task' => 'task/task.php', // Задания
//'/user/task/add' => 'task/add.php', // Разместить задание 
//'/user/task/edit' => 'task/edit.php', // Редактировать задание
//'/user/task/check' => 'task/check.php', // Проверить задание
//'/user/task/my' => 'task/my.php', // Мои задания
//'/user/task/progress' => 'task/progress.php', // Выполнение
//'/user/task/process' => 'task/process.php', // В процессе выполнения
//'/user/task/done' => 'task/done.php', // Выполненные

// Вход
'/'.$adm.'' => 'login.php', // Вход

// Главная
'/'.$adm.'' => 'main.php', // Главная
'/'.$adm.'/' => 'main.php', // Главная с завершающим слешем
// Баннеры
'/'.$adm.'/admbanner' => 'admbanner.php',  
'/'.$adm.'/admbanner/edit/([0-9]+)?' => 'admbanner.php',
'/'.$adm.'/banners' => 'banners.php',  // Список баннеров
'/'.$adm.'/promocode' => 'promocode.php',  // Список баннеров
'/'.$adm.'/banners/edit/([0-9]+)?' => 'banners.php', // Редактирование баннера по ID
'/'.$adm.'/banners/([^/]+)' => 'banners.php',  // Дополнительные параметры баннера
# Админ5
'/'.$adm.'/webmone' => 'webmone.php',
'/'.$adm.'/webmoder' => 'webmoder.php',
'/'.$adm.'/webstata' => 'webstata.php',
'/'.$adm.'/websts' => 'websts.php',
'/'.$adm.'/websts/add' => 'websts.php', 
'/'.$adm.'/websts/edit/([0-9]+)?' => 'websts.php',
 '/'.$adm.'/rewards' => 'rewards.php', // Награда Админ
// Реклама
'/'.$adm.'/ad' => 'ad.php',  // Страница рекламы
'/'.$adm.'/ad/([^/]+)' => 'ad.php',  // Реклама с дополнительными параметрами
'/'.$adm.'/ad/edit/([0-9]+)?' => 'ad.php', // Редактирование рекламы по ID

// Серфинг
'/'.$adm.'/serf' => 'serf.php', // Страница серфинга
'/'.$adm.'/statistics' => 'statistics.php', // статистика
'/'.$adm.'/statistics/([0-9]+)?' => 'statistics.php', // статистика

// Управление пользователями
'/'.$adm.'/users' => 'users.php', // Управление пользователями
'/'.$adm.'/uips' => 'uips.php', // Управление IP-адресами пользователей
'/'.$adm.'/users/info/([0-9]+)?' => 'users.php', // Информация о пользователе
'/'.$adm.'/users/p/([0-9]+)?' => 'users.php', // Страница пользователей по номеру
'/'.$adm.'/multi' => 'multi.php', // Мульты
'/'.$adm.'/bonustg' => 'bonustg.php', // Тг
'/'.$adm.'/feik' => 'feik.php', // фейки

// Статистика
'/'.$adm.'/st/([^/]+)' => 'astats.php', // Статистика
'/'.$adm.'/botser' => 'botser.php',
// Настройки
'/'.$adm.'/config' => 'config.php', // Настройки админки
'/'.$adm.'/ticket_otv' => 'ticket_otv.php', // ticket
'/'.$adm.'/ticket_otv/mess/([0-9]+)?' => 'ticket_otv.php', // ticket

// Ручные выплаты
'/'.$adm.'/pays' => 'pays.php', // Ручные выплаты

// Источники трафика
'/'.$adm.'/referers' => 'referers.php', // Источники трафика    
'/'.$adm.'/referers/all' => 'referers.php', // Все источники трафика
'/'.$adm.'/task' => 'task.php', // Задания
);
?>