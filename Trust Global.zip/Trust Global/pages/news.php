<?php if(!defined('FastCore')){exit('Opss!');}
# Заголовки
$opt = array(
  'title' => 'Новости сайта',
  'keywords' => 'новости сайта, уведомления для сайта, оповещение пользователям, события',
  'description' => 'Самые свежие и актуальные новости на нашем сайте, о конкурсах и акциях, прочитай чтобы не пропустить.'
);
?>

<!-- Заголовок -->
<div class="mb-6">
  <h1 class="text-2xl font-bold text-gradient mb-2">{!TITLE!}</h1>
  <p class="text-gray-400 text-sm">Будьте в курсе последних событий и акций</p>
</div>

<?php
# Полная новость
if(isset($pg->segment[1]) && $pg->segment[1] === 'i') {
  $url_news = filter_var($pg->params[1], FILTER_SANITIZE_STRING);
  $news = $db->query('SELECT * FROM db_news WHERE url = ? LIMIT 1',array($url_news))->fetchArray();
  if(isset($news['url']) == 0) {
    echo '<div class="bubble-card p-4 mb-4 border-red-400/30">
      <div class="flex items-center gap-3 text-red-400">
        <i class="bi bi-exclamation-triangle text-xl"></i>
        <span>Новость не найдена</span>
      </div>
    </div>'; 
    return;
  }
?>

<!-- Полная новость -->
<div class="bubble-card overflow-hidden">
  <?php if (!empty($news['img'])): ?>
    <div class="h-64 overflow-hidden">
      <img src="<?=$news['img']; ?>" alt="<?=$news['title']; ?>" class="w-full h-full object-cover">
    </div>
  <?php endif; ?>
  <div class="p-6">
    <div class="flex items-center gap-2 text-gray-400 text-sm mb-4">
      <i class="bi bi-calendar text-lime-400"></i>
      <span><?=date("d.m.Y в H:i",$news['add']); ?></span>
    </div>
    <h2 class="text-2xl font-bold mb-4"><?=$news['title'];?></h2>
    <div class="text-gray-300 leading-relaxed"><?=$news['text'];?></div>
  </div>
</div>

<div class="mt-6">
  <a href="/news" class="btn-dark inline-flex items-center gap-2 px-6 py-2">
    <i class="bi bi-arrow-left"></i>
    Ко всем новостям
  </a>
</div>

<?php
  return;
} 

if(isset($uid)) {
  # Считаем непрочитаные новости
  $numnews = $db->query("SELECT id FROM db_news ORDER BY id DESC")->fetchAll();
  $nnews = count($numnews);
  $u_news = $db->query('SELECT id,news FROM db_users WHERE id = '.$uid.'')->fetchArray();
  $newsus = $u_news['news'] ?? 0;
  if($nnews > $newsus) {
    $db->query('UPDATE db_users SET news = '.$nnews.' WHERE id = '.$uid.'');
  }
}

# Текущая страница
$rows = $db->query("SELECT * FROM `db_news` WHERE `id` > 0")->numRows();

# Пагинация
$cnt = 12;
$nav ='/news';
$page = $pg->params[1] ?? 1;
$start = ($page * $cnt) - $cnt;
$str_pag = ceil($rows / $cnt);

if($rows == 0) {
  echo '<div class="bubble-card p-8 text-center">
    <div class="w-16 h-16 rounded-xl bg-lime-400/10 flex items-center justify-center mx-auto mb-4">
      <i class="bi bi-inbox text-lime-400 text-2xl"></i>
    </div>
    <h3 class="text-lg font-semibold mb-2">Новостей пока нет</h3>
    <p class="text-gray-400 text-sm">На данный момент новости не были опубликованы</p>
  </div>';
} else {
?>

<!-- Список новостей -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
<?php
  $news = $db->query('SELECT * FROM `db_news` ORDER BY `id` DESC LIMIT '.$start.','.$cnt.'')->fetchAll();
  foreach ($news as $news) { 
?>
  <a href="/news/i/<?=$news['url']; ?>" class="bubble-card overflow-hidden hover:border-lime-400/30 transition">
    <?php if (!empty($news['img'])): ?>
      <div class="h-40 overflow-hidden">
        <img src="<?=$news['img']; ?>" alt="<?=$news['title']; ?>" class="w-full h-full object-cover hover:scale-105 transition">
      </div>
    <?php endif; ?>
    <div class="p-4">
      <div class="flex items-center gap-2 text-gray-500 text-xs mb-2">
        <i class="bi bi-calendar text-lime-400"></i>
        <span><?=date("d.m.Y в H:i",$news['add']); ?></span>
      </div>
      <h3 class="font-semibold line-clamp-2"><?=$news['title']; ?></h3>
    </div>
  </a>
<?php } ?>
</div>

<?php
  # Пагинация
  if ($str_pag > 1) {
    echo '<div class="flex justify-center gap-2 mt-6">';
    for ($i = 1; $i <= $str_pag; $i++){
      if ($i == $page) {
        echo '<span class="btn-lime px-4 py-2">'.$i.'</span>';
      } else {
        echo '<a class="btn-dark px-4 py-2" href="'.$nav.'/p/'.$i.'">'.$i.'</a>';
      }
    }
    echo '</div>';
  }
}
?>
