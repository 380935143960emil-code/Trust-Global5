<?php if(!defined('FastCore')){exit('Opss!');}
# Заголовки
$opt = array(
  'title' => 'Авторизация'
);

if (isset($_SESSION['uid'])) {
  Header('Location: /user/dashboard'); return;
}
?>

<!-- Заголовок -->
<div class="mb-6 text-center">
  <h1 class="text-2xl font-bold text-gradient mb-2">{!TITLE!}</h1>
  <p class="text-gray-400 text-sm">Войдите в свой аккаунт для доступа к кабинету</p>
</div>

<?php
    # Обработка формы
    if (isset($_POST['auth'])) {
        $login = $func->FLogin($_POST['email']);
        $email = $func->FMail($_POST['email']);
        $pass = $func->FPass($_POST['pass']);

        $ipGet = $func->ipGet();
        $ip = $func->ipValid($ipGet);

        if (empty($_POST['email']) || empty($_POST['pass'])) {
            $errors[] = 'Не все поля заполнены!';
        }

        if (empty(filter_var($email, FILTER_VALIDATE_EMAIL)) && empty($login)) {
            $errors[] = 'Email или Логин заполнен неверно';
        }

        $users = $db->query('SELECT * FROM db_users WHERE email = ? OR login = ? LIMIT 1', array($email, $login))->fetchArray();

        if (!isset($users['email']) && $email) {
            $errors[] = 'Email не найден!';
        }
        if (!isset($users['login']) && $login) {
            $errors[] = 'Логин не найден!';
        }

        if (isset($users['pass'])) {
            if (strtolower($users['pass']) != strtolower($pass)) {
                $errors[] = 'Пароль не совпадает!';
            }

            if ($users['ban'] == 1) {
                $errors[] = 'Ваш аккаунт был заблокирован!';
            }
        }

        if (empty($errors)) {
            $time = time();
            $userID = $users['id'];
            $db->query('UPDATE db_users SET auth = ? WHERE id = ?', array($time, $userID));
            $db->query('UPDATE db_uips SET ip2 = ?, time = ? WHERE id = ?', array($ip, $time, $userID));
            $_SESSION['uid'] = $users['id'];
            $_SESSION['login'] = $users['login'];
            header('Location: /user/dashboard');
            return;
        } else {
            echo '<div class="bubble-card p-4 mb-4 border-red-400/30">
              <div class="flex items-center gap-3 text-red-400">
                <i class="bi bi-exclamation-triangle text-xl"></i>
                <span>' . array_shift($errors) . '</span>
              </div>
            </div>';
        }
    }
?>

<!-- Форма авторизации -->
<div class="max-w-md mx-auto">
  <div class="bubble-card p-8">
    <form method="POST" class="space-y-5">
      
      <div>
        <label class="block text-gray-400 text-sm mb-2">Email или Логин</label>
        <div class="relative">
          <i class="bi bi-person absolute left-4 top-1/2 -translate-y-1/2 text-gray-500"></i>
          <input type="text" name="email" class="input-dark w-full pl-11" placeholder="Введите email или логин" required>
        </div>
      </div>
    
      <div>
        <label class="block text-gray-400 text-sm mb-2">Пароль</label>
        <div class="relative">
          <i class="bi bi-lock absolute left-4 top-1/2 -translate-y-1/2 text-gray-500"></i>
          <input type="password" name="pass" class="input-dark w-full pl-11" placeholder="Введите пароль" required>
        </div>
      </div>
    
      <div class="flex items-center justify-between">
        <label class="flex items-center gap-2 cursor-pointer">
          <input type="checkbox" class="w-4 h-4 rounded border-lime-400/30 bg-dark-700 text-lime-400 focus:ring-lime-400">
          <span class="text-sm text-gray-400">Запомнить меня</span>
        </label>
        <a href="/recovery" class="text-sm text-lime-400 hover:text-lime-300">Забыли пароль?</a>
      </div>
    
      <button type="submit" name="auth" class="btn-lime w-full py-3 flex items-center justify-center gap-2">
        <i class="bi bi-box-arrow-in-right"></i>
        Войти в аккаунт
      </button>
    </form>
    
    <div class="mt-6 text-center">
      <p class="text-gray-400 text-sm">
        Ещё нет аккаунта? 
        <a href="/signup" class="text-lime-400 hover:text-lime-300 font-medium">Зарегистрироваться</a>
      </p>
    </div>
  </div>
  
  <!-- Преимущества -->
  <div class="grid grid-cols-3 gap-3 mt-6">
    <div class="text-center">
      <div class="w-12 h-12 rounded-xl bg-lime-400/10 flex items-center justify-center mx-auto mb-2">
        <i class="bi bi-shield-check text-lime-400 text-xl"></i>
      </div>
      <div class="text-xs text-gray-400">Безопасность</div>
    </div>
    <div class="text-center">
      <div class="w-12 h-12 rounded-xl bg-lime-400/10 flex items-center justify-center mx-auto mb-2">
        <i class="bi bi-lightning text-lime-400 text-xl"></i>
      </div>
      <div class="text-xs text-gray-400">Мгновенно</div>
    </div>
    <div class="text-center">
      <div class="w-12 h-12 rounded-xl bg-lime-400/10 flex items-center justify-center mx-auto mb-2">
        <i class="bi bi-headset text-lime-400 text-xl"></i>
      </div>
      <div class="text-xs text-gray-400">Поддержка</div>
    </div>
  </div>
</div>
