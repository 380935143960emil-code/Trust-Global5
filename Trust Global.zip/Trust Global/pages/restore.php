<?php if(!defined('FastCore')){exit('Opss!');}
# Заголовки
$opt = array(
  'title' => 'Восстановление пароля',
  'description' => 'Восстановление пароля, вспомнить пароль, сбросить пароль'
);

if(isset($_SESSION['uid'])){ Header('Location: /user/dashboard'); return; }
?>

<!-- Заголовок -->
<div class="mb-6 text-center">
  <h1 class="text-2xl font-bold text-gradient mb-2">{!TITLE!}</h1>
  <p class="text-gray-400 text-sm">Введите ваш email для восстановления пароля</p>
</div>

<?php
# Форма восстановления
if (isset($_POST['restore'])) {
    # Фильтрация
    $email = $func->FMail($_POST['email']);
    $time = time();
    $tdel = $time + 60 * 15;

    # Удаляем устаревшие записи восстановления
    $db->query("DELETE FROM db_restore WHERE date_del < ?", $time);

    # IP адрес
    $ipGet = $func->ipGet();
    $ip = $func->ipValid($ipGet);

    # Ошибка email
    if (!empty(filter_var($email, FILTER_VALIDATE_EMAIL) !== false)) {
        # Ищем пользователя
        $uml = $db->query("SELECT * FROM db_users WHERE email = ?", $email)->numRows();
        if ($uml == 1) {
            # Проверка на повторное восстановление за последние 15 минут
            $restore = $db->query("SELECT * FROM db_restore WHERE ip = ? OR email = ?", $ip, $email)->numRows();
            if ($restore == 0) {
                # Генерация нового безопасного пароля
                function generate_password($length = 12) {
                    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
                    return substr(str_shuffle(str_repeat($chars, ceil($length / strlen($chars)))), 0, $length);
                }

                $new_pass = generate_password();

                # Вносим запись в БД
                $db->query("INSERT INTO db_restore (email, ip, date_add, date_del) VALUES (?, ?, ?, ?)", $email, $ip, $time, $tdel);
                $db->query("UPDATE db_users SET pass = ? WHERE email = ?", array($new_pass, $email));

                # Отправка письма
                $mail = new send_mail;
                $mail->send($email, 'Восстановление пароля', 'Ваш новый пароль: ' . $new_pass);

                echo '<div class="bubble-card p-4 mb-4 border-lime-400/30">
                  <div class="flex items-center gap-3 text-lime-400">
                    <i class="bi bi-check-circle text-xl"></i>
                    <span>На ваш E-Mail адрес было отправлено сообщение с новым паролем.</span>
                  </div>
                </div>';
            } else {
                $errors[] = 'Восстановление пароля с этого IP уже производилось за последние 15 минут!';
            }
        } else {
            $errors[] = 'Пользователь с таким email не найден!';
        }
    } else {
        $errors[] = 'Ошибка заполнения email!';
    }

    # Вывод ошибок
    if (!empty($errors)) {
        echo '<div class="bubble-card p-4 mb-4 border-red-400/30">
          <div class="flex items-center gap-3 text-red-400">
            <i class="bi bi-exclamation-triangle text-xl"></i>
            <span>' . array_shift($errors) . '</span>
          </div>
        </div>';
    }
}
?>

<!-- Форма восстановления -->
<div class="max-w-md mx-auto">
  <div class="bubble-card p-8">
    <form method="POST" class="space-y-5">
      <div>
        <label class="block text-gray-400 text-sm mb-2">Email</label>
        <div class="relative">
          <i class="bi bi-envelope absolute left-4 top-1/2 -translate-y-1/2 text-gray-500"></i>
          <input type="email" name="email" class="input-dark w-full pl-11" placeholder="your@email.com" required>
        </div>
      </div>
       
      <button type="submit" name="restore" class="btn-lime w-full py-3 flex items-center justify-center gap-2">
        <i class="bi bi-key"></i>
        Сбросить пароль
      </button>
    </form>
    
    <div class="mt-6 text-center">
      <p class="text-gray-400 text-sm">
        Вспомнили пароль? 
        <a href="/login" class="text-lime-400 hover:text-lime-300 font-medium">Войти</a>
      </p>
    </div>
  </div>
</div>
