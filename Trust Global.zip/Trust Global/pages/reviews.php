<?php if(!defined('FastCore')){exit('Opss!');}

$opt = array(
    'title' => 'Отзывы о проекте',
    'keywords' => 'отзывы сайта, рекомендация пользователей, оценка сайта, отзывы пользователей',
    'description' => 'Читайте отзывы наших пользователей, или оставьте свой отзыв и оценку для сайта.'
);
?>

<!-- Заголовок -->
<div class="mb-6">
  <h1 class="text-2xl font-bold text-gradient mb-2">{!TITLE!}</h1>
  <p class="text-gray-400 text-sm">Читайте отзывы пользователей и оставляйте свои</p>
</div>

<!-- Информация -->
<div class="bubble-card p-4 mb-6">
  <div class="flex items-center gap-3 text-gray-400">
    <i class="bi bi-info-circle text-lime-400"></i>
    <span>Читайте отзывы или оставьте свой отзыв о нашем проекте!</span>
  </div>
</div>

<?php 
$rows = $db->query("SELECT * FROM `db_reviews` WHERE `id` > 0")->numRows();

$cnt = 30;
$nav ='/reviews';
$page = $pg->params[1] ?? 1;
$start = ((int)$page * $cnt) - $cnt;
$str_pag = ceil($rows / $cnt);

if($rows == 0) {
    echo '<div class="bubble-card p-4 mb-6 border-yellow-400/30">
      <div class="flex items-center gap-3 text-yellow-400">
        <i class="bi bi-info-circle text-xl"></i>
        <span>Отзывы еще никто не оставлял, можете оставить свой отзыв!</span>
      </div>
    </div>';
} else {
$reviews = $db->query('SELECT * FROM `db_reviews` ORDER BY `id` DESC LIMIT '.$start.','.$cnt.'')->fetchAll();
foreach ($reviews as $ur) {
    $us = $db->query('SELECT avatar FROM db_users WHERE id = "'.$ur['uid'].'"')->fetchArray();
?>
    <div class="bubble-card p-5 mb-4">
        <div class="flex justify-between items-start mb-3">
            <div class="flex items-center gap-3">
                <img src="/avatars/<?= !empty($us['avatar']) ? htmlspecialchars($us['avatar']) : '4.png' ?>" 
                     class="w-10 h-10 rounded-full border border-lime-400/30" alt="Avatar">
                <div>
                    <div class="font-semibold"><?=$ur['login']; ?></div>
                    <div class="text-xs text-gray-400"><?=date("d.m.Y в H:i", $ur['date']); ?></div>
                </div>
            </div>
        </div>
        <p class="text-gray-300 mb-3"><?=$ur['text']; ?></p>
        <?php if (!empty($ur['img'])): ?>
            <img src="/img/reviews/<?=$ur['img']; ?>" alt="Скриншот" class="max-h-64 rounded-xl border border-lime-400/20">
        <?php endif; ?>
    </div>
<?php
    }

    if ($rows > $cnt) {
        echo '<div class="flex justify-center gap-2 mt-6">';
        for ($i = 1; $i <= $str_pag; $i++){
            echo '<a class="btn-dark px-4 py-2" href="'.$nav.'/p/'.$i.'">'.$i.'</a>';
        }
        echo '</div>';
    }
}

$limit = $db->query("SELECT * FROM db_reviews WHERE uid = '$uid'")->numRows();
$comm = $db->query("SELECT * FROM db_users WHERE id = '$uid'")->fetchArray();
$invest = $comm['sum_in'] ?? '0';
$login = $comm['login'] ?? 'Guest';

if(isset($_POST['review'])) {
    $date = time();
    $text = filter_var($_POST['content'], FILTER_SANITIZE_STRING);
    $filename = "";

    if($limit >= 100) {
        $err[]='Вы уже оставляли отзыв!';
    } elseif (!isset($_SESSION["login"])) {
        $err[]='Необходимо авторизоваться!';
    } elseif($invest <= 29.99) {
        $err[]='Отзыв могут оставлять только активные пользователи, пополнившие баланс на сумму от 30 руб!';
    } elseif(mb_strlen($text) < 20 or mb_strlen($text) > 1000) {
        $err[]='Отзыв должен быть от 20 до 1000 символов.';
    } else {
        if (isset($_FILES['screenshot']) && $_FILES['screenshot']['error'] == 0) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif'];
            $ext = strtolower(pathinfo($_FILES['screenshot']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, $allowed)) {
                $filename = uniqid('screenshot_') . '.' . $ext;
                move_uploaded_file($_FILES['screenshot']['tmp_name'], 'img/reviews/' . $filename);
            } else {
                $err[] = 'Неверный формат изображения!';
            }
        }

        if (empty($err)) {
            $db->query('INSERT INTO db_reviews (login, uid, text, `date`, img) VALUES (?, ?, ?, ?, ?)', array($login, $uid, $text, $date, $filename));
            echo '<div class="bubble-card p-4 mb-4 border-lime-400/30">
              <div class="flex items-center gap-3 text-lime-400">
                <i class="bi bi-check-circle text-xl"></i>
                <span>Ваш отзыв добавлен!</span>
              </div>
            </div>';
            header('Refresh: 1;'); return;
        }
    }
}

if (!empty($err)) {
    echo '<div class="bubble-card p-4 mb-4 border-red-400/30">
      <div class="flex items-center gap-3 text-red-400">
        <i class="bi bi-exclamation-triangle text-xl"></i>
        <span>'.array_shift($err).'</span>
      </div>
    </div>';
}
?>

<?php if (isset($_SESSION["login"]) && $limit < 1000): ?>
    <div class="bubble-card p-6 mt-6">
        <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
            <i class="bi bi-pencil-square text-lime-400"></i>
            Оставьте свой отзыв
        </h3>
        <p class="text-gray-400 text-sm mb-4">Ваше мнение помогает сделать проект лучше.</p>

        <form method="POST" action="" enctype="multipart/form-data" class="space-y-4">
            <div>
                <label class="block text-gray-400 text-sm mb-2">Ваш отзыв:</label>
                <textarea name="content" rows="5" minlength="20" maxlength="1000" required
                    class="input-dark w-full resize-none" placeholder="От 20 до 1000 символов"></textarea>
            </div>

            <div>
                <label class="block text-gray-400 text-sm mb-2">Загрузить скриншот</label>
                <input type="file" name="screenshot" accept="image/*"
                    class="block w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-lime-400 file:text-dark-900 hover:file:bg-lime-500 bg-dark-700 border border-lime-400/20 rounded-xl cursor-pointer transition">
                <p class="mt-1 text-xs text-gray-500">Поддерживаются форматы: JPG, PNG, GIF. Макс. размер: 5MB.</p>
            </div>

            <button type="submit" name="review" class="btn-lime w-full py-3 flex items-center justify-center gap-2">
                <i class="bi bi-send"></i>
                Отправить отзыв
            </button>
        </form>
    </div>
<?php endif; ?>
