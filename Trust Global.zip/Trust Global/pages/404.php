<?php if(!defined('FastCore')){exit('Opss!');}
# Заголовки
$opt = array(
  'title' => 'Страница не найдена'
);
?>

<!-- 404 -->
<div class="min-h-[60vh] flex flex-col items-center justify-center">
  <div class="text-center">
    <div class="relative mb-8">
      <div class="absolute -inset-8 bg-lime-400/10 rounded-full blur-3xl"></div>
      <h1 class="relative text-8xl font-bold text-gradient">
        404
      </h1>
    </div>
    
    <h2 class="text-2xl font-semibold mb-4">Страница не найдена</h2>
    <p class="text-gray-400 mb-8 max-w-md mx-auto">
      Запрашиваемая страница не существует или была удалена. Проверьте правильность адреса или вернитесь на главную.
    </p>
    
    <a href="/" class="btn-lime inline-flex items-center gap-2 px-8 py-3">
      <i class="bi bi-house-door"></i>
      На главную
    </a>
  </div>
</div>
