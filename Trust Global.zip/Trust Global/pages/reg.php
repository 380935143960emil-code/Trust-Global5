<?php if(!defined('FastCore')){exit('Opss!');}
# Заголовки
$opt = array(
  'title' => 'Регистрация',
  'description' => 'Регистрируйся и получи доступ к заработку и рекламным возможностям.'
);

if (isset($_SESSION['uid'])) {
  Header('Location: /user/dashboard'); return;
}
?>

<!-- Заголовок -->
<div class="mb-6 text-center">
  <h1 class="text-2xl font-bold text-gradient mb-2">{!TITLE!}</h1>
  <p class="text-gray-400 text-sm">Создайте аккаунт и начните зарабатывать уже сегодня</p>
</div>

<?php
$time = time();

// Удаляем записи, где время истекло и статус равен 1
$db->query("DELETE FROM `db_autoref` WHERE ? >= `date_end` AND `status` = '1'", [$time]);

// Получаем только активные записи
$leaders = $db->query("SELECT * FROM `db_autoref` WHERE `status` = '1' AND `date_end` > ?", [$time])->fetchAll();

if (!empty($leaders)) {
    $row_leader = $db->query("SELECT * FROM `db_autoref` WHERE `status` = 1 ORDER BY RAND() LIMIT 1")->fetchArray();
} else {
    $row_leader = [
        'uid' => 1,
        'login' => 'Admin'
    ];
}

// Обработка формы регистрации
$checked = '';

if (isset($_POST['reg'])) {
    $login = $func->FLogin($_POST["login"]);
    $email = $func->FMail($_POST["email"]);
    $pass = $func->FPass($_POST["pass"]);
    $time = time();

    $errors = [];

    // Проверка согласия с правилами
    if (empty($_POST['agree'])) {
        $errors[] = 'Вы должны согласиться с правилами сайта';
    } else {
        $checked = 'checked';
    }

    // Источник перехода
    $site = '';
    if (!empty($_COOKIE['rsite'])) {
        $host = parse_url($_COOKIE['rsite']);
        $site = $host['host'] ?? '';
    }

    // Валидация данных
    if (empty($login)) $errors[] = 'Введите логин';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Некорректный email';
    $blocked_domains = ['lists.ru', 'bsk.ru', 'ind.ru'];
    $email_domain = strtolower(substr(strrchr($email, "@"), 1));

    if (in_array($email_domain, $blocked_domains)) {
        $errors[] = 'Регистрация с доменом почты '.$email_domain.' запрещена!';
    }

    if (empty($pass)) $errors[] = 'Введите пароль';

    // Проверка уникальности
    $users = $db->query('SELECT * FROM db_users WHERE login = ? OR email = ?', [$login, $email])->fetchArray();
    if (!empty($users['login']) && $users['login'] == $login) $errors[] = 'Такой логин уже используется';
    if (!empty($users['email']) && $users['email'] == $email) $errors[] = 'Такой email уже зарегистрирован';

    // IP адрес
    $ipGet = $func->ipGet();
    $ip = $func->ipValid($ipGet);

    // Проверка IP
    $ipUser = $db->query('SELECT * FROM db_uips WHERE ip = ?',array($ip))->fetchArray();

    // Если ошибок нет, продолжаем регистрацию
    if (empty($errors)) {
        // Определяем, кто пригласил
        $rid = (isset($_COOKIE["i"]) && $_COOKIE["i"] != 1) ? intval($_COOKIE["i"]) : $row_leader['uid'];
        $referer = $rid == 0 ? 0 : $db->query('SELECT login FROM db_users WHERE id = ? LIMIT 1', [$rid])->fetchArray();

        if ($referer == null) {
            $rid = $row_leader['uid'];
            $referer = ['login' => $row_leader['login']];
        }

        # Создаем пользователя
        $db->query('INSERT INTO db_users (login, email, pass, reg, rid, referer, refsite) VALUES (?,?,?,?,?,?,?)', array($login, $email, $pass, $time, $rid, $referer['login'], $site));
        $lid = $db->LastInsert(); 

        // Сохраняем IP
        $db->query('INSERT INTO db_uips (id, uid, ip, time) VALUES (?, ?, ?, ?)', [$lid, $lid, $ip, $time]);

        // Обновляем статистику и количество рефералов
        $db->query('UPDATE db_users SET refs = refs + 1, money_b = money_b + 0 WHERE id = ?', [$rid]);

        if ($lid) {
            $db->query("UPDATE `db_stats` SET `users` = `users` + 1 WHERE `id` = '1'");
        }

        // Сообщение об успешной регистрации
        echo '<div class="bubble-card p-4 mb-4 border-lime-400/30">
          <div class="flex items-center gap-3 text-lime-400">
            <i class="bi bi-check-circle text-xl"></i>
            <span>Регистрация прошла успешно! Теперь вы можете <a href="/login" class="underline">войти</a> в аккаунт.</span>
          </div>
        </div>';

        return;

    } else {
        // Отображение первой ошибки
        echo '<div class="bubble-card p-4 mb-4 border-red-400/30">
          <div class="flex items-center gap-3 text-red-400">
            <i class="bi bi-exclamation-triangle text-xl"></i>
            <span>' . array_shift($errors) . '</span>
          </div>
        </div>';
    }
}
?>

<!-- Форма регистрации -->
<div class="max-w-md mx-auto">
  <div class="bubble-card p-8">
    <form method="POST" class="space-y-5">
      
      <div>
        <label class="block text-gray-400 text-sm mb-2">Логин</label>
        <div class="relative">
          <i class="bi bi-person absolute left-4 top-1/2 -translate-y-1/2 text-gray-500"></i>
          <input type="text" name="login" class="input-dark w-full pl-11" placeholder="Придумайте логин" required>
        </div>
      </div>
    
      <div>
        <label class="block text-gray-400 text-sm mb-2">Email</label>
        <div class="relative">
          <i class="bi bi-envelope absolute left-4 top-1/2 -translate-y-1/2 text-gray-500"></i>
          <input type="email" name="email" class="input-dark w-full pl-11" placeholder="your@email.com" required>
        </div>
      </div>
    
      <div>
        <label class="block text-gray-400 text-sm mb-2">Пароль</label>
        <div class="relative">
          <i class="bi bi-lock absolute left-4 top-1/2 -translate-y-1/2 text-gray-500"></i>
          <input type="password" name="pass" class="input-dark w-full pl-11" placeholder="Придумайте пароль" required>
        </div>
      </div>

      <!-- Согласие с правилами -->
      <div class="flex items-start gap-3">
        <input type="checkbox" name="agree" id="agree" class="w-5 h-5 rounded border-lime-400/30 bg-dark-700 text-lime-400 focus:ring-lime-400 mt-0.5" <?= $checked ?>>
        <label for="agree" class="text-sm text-gray-400">
          Я прочитал(а) и согласен(на) с 
          <a href="/rules" target="_blank" class="text-lime-400 hover:text-lime-300 underline">правилами сайта</a>
        </label>
      </div>
    
      <button type="submit" name="reg" class="btn-lime w-full py-3 flex items-center justify-center gap-2">
        <i class="bi bi-person-plus"></i>
        Зарегистрироваться
      </button>
    </form>
    
    <div class="mt-6 text-center">
      <p class="text-gray-400 text-sm">
        Уже есть аккаунт? 
        <a href="/login" class="text-lime-400 hover:text-lime-300 font-medium">Войти</a>
      </p>
    </div>
  </div>
  
  <!-- Преимущества -->
  <div class="grid grid-cols-3 gap-3 mt-6">
    <div class="text-center">
      <div class="w-12 h-12 rounded-xl bg-lime-400/10 flex items-center justify-center mx-auto mb-2">
        <i class="bi bi-cash-coin text-lime-400 text-xl"></i>
      </div>
      <div class="text-xs text-gray-400">Доходность<br>до 155%</div>
    </div>
    <div class="text-center">
      <div class="w-12 h-12 rounded-xl bg-lime-400/10 flex items-center justify-center mx-auto mb-2">
        <i class="bi bi-lightning text-lime-400 text-xl"></i>
      </div>
      <div class="text-xs text-gray-400">Мгновенные<br>выплаты</div>
    </div>
    <div class="text-center">
      <div class="w-12 h-12 rounded-xl bg-lime-400/10 flex items-center justify-center mx-auto mb-2">
        <i class="bi bi-gift text-lime-400 text-xl"></i>
      </div>
      <div class="text-xs text-gray-400">Бонусы<br>каждый день</div>
    </div>
  </div>
</div>
