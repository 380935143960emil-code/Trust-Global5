<?php if(!defined('FastCore')){exit('Opss!');}
# Заголовки
$opt = array(
  'title' => 'Поддержка',
  'description' => 'Контакты для решения вопросов, а также для сотрудничества и рекламы.'
);
?>

<!-- Заголовок -->
<div class="mb-6">
  <h1 class="text-2xl font-bold text-gradient mb-2">{!TITLE!}</h1>
  <p class="text-gray-400 text-sm">Свяжитесь с нами для решения любых вопросов</p>
</div>

<!-- Описание -->
<div class="bubble-card p-6 mb-6">
  <p class="text-gray-400 text-center">
    Если у вас возникли вопросы или предложения по сотрудничеству — свяжитесь с нами. 
    Указывайте ваш логин на сайте для более быстрой обработки запроса.
  </p>
</div>

<!-- Контакты -->
<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
  <div class="bubble-card p-6">
    <div class="flex items-center gap-4 mb-4">
      <div class="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center">
        <i class="bi bi-envelope text-blue-400 text-xl"></i>
      </div>
      <div>
        <div class="text-sm text-gray-400">Email для связи</div>
        <div class="text-lg font-semibold"><?=$config->email;?></div>
      </div>
    </div>
    <a href="mailto:<?=$config->email;?>" class="btn-dark w-full py-2 text-center block">
      <i class="bi bi-send mr-2"></i>
      Написать письмо
    </a>
  </div>
  
  <div class="bubble-card p-6">
    <div class="flex items-center gap-4 mb-4">
      <div class="w-12 h-12 rounded-xl bg-blue-400/10 flex items-center justify-center">
        <i class="bi bi-telegram text-blue-400 text-xl"></i>
      </div>
      <div>
        <div class="text-sm text-gray-400">Telegram для связи</div>
        <div class="text-lg font-semibold"><?=$config->telegram;?></div>
      </div>
    </div>
    <a href="https://t.me/<?=str_replace('@', '', $config->telegram);?>" target="_blank" class="btn-lime w-full py-2 text-center block">
      <i class="bi bi-telegram mr-2"></i>
      Написать в Telegram
    </a>
  </div>
</div>
