<?php if(!defined('FastCore')){exit('Opss!');}
# Заголовки
$opt = array(
  'title' => 'Инвестиционная платформа'
);

# Статистика
$stats = $db->query("SELECT * FROM db_stats WHERE id = '1'")->fetchArray();

# Количество 24 часа
$times = time() - 60*60*24;
$users_rows = $db->query("SELECT reg FROM `db_users` WHERE `reg` > '$times'")->numRows();
$users24 = $users_rows;

# Вставляем в куки ID пригласителя /i/123
if (isset($pg->params[1])) {
  $rid = (intval($pg->params[1]) > 0) ? intval($pg->params[1]) : 1;
  setcookie('i',$rid,time()+(60*60*24*14), '/'); 
  header('Location: /'); return;
} 
?>

<!-- Hero Section -->
<div class="bubble-card p-6 md:p-8 mb-4 relative overflow-hidden">
  <div class="absolute inset-0 bg-gradient-to-br from-lime-400/5 via-transparent to-lime-600/5"></div>
  <div class="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-lime-400/30 to-transparent"></div>
  
  <div class="relative">
    <div class="flex flex-col md:flex-row items-center gap-6">
      <div class="flex-1 text-center md:text-left">
        <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-lime-400/10 border border-lime-400/20 mb-4">
          <span class="w-2 h-2 rounded-full bg-lime-400 animate-pulse"></span>
          <span class="text-xs text-lime-400 font-medium">Надёжная инвестиционная платформа</span>
        </div>
        
        <h1 class="text-3xl md:text-4xl font-bold mb-3">
          <span class="text-gradient">Trust Global</span><br>
          <span class="text-white">Прозрачно и надёжно</span>
        </h1>
        
        <p class="text-gray-400 text-sm mb-6 max-w-lg">
          Профессиональные инвестиционные инструменты с автоматической оптимизацией дохода. Начните строить свой портфель уже сегодня.
        </p>
        
        <div class="flex flex-col sm:flex-row gap-3 justify-center md:justify-start">
          <?php if (!isset($_SESSION['uid'])): ?>
            <a href="/signup" class="btn-lime px-6 py-3 text-center text-sm">
              <i class="bi bi-rocket mr-2"></i>
              Начать зарабатывать
            </a>
            <a href="/login" class="btn-dark px-6 py-3 text-center text-sm">
              <i class="bi bi-box-arrow-in-right mr-2"></i>
              Войти в аккаунт
            </a>
          <?php else: ?>
            <a href="/user/dashboard" class="btn-lime px-6 py-3 text-center text-sm">
              <i class="bi bi-grid mr-2"></i>
              Мой кабинет
            </a>
          <?php endif; ?>
        </div>
      </div>
      
      <div class="w-full md:w-[280px]">
        <div class="relative">
          <div class="absolute -inset-4 bg-lime-400/10 rounded-full blur-3xl"></div>
          <img src="img/9988.png" alt="Promo" class="relative w-full h-auto rounded-xl">
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Статистика -->
<div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
  <div class="stat-card text-center p-4">
    <div class="text-2xl font-bold text-lime-400 mb-1"><?= number_format(round($stats['users'], 2), 0, '.', ' ') ?></div>
    <div class="text-xs text-gray-400">Активных инвестора</div>
    <div class="text-[10px] text-lime-400/60 mt-1"><i class="bi bi-arrow-up-short"></i> +12%</div>
  </div>
  <div class="stat-card text-center p-4">
    <div class="text-2xl font-bold text-lime-400 mb-1"><?= number_format(round($stats['inserts'], 2), 0, '.', ' ') ?></div>
    <div class="text-xs text-gray-400">Всего инвестировано</div>
    <div class="text-[10px] text-lime-400/60 mt-1">USD</div>
  </div>
  <div class="stat-card text-center p-4">
    <div class="text-2xl font-bold text-lime-400 mb-1"><?= number_format(round($stats['payments'], 2), 0, '.', ' ') ?></div>
    <div class="text-xs text-gray-400">Всего выплачено</div>
    <div class="text-[10px] text-lime-400/60 mt-1">USD</div>
  </div>
  <div class="stat-card text-center p-4">
    <div class="text-2xl font-bold text-lime-400 mb-1"><?= num2word($prworks)+2; ?></div>
    <div class="text-xs text-gray-400">Дней работы</div>
    <div class="text-[10px] text-lime-400/60 mt-1">дней</div>
  </div>
</div>

<!-- How It Works -->
<div class="bubble-card p-5 mb-4">
  <h2 class="text-xl font-bold text-center mb-1">Как это работает</h2>
  <p class="text-gray-400 text-sm text-center mb-5">Три простых шага для начала вашего инвестиционного пути</p>
  
  <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
    <div class="text-center p-4 rounded-xl bg-dark-700/30 relative">
      <div class="absolute top-2 right-2 text-4xl font-bold text-lime-400/10">01</div>
      <div class="w-12 h-12 rounded-xl bg-lime-400/10 flex items-center justify-center mx-auto mb-3">
        <i class="bi bi-cart-check text-lime-400 text-lg"></i>
      </div>
      <h3 class="text-base font-semibold mb-1">Выберите карту</h3>
      <p class="text-gray-400 text-xs">Выбирайте из наших инвестиционных карт с различной доходностью</p>
    </div>
    
    <div class="text-center p-4 rounded-xl bg-dark-700/30 relative">
      <div class="absolute top-2 right-2 text-4xl font-bold text-lime-400/10">02</div>
      <div class="w-12 h-12 rounded-xl bg-lime-400/10 flex items-center justify-center mx-auto mb-3">
        <i class="bi bi-graph-up-arrow text-lime-400 text-lg"></i>
      </div>
      <h3 class="text-base font-semibold mb-1">Получайте доход</h3>
      <p class="text-gray-400 text-xs">Наша система работает 24/7 для оптимизации ваших инвестиций</p>
    </div>
    
    <div class="text-center p-4 rounded-xl bg-dark-700/30 relative">
      <div class="absolute top-2 right-2 text-4xl font-bold text-lime-400/10">03</div>
      <div class="w-12 h-12 rounded-xl bg-lime-400/10 flex items-center justify-center mx-auto mb-3">
        <i class="bi bi-cash-stack text-lime-400 text-lg"></i>
      </div>
      <h3 class="text-base font-semibold mb-1">Выводите средства</h3>
      <p class="text-gray-400 text-xs">Мгновенный вывод без скрытых комиссий, когда вам удобно</p>
    </div>
  </div>
</div>

<!-- Преимущества -->
<div class="bubble-card p-6 mb-4">
  <div class="flex flex-col md:flex-row items-center gap-6">
    <div class="flex-1">
      <h2 class="text-xl font-bold mb-3">Профессиональные инвестиционные решения</h2>
      <p class="text-gray-400 text-sm mb-4">
        Trust Global предоставляет институциональные инвестиционные инструменты для частных инвесторов. Наша платформа объединяет передовые алгоритмы с безопасным управлением инвестициями.
      </p>
      
      <div class="flex flex-wrap gap-3 mb-4">
        <div class="flex items-center gap-2 px-3 py-2 rounded-lg bg-dark-700/50">
          <span class="text-lime-400 font-bold text-sm">155%</span>
          <span class="text-xs text-gray-400">Макс. доходность</span>
        </div>
        <div class="flex items-center gap-2 px-3 py-2 rounded-lg bg-dark-700/50">
          <span class="text-lime-400 font-bold text-sm">1</span>
          <span class="text-xs text-gray-400">Уровня рефералов</span>
        </div>
        <div class="flex items-center gap-2 px-3 py-2 rounded-lg bg-dark-700/50">
          <span class="text-lime-400 font-bold text-sm">24/7</span>
          <span class="text-xs text-gray-400">Поддержка</span>
        </div>
      </div>
      
      <a href="/signup" class="btn-lime inline-flex items-center gap-2 px-5 py-2.5 text-sm">
        <i class="bi bi-shield-check"></i>
        Начать инвестировать
      </a>
    </div>
    
    <div class="w-full md:w-[240px]">
      <div class="bubble-card p-5 text-center">
        <div class="w-14 h-14 rounded-xl bg-lime-400/10 flex items-center justify-center mx-auto mb-3">
          <i class="bi bi-shield-fill-check text-lime-400 text-2xl"></i>
        </div>
        <h3 class="text-base font-semibold mb-1">Защищено</h3>
        <p class="text-gray-400 text-xs">Все транзакции защищены современными протоколами</p>
      </div>
    </div>
  </div>
</div>

<!-- Инвестиционные планы -->
<div class="bubble-card p-5 mb-4">
  <h2 class="text-xl font-bold text-center mb-1">Инвестиционные планы</h2>
  <p class="text-gray-400 text-sm text-center mb-5">Выберите оптимальную инвестиционную карту</p>
  
  <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
    <!-- План 1 -->
    <div class="bubble-card p-5 relative overflow-hidden">
      <div class="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-lime-400/50 to-lime-600/50"></div>
      <div class="flex items-center justify-between mb-3">
        <div>
          <div class="text-xs text-gray-400">START</div>
          <div class="text-lg font-bold">3%</div>
        </div>
        <div class="w-10 h-10 rounded-lg bg-lime-400/10 flex items-center justify-center">
          <i class="bi bi-hexagon text-lime-400"></i>
        </div>
      </div>
      <div class="text-3xl font-bold text-lime-400 mb-1">$5</div>
      <div class="text-xs text-gray-400 mb-4">Минимальная инвестиция</div>
      
      <div class="space-y-2 mb-4 text-sm">
        <div class="flex justify-between">
          <span class="text-gray-400 text-xs">Доходность:</span>
          <span class="text-lime-400 font-semibold text-sm">+130%</span>
        </div>
        <div class="flex justify-between">
          <span class="text-gray-400 text-xs">Ежедневно:</span>
          <span class="text-white text-sm">+0.15 $</span>
        </div>
        <div class="flex justify-between">
          <span class="text-gray-400 text-xs">Лимит:</span>
          <span class="text-white text-sm">6.50 $</span>
        </div>
      </div>
      
      <?php if (isset($_SESSION['uid'])): ?>
        <a href="/user/galaxy" class="btn-lime w-full py-2.5 text-center block text-sm">Инвестировать</a>
      <?php else: ?>
        <a href="/signup" class="btn-dark w-full py-2.5 text-center block text-sm">Начать</a>
      <?php endif; ?>
    </div>
    
    <!-- План 2 -->
    <div class="bubble-card p-5 relative overflow-hidden border-lime-400/30">
      <div class="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-lime-400 to-lime-600"></div>
      <div class="absolute top-3 right-3">
        <span class="badge-vip text-[10px]">POPULAR</span>
      </div>
      <div class="flex items-center justify-between mb-3">
        <div>
          <div class="text-xs text-gray-400">SILVER</div>
          <div class="text-lg font-bold">3%</div>
        </div>
        <div class="w-10 h-10 rounded-lg bg-lime-400/10 flex items-center justify-center">
          <i class="bi bi-hexagon-fill text-lime-400"></i>
        </div>
      </div>
      <div class="text-3xl font-bold text-lime-400 mb-1">$25</div>
      <div class="text-xs text-gray-400 mb-4">Минимальная инвестиция</div>
      
      <div class="space-y-2 mb-4 text-sm">
        <div class="flex justify-between">
          <span class="text-gray-400 text-xs">Доходность:</span>
          <span class="text-lime-400 font-semibold text-sm">+136%</span>
        </div>
        <div class="flex justify-between">
          <span class="text-gray-400 text-xs">Ежедневно:</span>
          <span class="text-white text-sm">+0.75 $</span>
        </div>
        <div class="flex justify-between">
          <span class="text-gray-400 text-xs">Лимит:</span>
          <span class="text-white text-sm">34.00 $</span>
        </div>
      </div>
      
      <?php if (isset($_SESSION['uid'])): ?>
        <a href="/user/galaxy" class="btn-lime w-full py-2.5 text-center block text-sm">Инвестировать</a>
      <?php else: ?>
        <a href="/signup" class="btn-lime w-full py-2.5 text-center block text-sm">Начать</a>
      <?php endif; ?>
    </div>
    
    <!-- План 3 -->
    <div class="bubble-card p-5 relative overflow-hidden">
      <div class="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-lime-600/50 to-lime-800/50"></div>
      <div class="flex items-center justify-between mb-3">
        <div>
          <div class="text-xs text-gray-400">GOLD</div>
          <div class="text-lg font-bold">3%</div>
        </div>
        <div class="w-10 h-10 rounded-lg bg-lime-400/10 flex items-center justify-center">
          <i class="bi bi-gem text-lime-400"></i>
        </div>
      </div>
      <div class="text-3xl font-bold text-lime-400 mb-1">$50</div>
      <div class="text-xs text-gray-400 mb-4">Минимальная инвестиция</div>
      
      <div class="space-y-2 mb-4 text-sm">
        <div class="flex justify-between">
          <span class="text-gray-400 text-xs">Доходность:</span>
          <span class="text-lime-400 font-semibold text-sm">+141%</span>
        </div>
        <div class="flex justify-between">
          <span class="text-gray-400 text-xs">Ежедневно:</span>
          <span class="text-white text-sm">+1.50 $</span>
        </div>
        <div class="flex justify-between">
          <span class="text-gray-400 text-xs">Лимит:</span>
          <span class="text-white text-sm">70.50 $</span>
        </div>
      </div>
      
      <?php if (isset($_SESSION['uid'])): ?>
        <a href="/user/galaxy" class="btn-lime w-full py-2.5 text-center block text-sm">Инвестировать</a>
      <?php else: ?>
        <a href="/signup" class="btn-dark w-full py-2.5 text-center block text-sm">Начать</a>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Функции -->
<!--<div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
  <div class="bubble-card p-4 text-center hover:border-lime-400/30 transition">
    <img src="img/4.png" class="w-14 mx-auto mb-2" alt="Galaxy">
    <h4 class="text-sm font-bold text-lime-400">Galaxy</h4>
    <p class="text-gray-400 text-[10px]">Доступные тарифы</p>
  </div>
  
  <div class="bubble-card p-4 text-center hover:border-lime-400/30 transition">
    <img src="img/1.png" class="w-14 mx-auto mb-2" alt="Выплаты">
    <h4 class="text-sm font-bold text-lime-400">Выплаты</h4>
    <p class="text-gray-400 text-[10px]">Своевременные выплаты</p>
  </div>
  
  <div class="bubble-card p-4 text-center hover:border-lime-400/30 transition">
    <img src="img/2.png" class="w-14 mx-auto mb-2" alt="Партнёры">
    <h4 class="text-sm font-bold text-lime-400">Партнёры</h4>
    <p class="text-gray-400 text-[10px]">Зарабатывайте с рефералов</p>
  </div>
  
  <div class="bubble-card p-4 text-center hover:border-lime-400/30 transition">
    <img src="img/3.png" class="w-14 mx-auto mb-2" alt="Сёрфинг">
    <h4 class="text-sm font-bold text-lime-400">Сёрфинг</h4>
    <p class="text-gray-400 text-[10px]">Деньги за просмотр</p>
  </div>
  
  <div class="bubble-card p-4 text-center hover:border-lime-400/30 transition">
    <img src="img/5.png" class="w-14 mx-auto mb-2" alt="Бонусы">
    <h4 class="text-sm font-bold text-lime-400">Бонусы</h4>
    <p class="text-gray-400 text-[10px]">Бонусы за активность</p>
  </div>
  
  <div class="bubble-card p-4 text-center hover:border-lime-400/30 transition">
    <img src="img/6.png" class="w-14 mx-auto mb-2" alt="Мобильность">
    <h4 class="text-sm font-bold text-lime-400">Мобильность</h4>
    <p class="text-gray-400 text-[10px]">Доступ с любых устройств</p>
  </div>
</div>-->
