<?php if(!defined('FastCore')){exit('Oops!');}

// Заголовки
$opt = array(
  'title' => 'Выплаты'
);
 
// Получаем данные за последние 24 часа
$last_24_hours = time() - 60 * 60 * 24;

// Запрос на выборку данных за последние 24 часа
$query = "SELECT * FROM db_payout WHERE status = '3' AND `add` >= ?";

// Подготовка и выполнение запроса с параметром
$result = $db->query($query, $last_24_hours);

// Получаем все данные
$pays = $result->fetchAll();

// Суммируем все выплаты за последние 24 часа
$total_sum = 0;
foreach ($pays as $pay) {
    $total_sum += $pay['sum'];
}

?>

<!-- Заголовок -->
<div class="mb-6">
  <h1 class="text-2xl font-bold text-gradient mb-2">{!TITLE!}</h1>
  <p class="text-gray-400 text-sm">Последние выплаты пользователям</p>
</div>

<!-- Статистика за 24 часа -->
<div class="bubble-card p-6 mb-6">
  <div class="flex items-center justify-between">
    <div>
      <div class="text-sm text-gray-400 mb-1">Выплачено за 24 часа</div>
      <div class="text-3xl font-bold text-lime-400"><?= number_format($total_sum, 2, '.', ' '); ?> $</div>
    </div>
    <div class="w-14 h-14 rounded-xl bg-lime-400/10 flex items-center justify-center">
      <i class="bi bi-cash-stack text-lime-400 text-2xl"></i>
    </div>
  </div>
</div>

<!-- Таблица выплат -->
<div class="bubble-card overflow-hidden">
  <div class="p-4 border-b border-lime-400/10">
    <h3 class="font-semibold flex items-center gap-2">
      <i class="bi bi-clock-history text-lime-400"></i>
      Последние выплаты
    </h3>
  </div>
  
  <div class="overflow-x-auto">
    <table class="table-dark">
      <thead>
        <tr>
          <th>Пользователь</th>
          <th>Сумма</th>
          <th>Система</th>
          <th>Дата</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $payout = $db->query('SELECT * FROM db_payout WHERE status = 3 ORDER BY id DESC LIMIT 15')->fetchAll();
        $img_array = ['payeer' => 'Payeer', 'yandex' => 'ЮMoney', 'azvox' => 'Azvox'];

        if (empty($payout)) {
            echo '<tr><td colspan="4" class="py-8 text-center text-gray-500">Нет записей</td></tr>';
        } else {
            foreach ($payout as $pay) {
                $user_data = $db->query("SELECT is_vip FROM db_users WHERE id = ?", [$pay['uid']])->fetchArray();
                $is_vip = isset($user_data['is_vip']) ? $user_data['is_vip'] : 0;
                $us = $db->query('SELECT avatar FROM db_users WHERE id = "'.$pay['uid'].'"')->fetchArray();
                
                $color = 'text-gray-300';
                switch ($pay['systems']) {
                    case 'payeer':
                        $color = 'text-blue-400';
                        break;
                    case 'yandex':
                        $color = 'text-purple-400';
                        break;
                    case 'azvox':
                        $color = 'text-indigo-400';
                        break;
                }
        ?>
        <tr>
          <td class="flex items-center gap-3">
            <img src="/avatars/<?= !empty($us['avatar']) ? htmlspecialchars($us['avatar']) : '4.png' ?>" 
                 class="w-8 h-8 rounded-full border border-lime-400/30" alt="Avatar">
            <span><?= htmlspecialchars($pay['login']); ?></span>
            <?php if ($is_vip): ?>
              <span class="badge-vip">VIP</span>
            <?php endif; ?>
          </td>
          <td class="text-lime-400 font-semibold"><?= number_format($pay['sum'], 2, '.', ' '); ?> $</td>
          <td class="<?= $color ?>"><?= isset($img_array[$pay['systems']]) ? $img_array[$pay['systems']] : 'Неизвестно'; ?></td>
          <td><?= date("d.m.Y", $pay['add']); ?></td>
        </tr>
        <?php
            }
        }
        ?>
      </tbody>
    </table>
  </div>
</div>
