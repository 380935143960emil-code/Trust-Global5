<?php if(!defined('FastCore')){exit('Opss!');}
$opt['title'] = 'Настройки';
?>


<div class="mb-6">
  <h1 class="text-2xl font-bold text-gradient mb-2">{!TITLE!}</h1>
  <p class="text-gray-400 text-sm">Управляйте настройками вашего аккаунта</p>
</div>


<div class="bubble-card p-6 mb-6">
  <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
    <i class="bi bi-shield-lock text-lime-400"></i>
    Изменить пароль
  </h3>

  <?php
  if (isset($_POST['new_pass'])) {
    $pass = $func->FPass($_POST['pass']);
    $pass_new = $func->FPass($_POST['pass_new']);
    if ($pass !== false && strtolower($pass) == strtolower($user['pass'])) {
      if ($pass_new !== false) {
        $db->query("UPDATE db_users SET pass = '$pass_new' WHERE id = '$uid'");
        echo '<div class="bubble-card p-4 mb-4 border-lime-400/30">
          <div class="flex items-center gap-3 text-lime-400">
            <i class="bi bi-check-circle text-xl"></i>
            <span>Пароль успешно изменен!</span>
          </div>
        </div>';
      } else {
        echo '<div class="bubble-card p-4 mb-4 border-yellow-400/30">
          <div class="flex items-center gap-3 text-yellow-400">
            <i class="bi bi-exclamation-triangle text-xl"></i>
            <span>Новый пароль имеет неверный формат!</span>
          </div>
        </div>';
      }
    } else {
      echo '<div class="bubble-card p-4 mb-4 border-red-400/30">
        <div class="flex items-center gap-3 text-red-400">
          <i class="bi bi-exclamation-triangle text-xl"></i>
          <span>Старый пароль заполнен неверно!</span>
        </div>
      </div>';
    }
  }
  ?>

  <form method="POST" action="">
    <div class="space-y-4">
      <div>
        <label class="block text-gray-400 text-sm mb-2">Старый пароль</label>
        <div class="relative">
          <i class="bi bi-lock absolute left-4 top-1/2 -translate-y-1/2 text-gray-500"></i>
          <input type="password" name="pass" class="input-dark w-full pl-11" placeholder="Введите старый пароль" required>
        </div>
      </div>

      <div>
        <label class="block text-gray-400 text-sm mb-2">Новый пароль</label>
        <div class="relative">
          <i class="bi bi-key absolute left-4 top-1/2 -translate-y-1/2 text-gray-500"></i>
          <input type="password" name="pass_new" class="input-dark w-full pl-11" placeholder="Введите новый пароль" required>
        </div>
      </div>

      <button type="submit" name="new_pass" class="btn-lime w-full py-3 flex items-center justify-center gap-2">
        <i class="bi bi-check-lg"></i>
        Сменить пароль
      </button>
    </div>
  </form>
</div>


<div class="bubble-card p-6 mb-6">
  <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
    <i class="bi bi-envelope text-lime-400"></i>
    Платежные реквизиты
  </h3>

  <?php
  $email_success_popup = false;
  if (isset($_POST['update_email'])) {
    if (!empty($user['email2'])) {
      echo '<div class="bubble-card p-4 mb-4 border-red-400/30">
        <div class="flex items-center gap-3 text-red-400">
          <i class="bi bi-exclamation-triangle text-xl"></i>
          <span>Обновление email запрещено, так как email уже привязан.</span>
        </div>
      </div>';
    } else {
      $new_email = $_POST['email'];
      $db->query('UPDATE db_users SET email2 = ? WHERE id = ?', $new_email, $user['id']);
      $user['email2'] = $new_email;
      $email_success_popup = true;
    }
  }
  ?>

  
  <?php if ($email_success_popup): ?>
  <div id="emailSuccessModal" class="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50" style="animation: fadeIn 0.3s ease;">
    <div class="bubble-card p-8 max-w-sm w-full mx-4 transform scale-100" style="animation: scaleIn 0.3s ease;">
      <div class="text-center">
        <div class="w-20 h-20 bg-lime-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
          <i class="bi bi-envelope-check text-4xl text-lime-400"></i>
        </div>
        <h4 class="text-xl font-bold text-white mb-2">Готово!</h4>
        <p class="text-gray-300 mb-6">Ваша почта успешно привязана</p>
        <button onclick="closeEmailModal()" class="btn-lime w-full py-3 flex items-center justify-center gap-2">
          <i class="bi bi-check-lg"></i>
          Отлично
        </button>
      </div>
    </div>
  </div>
  
  <style>
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
    @keyframes scaleIn {
      from { transform: scale(0.9); opacity: 0; }
      to { transform: scale(1); opacity: 1; }
    }
  </style>
  
  <script>
    function closeEmailModal() {
      document.getElementById('emailSuccessModal').style.display = 'none';
      window.location.href = window.location.href;
    }
    document.getElementById('emailSuccessModal').addEventListener('click', function(e) {
      if (e.target === this) closeEmailModal();
    });
  </script>
  <?php endif; ?>

  <form method="POST" action="" class="space-y-4">
    <input type="hidden" name="update_email" value="1">
    
    <div>
      <label class="block text-gray-400 text-sm mb-2">Email для выплат</label>
      <div class="relative">
        <div class="w-10 h-10 absolute left-1 top-1/2 -translate-y-1/2 bg-blue-500/10 rounded-lg flex items-center justify-center">
          <img src="/assets/images/ps/fpay.png" class="w-6 h-6 object-contain" alt="faucetpay">
        </div>
        <input type="email" name="email" class="input-dark w-full pl-14" 
               value="<?php echo htmlspecialchars($user['email2']); ?>"
               placeholder="Введите email faucetpay"
               <?php echo !empty($user['email2']) ? 'readonly' : ''; ?>>
      </div>
      
      <?php if (!empty($user['email2'])): ?>
        <div class="mt-2 flex items-center gap-2 text-sm text-lime-400">
          <i class="bi bi-check-circle-fill"></i>
          <span>Email привязан к аккаунту</span>
        </div>
      <?php endif; ?>
    </div>

    <?php if (empty($user['email2'])): ?>
      <button type="submit" class="btn-lime w-full py-3 flex items-center justify-center gap-2">
        <i class="bi bi-check-lg"></i>
        Привязать
      </button>
    <?php else: ?>
      <div class="bubble-card p-3 bg-gray-800/50 border border-gray-700/50">
        <div class="flex items-center gap-2 text-sm text-gray-400">
          <i class="bi bi-info-circle"></i>
          <span>Для смены email обратитесь в поддержку</span>
        </div>
      </div>
    <?php endif; ?>
  </form>
</div>


<div class="bubble-card p-6">
  <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
    <i class="bi bi-wallet2 text-lime-400"></i>
    Платёжные кошельки
  </h3>
  
  <?php
  $wallet = new wallets();

  $ps = $db->query('SELECT * FROM db_purse WHERE uid = ?', [$uid])->fetchArray();
  if (!$ps) {
    $time = time();
    $db->query('INSERT INTO db_purse (uid, time) VALUES (?, ?)', [$uid, $time]);
    $ps = $db->query('SELECT * FROM db_purse WHERE uid = ?', [$uid])->fetchArray();
  }

  if (isset($_POST['save_wallet'])) {
    $payeer = $_POST['wallets']['payeer']['purse'] ?? '';
    $yandex = $_POST['wallets']['yandex']['purse'] ?? '';
    $azvox  = $_POST['wallets']['azvox']['purse'] ?? '';

    $err = [];
    $save_p = [];

    if (!empty($payeer)) {
      $payeer_valid = $wallet->payeer_wallet($payeer);
      if ($payeer_valid === false) {
        $err[] = 'Неверный формат кошелька PAYEER!';
      } else {
        $ok = $db->query('SELECT * FROM db_purse WHERE payeer = ?', [$payeer])->numRows();
        if ($ok > 0 && $ps['payeer'] != $payeer) {
          $err[] = 'Такой PAYEER уже используется!';
        } elseif ($ps['payeer'] == '0') {
          $db->query('UPDATE db_purse SET payeer = ? WHERE uid = ?', [$payeer, $uid]);
          $save_p[] = 'Кошелек PAYEER сохранен';
        }
      }
    }

    if (!empty($azvox)) {
      $azvox_valid = $wallet->azvox_wallet($azvox);
      if ($azvox_valid === false) {
        $err[] = 'Неверный формат кошелька AZVOX!';
      } else {
        $ok = $db->query('SELECT * FROM db_purse WHERE azvox = ?', [$azvox])->numRows();
        if ($ok > 0 && $ps['azvox'] != $azvox) {
          $err[] = 'Такой AZVOX уже используется!';
        } elseif ($ps['azvox'] == '0') {
          $db->query('UPDATE db_purse SET azvox = ? WHERE uid = ?', [$azvox, $uid]);
          $save_p[] = 'Кошелек AZVOX сохранен';
        }
      }
    }

    if (!empty($err)) {
      echo '<div class="bubble-card p-4 mb-4 border-red-400/30">
        <div class="flex items-center gap-3 text-red-400">
          <i class="bi bi-exclamation-triangle text-xl"></i>
          <span>' . array_shift($err) . '</span>
        </div>
      </div>';
    }
    
    if (!empty($save_p)) {
      echo '<div class="bubble-card p-4 mb-4 border-lime-400/30">
        <div class="flex items-center gap-3 text-lime-400">
          <i class="bi bi-check-circle text-xl"></i>
          <span>' . array_shift($save_p) . '</span>
        </div>
      </div>';
    }
  }
  ?>

  <form method="POST" action="">
    <div class="space-y-4">
      
      <div>
        <label class="block text-gray-400 text-sm mb-2">Azvox кошелёк</label>
        <div class="relative">
          <div class="w-10 h-10 absolute left-1 top-1/2 -translate-y-1/2 bg-indigo-500/10 rounded-lg flex items-center justify-center">
            <img src="/assets/images/ps/azvox.png" class="w-6 h-6 object-contain">
          </div>
          <input type="text" name="wallets[azvox][purse]" class="input-dark w-full pl-14" 
                 value="<?= ($ps['azvox'] != '0') ? $ps['azvox'] : ''; ?>" 
                 placeholder="Azvox кошелёк"
                 <?= ($ps['azvox'] != '0') ? 'readonly' : ''; ?>>
        </div>
        <?php if ($ps['azvox'] != '0'): ?>
          <div class="mt-1 text-xs text-lime-400"><i class="bi bi-check-circle"></i> Кошелёк сохранён</div>
        <?php endif; ?>
      </div>

      <?php if ($ps['azvox'] == '0'): ?>
        <button type="submit" name="save_wallet" class="btn-lime w-full py-3 flex items-center justify-center gap-2">
          <i class="bi bi-save"></i>
          Сохранить кошельки
        </button>
      <?php endif; ?>
    </div>
  </form>
</div>