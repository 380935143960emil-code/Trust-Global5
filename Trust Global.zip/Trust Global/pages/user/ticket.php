<?php if(!defined('FastCore')){exit('Opss!');}
$opt['title'] = 'Техническая поддержка';

$type=3;
if(!empty($pg->segment[2] ==='add')) $type=1;
if(!empty($pg->segment[2] ==='ticket')) $type=3;
if(!empty($pg->segment[2] ==='mess')) $type=2;

$nickticket = 'Поддержка';

// Обновляем время последнего просмотра всех тикетов пользователя
$db->Query("UPDATE db_support SET last_read=".time()." WHERE uid='$uid'");
?>

<!-- Заголовок -->
<div class="mb-6">
  <h1 class="text-2xl font-bold text-gradient mb-2">{!TITLE!}</h1>
  <p class="text-gray-400 text-sm">Свяжитесь с нами для решения любых вопросов</p>
</div>

<!-- Информация -->
<div class="bubble-card p-4 mb-6">
  <div class="flex items-center gap-3 text-gray-400">
    <i class="bi bi-clock text-lime-400"></i>
    <span>Время работы поддержки: с 08:00 до 00:00 по МСК</span>
  </div>
</div>

<!-- Навигация -->
<div class="flex gap-3 mb-6">
  <a href="/user/ticket" class="flex-1 py-3 px-4 rounded-xl text-center font-medium transition-all <?= $type == 3 ? 'bg-lime-400 text-dark-900' : 'bg-dark-700 text-gray-400 hover:text-lime-400' ?>">
    <i class="bi bi-chat-left-text mr-2"></i>
    Мои обращения
  </a>
  <a href="/user/ticket/add" class="flex-1 py-3 px-4 rounded-xl text-center font-medium transition-all <?= $type == 1 ? 'bg-lime-400 text-dark-900' : 'bg-dark-700 text-gray-400 hover:text-lime-400' ?>">
    <i class="bi bi-plus-circle mr-2"></i>
    Новое обращение
  </a>
</div>

<?php
if($type==1) { 
?>
<?php
if(isset($_POST['submit_rit'])){
  $tima = filter_var($_POST['title_g'], FILTER_SANITIZE_STRING);
  $sod = filter_var($_POST['post_g'], FILTER_SANITIZE_STRING);

  if($tima==""){$err[] = 'Заполните поле Тема';}
  elseif($sod==""){$err[] = 'Заполните поле Содержание';}
  $date = time();
  if(empty($err)){
    $db->Query("INSERT INTO `db_support` (`user`,`uid`,`title`,`text`,`date`,`status`)VALUES('$login','$uid','$tima','$sod','$date','0')");
    echo '<div class="bubble-card p-4 mb-4 border-lime-400/30">
      <div class="flex items-center gap-3 text-lime-400">
        <i class="bi bi-check-circle text-xl"></i>
        <span>Тикет успешно создан!</span>
      </div>
    </div>';
    header('Refresh: 1; URL=/user/ticket'); return;
  } else {
    foreach($err AS $error)
    echo '<div class="bubble-card p-4 mb-4 border-red-400/30">
      <div class="flex items-center gap-3 text-red-400">
        <i class="bi bi-exclamation-triangle text-xl"></i>
        <span>'.$error.'</span>
      </div>
    </div>';
  }
}
?>

<!-- Форма создания тикета -->
<div class="bubble-card p-6">
  <h3 class="text-lg font-semibold mb-4">Создать новое обращение</h3>
  <form method="POST" class="space-y-4">
    <div>
      <label class="block text-gray-400 text-sm mb-2">Тема обращения</label>
      <input type="text" maxlength="60" required placeholder="Введите тему тикета" name="title_g" class="input-dark w-full">
    </div>
    <div>
      <label class="block text-gray-400 text-sm mb-2">Содержание</label>
      <textarea name="post_g" maxlength="500" required placeholder="Опишите вашу проблему подробно" class="input-dark w-full h-32 resize-none"></textarea>
    </div>
    <button type="submit" name="submit_rit" class="btn-lime w-full py-3 flex items-center justify-center gap-2">
      <i class="bi bi-send"></i>
      Отправить обращение
    </button>
  </form>
</div>

<?php
} else if($type==2) {
?>

<?php
# ответ 
if(isset($pg->segment[2])){
  $idr = intval($pg->params[1]);

  if(isset($_POST['ans_go'])){
    $id_m = htmlspecialchars($_POST['id_mes'], FILTER_SANITIZE_STRING);
    $date = time();
    $ans = htmlspecialchars($_POST['ans'], FILTER_SANITIZE_STRING);
    $db->Query("INSERT INTO `db_ot_sup` (`id_mes`,`user`,`text`,`date`)VALUES('$id_m','$login','$ans','$date')");
    echo '<div class="bubble-card p-4 mb-4 border-lime-400/30">
      <div class="flex items-center gap-3 text-lime-400">
        <i class="bi bi-check-circle text-xl"></i>
        <span>Сообщение отправлено!</span>
      </div>
    </div>';
    header('Refresh: 1');
    $db->Query("UPDATE db_support SET status='0' WHERE id='$id_m'");
  }

  $tid = intval($pg->params[1]);
  $remd = $db->Query("SELECT * FROM db_support WHERE id='$tid'")->FetchArray();
  $idd  = $remd['id'];
  $title  = $remd['title'];
  $user = $remd['user'];
  $textd  = $remd['text'];
  $dat  = $remd['date'];
  $status  = $remd['status'];

  $status_array2 = array(0 => "bg-yellow-500", 1 => "bg-lime-500", 2 => "bg-blue-500", 3 => "bg-red-500");
  $status_array = array(0 => "В очереди", 1 => "Просмотрено", 2 => "Отменена", 3 => "Закрыт");

  if ($login == $user) {
?>

<!-- Тикет -->
<div class="bubble-card p-5 mb-4">
  <div class="flex flex-wrap items-center gap-3 mb-4 pb-4 border-b border-lime-400/10">
    <span class="badge-lime">№<?=$idd?></span>
    <span class="text-gray-400"><?=$user?></span>
    <span class="<?=$status_array2[$status]; ?> text-white text-xs font-semibold px-3 py-1 rounded-full"><?=$status_array[$status]; ?></span>
    <span class="text-gray-500 text-sm ml-auto"><?=date("d.m.Y",$dat)?></span>
  </div>
  <h3 class="text-lg font-semibold mb-3"><?=$title?></h3>
  <p class="text-gray-300"><?=$textd?></p>
</div>

<?php if ($status != '3'): ?>
<!-- Форма ответа -->
<div class="bubble-card p-5 mb-4">
  <form method="POST">
    <textarea name="ans" maxlength="500" required placeholder="Введите текст ответа" class="input-dark w-full h-24 resize-none mb-4"></textarea>
    <input type="hidden" name="id_mes" value='<?=$idd?>'>
    <button type="submit" name="ans_go" class="btn-lime w-full py-3 flex items-center justify-center gap-2">
      <i class="bi bi-reply"></i>
      Отправить ответ
    </button>
  </form>
</div>
<?php else: ?>
<div class="bubble-card p-4 mb-4 border-red-400/30">
  <div class="flex items-center gap-3 text-red-400">
    <i class="bi bi-lock text-xl"></i>
    <span>Тикет закрыт, вы не можете отправлять новые сообщения</span>
  </div>
</div>
<?php endif; ?>

<!-- История сообщений -->
<?php
$remd2 = $db->Query("SELECT * FROM db_ot_sup WHERE id_mes='$idd' ORDER BY id DESC LIMIT 5000")->fetchAll();
foreach ($remd2 as $remd2) { 
?>
<div class="bubble-card p-4 mb-3 <?= $remd2['user'] == $nickticket ? 'border-lime-400/30' : '' ?>">
  <div class="flex items-center gap-2 mb-2">
    <?php if ($remd2['user'] == $nickticket): ?>
      <i class="bi bi-headset text-lime-400"></i>
      <span class="font-semibold text-lime-400">Поддержка</span>
    <?php else: ?>
      <i class="bi bi-person text-gray-400"></i>
      <span class="font-semibold text-gray-400"><?=$remd2['user']?></span>
    <?php endif; ?>
    <span class="text-gray-500 text-xs ml-auto"><?=date("d.m.Y H:i",$remd2['date'])?></span>
  </div>
  <p class="text-gray-300"><?=$remd2['text']?></p>
</div>
<?php } ?>

<?php
  } else {
?>
<div class="bubble-card p-8 text-center">
  <div class="w-16 h-16 rounded-xl bg-red-400/10 flex items-center justify-center mx-auto mb-4">
    <i class="bi bi-lock text-red-400 text-2xl"></i>
  </div>
  <h3 class="text-lg font-semibold mb-2">Просмотр запрещён</h3>
  <p class="text-gray-400 text-sm">У вас нет доступа к этому тикету</p>
</div>
<?php
  }
  return;
}
?>
<?php
} else if($type==3) {
?>
 
<!-- Список тикетов -->
<div class="space-y-3">
<?php
$rows = $db->query("SELECT * FROM `db_support` WHERE uid = '$uid' ORDER BY id DESC LIMIT 20")->fetchAll();
if(empty($rows)) { 
  echo '<div class="bubble-card p-8 text-center">
    <div class="w-16 h-16 rounded-xl bg-lime-400/10 flex items-center justify-center mx-auto mb-4">
      <i class="bi bi-inbox text-lime-400 text-2xl"></i>
    </div>
    <h3 class="text-lg font-semibold mb-2">У вас нет обращений</h3>
    <p class="text-gray-400 text-sm mb-4">Создайте новое обращение, если у вас есть вопросы</p>
    <a href="/user/ticket/add" class="btn-lime inline-flex items-center gap-2 px-6 py-2">
      <i class="bi bi-plus-circle"></i>
      Создать обращение
    </a>
  </div>';
} else {
  foreach ($rows as $shop) { 
    if($shop['status']=='0'){$ot = 'В очереди'; $otClass = 'bg-yellow-500';} else {$ot = 'Просмотрено'; $otClass = 'bg-lime-500';}
    if($shop['status']=='3'){$ot = 'Закрыт'; $otClass = 'bg-red-500';} 
?>
  <a href="/user/ticket/mess/<?=$shop['id']; ?>" class="bubble-card p-4 flex items-center justify-between hover:border-lime-400/30 transition">
    <div class="flex items-center gap-3">
      <i class="bi bi-chat-left-text text-lime-400"></i>
      <span class="font-medium"><?=$shop['title']; ?></span>
    </div>
    <div class="flex items-center gap-3">
      <span class="<?=$otClass; ?> text-white text-xs font-semibold px-3 py-1 rounded-full"><?=$ot?></span>
      <span class="text-gray-500 text-sm"><?=date("d.m.Y H:i",$shop['date']); ?></span>
      <i class="bi bi-chevron-right text-gray-500"></i>
    </div>
  </a>
<?php
  }
}
?> 
</div>
<?php
}
?>
