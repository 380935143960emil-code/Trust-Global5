<?php if (!defined('FastCore')) { exit('Opss!'); }

// Заголовок
$opt['title'] = 'Личный кабинет';

$bonusok = 1; // Бонус

// Пользователь вышел
if ($pg->segment[1] === 'logout') {
    session_destroy();
    header('Location: /');
    return;
}
?>
<?php include "inc/statday.php"; ?>

<!-- Заголовок страницы -->
<div class="mb-6">
  <h1 class="text-2xl font-bold text-gradient">{!TITLE!}</h1>
  <p class="text-gray-400 text-sm">Управляйте своими инвестициями и отслеживайте доход</p>
</div>

<?php
if ($user['bonreg'] == '0'){
?>
<div class="mb-6">
  <?php
  # Бонус
  if(isset($_POST['bonreg'])) {
    if($user['sum_in'] <= 999.99) {
      $err[]='<script>
        Swal.fire({
          icon: "warning",
          title: "У вас должно быть пополнение на проекте от 1000 RUB и получите этот бонус",
          showConfirmButton: true
        });
      </script>';
      header('Refresh: 9; URL=/user/dashboard'); 
    }
    elseif($user['bonreg'] >= 1) {
      $err[]='<script>
        Swal.fire({
          icon: "warning",
          title: "Вы уже получили бонус!",
          showConfirmButton: true
        });
      </script>'; 
      header('Refresh: 3; URL=/user/dashboard');
    }
    else {
      $db->query("UPDATE db_users SET `money_b` = `money_b` + '100' WHERE `id` = '$uid'");
      $db->query("UPDATE db_users SET bonreg = '1' WHERE id = '$uid'");
      
      echo '<script>
        Swal.fire({
          icon: "success",
          title: "Вы получили бонус 100 RUB!",
          showConfirmButton: true
        });
      </script>';
      header('Refresh: 3; URL=/user/dashboard');
    }
  }
  # ошибки
  if (!empty($err)) {
    echo '<div class="alert alert-danger"> '.array_shift($err).'</div>';
  }
  ?>
</div>
<?php
}
?>

<!-- Балансы -->
<div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
  <!-- Баланс для покупок -->
  <div class="bubble-card p-5">
    <div class="flex items-center justify-between mb-3">
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-xl bg-lime-400/10 flex items-center justify-center">
          <i class="bi bi-wallet text-lime-400"></i>
        </div>
        <span class="text-gray-400 text-sm">Баланс покупки</span>
      </div>
    </div>
    <div class="text-3xl font-bold text-lime-400 mb-3"><?= sprintf("%.2f", $user['money_b']); ?> $</div>
    <a href="/user/insertts" class="btn-lime w-full py-2 text-center text-sm flex items-center justify-center gap-2">
      <i class="bi bi-plus-circle"></i>
      Пополнить
    </a>
  </div>
  
  <!-- Баланс для выплат -->
  <div class="bubble-card p-5">
    <div class="flex items-center justify-between mb-3">
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center">
          <i class="bi bi-wallet2 text-red-400"></i>
        </div>
        <span class="text-gray-400 text-sm">Баланс вывода</span>
      </div>
    </div>
    <div class="text-3xl font-bold text-red-400 mb-3"><?= sprintf("%.2f", $user['money_p']); ?> $</div>
    <a href="/user/paymentes" class="btn-dark w-full py-2 text-center text-sm flex items-center justify-center gap-2 border-red-400/30 text-red-400 hover:bg-red-400/10">
      <i class="bi bi-arrow-down-circle"></i>
      Вывести
    </a>
  </div>
  
  <!-- Доход от рефералов -->
  <div class="bubble-card p-5">
    <div class="flex items-center justify-between mb-3">
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
          <i class="bi bi-people text-blue-400"></i>
        </div>
        <span class="text-gray-400 text-sm">Реферальный доход</span>
      </div>
    </div>
    <div class="text-3xl font-bold text-blue-400 mb-3"><?= sprintf("%.2f", $user['income']); ?> $</div>
    <a href="/user/refs" class="btn-dark w-full py-2 text-center text-sm flex items-center justify-center gap-2 border-blue-400/30 text-blue-400 hover:bg-blue-400/10">
      <i class="bi bi-share"></i>
      Пригласить
    </a>
  </div>
</div>

<!-- Информация и статистика -->
<div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
  <!-- Мои данные -->
  <div class="bubble-card p-5">
    <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
      <i class="bi bi-person-circle text-lime-400"></i>
      Мои данные
    </h3>
    <div class="space-y-3">
      <div class="flex justify-between items-center py-2 border-b border-lime-400/10">
        <span class="text-gray-400 text-sm">Логин</span>
        <span class="font-medium"><?= $user['login']; ?></span>
      </div>
      <div class="flex justify-between items-center py-2 border-b border-lime-400/10">
        <span class="text-gray-400 text-sm">Email</span>
        <span class="font-medium"><?= $user['email']; ?></span>
      </div>
      <div class="flex justify-between items-center py-2 border-b border-lime-400/10">
        <span class="text-gray-400 text-sm">Регистрация</span>
        <span class="font-medium"><?= date("d.m.Y", $user['reg']); ?></span>
      </div>
      <div class="flex justify-between items-center py-2 border-b border-lime-400/10">
        <span class="text-gray-400 text-sm">Пригласил</span>
        <span class="font-medium"><?= $user['referer'] ?: 'Нет'; ?></span>
      </div>
      <div class="flex justify-between items-center py-2">
        <span class="text-gray-400 text-sm">Рефералов</span>
        <span class="font-medium text-lime-400"><?= $user['refs']; ?> <i class="bi bi-person-fill"></i></span>
      </div>
    </div>
  </div>
  
  <!-- Моя статистика -->
  <div class="bubble-card p-5">
    <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
      <i class="bi bi-graph-up text-lime-400"></i>
      Моя статистика
    </h3>
    <div class="space-y-3">
      <div class="flex justify-between items-center py-2 border-b border-lime-400/10">
        <span class="text-gray-400 text-sm">Всего пополнено</span>
        <span class="font-medium text-lime-400"><?= sprintf("%.2f", $user['sum_in']); ?> $</span>
      </div>
      <div class="flex justify-between items-center py-2 border-b border-lime-400/10">
        <span class="text-gray-400 text-sm">Всего выплачено</span>
        <span class="font-medium text-red-400"><?= sprintf("%.2f", $user['sum_out']); ?> $</span>
      </div>
      <div class="flex justify-between items-center py-2 border-b border-lime-400/10">
        <span class="text-gray-400 text-sm">Баланс покупок</span>
        <span class="font-medium text-lime-400"><?= sprintf("%.2f", $user['money_b']); ?> $</span>
      </div>
      <div class="flex justify-between items-center py-2 border-b border-lime-400/10">
        <span class="text-gray-400 text-sm">Баланс вывода</span>
        <span class="font-medium text-red-400"><?= sprintf("%.2f", $user['money_p']); ?> $</span>
      </div>
      <!--<div class="flex justify-between items-center py-2">
        <span class="text-gray-400 text-sm">Сёрфинг</span>
        <span class="font-medium text-blue-400"><?= sprintf("%.0f", $user['surf_view']); ?> / <?= sprintf("%.2f", $user['surf_earn']); ?> $</span>
      </div>-->
    </div>
  </div>
</div>

<!-- История операций -->
<div class="bubble-card p-5" x-data="{ tab: 'in' }">
  <div class="flex items-center justify-between mb-6">
    <h3 class="text-lg font-semibold flex items-center gap-2">
      <i class="bi bi-clock-history text-lime-400"></i>
      История операций
    </h3>
    
    <!-- Tabs -->
    <div class="flex bg-dark-700 rounded-xl p-1">
      <button @click="tab = 'in'" :class="tab === 'in' ? 'bg-lime-400 text-dark-900' : 'text-gray-400'" class="px-4 py-2 rounded-lg text-sm font-medium transition-all">
        Пополнения
      </button>
      <button @click="tab = 'out'" :class="tab === 'out' ? 'bg-lime-400 text-dark-900' : 'text-gray-400'" class="px-4 py-2 rounded-lg text-sm font-medium transition-all">
        Выплаты
      </button>
    </div>
  </div>
  
  <!-- Таблица пополнений -->
  <div x-show="tab === 'in'" class="overflow-x-auto">
    <table class="table-dark">
      <thead>
        <tr>
          <th>Дата</th>
          <th>Сумма</th>
          <th>Метод</th>
          <th>Статус</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $inserts = $db->query("SELECT * FROM db_insert WHERE uid = ? ORDER BY id DESC LIMIT 10", [$uid])->fetchAll();
        if ($inserts) {
          foreach ($inserts as $row) {
            $paymentMethod = htmlspecialchars($row['sys']);
            $methodClass = '';
            $methodName = ucfirst($paymentMethod);
            
            switch ($paymentMethod) {
              case 'freekassa':
                $methodClass = 'text-red-400';
                $methodName = 'FreeKassa';
                break;
              case 'payeer':
                $methodClass = 'text-blue-400';
                $methodName = 'Payeer';
                break;
              case 'yoomoney':
                $methodClass = 'text-purple-400';
                $methodName = 'YooMoney';
                break;
              default:
                $methodClass = 'text-lime-400';
                break;
            }
            
            echo "<tr>";
            echo "<td>" . date("d.m.Y H:i", $row['add']) . "</td>";
            echo "<td class='text-lime-400 font-semibold'>" . number_format($row['sum'], 2, '.', ' ') . " $</td>";
            echo "<td class='$methodClass'>" . $methodName . "</td>";
            echo "<td>" . ($row['status'] == 1 ? "<span class='badge-lime'>Пополнено</span>" : "<span class='text-yellow-400'>В ожидании</span>") . "</td>";
            echo "</tr>";
          }
        } else {
          echo "<tr><td colspan='4' class='text-center text-gray-500 py-4'>Нет записей</td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>
  
  <!-- Таблица выплат -->
  <div x-show="tab === 'out'" class="overflow-x-auto" style="display: none;">
    <table class="table-dark">
      <thead>
        <tr>
          <th>Дата</th>
          <th>Сумма</th>
          <th>Кошелёк</th>
          <th>Статус</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $status_array = array(
          0 => ["Проверяется", "text-yellow-400"],
          1 => ["Ожидается", "text-blue-400"],
          2 => ["Отменена", "text-red-500"],
          3 => ["Выплачено", "text-lime-400"]
        );
        
        $pays = $db->query("SELECT * FROM db_payout WHERE uid = ? ORDER BY id DESC LIMIT 10", [$uid])->fetchAll();
        
        if ($pays) {
          foreach ($pays as $row) {
            $status = $status_array[$row['status']][0];
            $colorClass = $status_array[$row['status']][1];
            
            echo "<tr>";
            echo "<td>" . date("d.m.Y H:i", $row['add']) . "</td>";
            echo "<td class='text-red-400 font-semibold'>" . number_format($row['sum'], 2, '.', ' ') . " $</td>";
            echo "<td>" . htmlspecialchars($row['purse']) . "</td>";
            echo "<td><span class='$colorClass'>$status</span></td>";
            echo "</tr>";
          }
        } else {
          echo "<tr><td colspan='4' class='text-center text-gray-500 py-4'>Нет записей</td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
