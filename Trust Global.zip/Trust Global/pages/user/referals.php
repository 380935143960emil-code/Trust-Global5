<?php if(!defined('FastCore')){exit('Opss!');}

$opt['title'] = 'Партнерская программа';

$refs = $user['refs'];
$income = number_format($user['income'], 3, '.', ' ');
$url = 'https://' . $_SERVER['HTTP_HOST'];
$refLink = $url . '/i/' . $uid;
$lp = ($url.'/img/promo/');

// Получаем всех рефералов
$ref = $db->query("SELECT * FROM db_users WHERE rid = '$uid' ORDER BY ref_to DESC, surf_view DESC")->fetchAll();

// Пагинация
$per_page = 20;
$total_records = count($ref);
$total_pages = ceil($total_records / $per_page);
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = max(1, min($total_pages, $page));
$start_from = ($page - 1) * $per_page;
$ref_paginated = array_slice($ref, $start_from, $per_page);
$range = 1;
$start = max(1, $page - $range);
$end = min($total_pages, $page + $range);

?>

<!-- Заголовок -->
<div class="mb-6">
  <h1 class="text-2xl font-bold text-gradient mb-2">{!TITLE!}</h1>
  <p class="text-gray-400 text-sm">Приглашайте друзей и зарабатывайте вместе</p>
</div>

<!-- Статистика -->
<div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
  <div class="bubble-card p-5 text-center">
    <div class="text-3xl font-bold text-lime-400 mb-1"><?= $refs; ?></div>
    <div class="text-sm text-gray-400">Всего рефералов</div>
  </div>
  <div class="bubble-card p-5 text-center">
    <div class="text-3xl font-bold text-lime-400 mb-1"><?= $income; ?> $</div>
    <div class="text-sm text-gray-400">Реферальный доход</div>
  </div>
  <div class="bubble-card p-5 text-center">
    <div class="text-3xl font-bold text-lime-400 mb-1">6%</div>
    <div class="text-sm text-gray-400">От пополнений</div>
  </div>
</div>

<!-- Реферальная ссылка -->
<div class="bubble-card p-6 mb-6">
  <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
    <i class="bi bi-link-45deg text-lime-400"></i>
    Ваша реферальная ссылка
  </h3>
  <div class="flex items-center gap-3">
    <div class="relative flex-1">
      <i class="bi bi-globe absolute left-4 top-1/2 -translate-y-1/2 text-gray-500"></i>
      <input type="text" id="refLink" onclick="this.select()" readonly
             value="<?=$refLink; ?>"
             class="input-dark w-full pl-11">
    </div>
    <button onclick="copyRefLink(this)" class="btn-lime px-4 py-3 flex items-center gap-2">
      <i class="bi bi-clipboard"></i>
      <span class="hidden sm:inline">Копировать</span>
    </button>
  </div>
  <p class="mt-3 text-sm text-gray-400">Поделитесь этой ссылкой с друзьями и получайте 6% от их пополнений!</p>
</div>

<!-- Баннеры -->
<!--<div class="bubble-card p-6 mb-6">
  <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
    <i class="bi bi-image text-lime-400"></i>
    Рекламные баннеры
  </h3>
  
  <div class="space-y-4">
    <div>
      <div class="text-sm text-gray-400 mb-2">Баннер 468x60</div>
      <div class="p-4 rounded-xl bg-dark-700">
        <img src="<?=$lp;?>468.gif" alt="Баннер 468x60" class="mx-auto mb-3">
        <div class="flex items-center gap-2">
          <input type="text" value="<?=$lp;?>468.gif" class="input-dark flex-1 text-sm" readonly>
          <button onclick="copyToClipboard('<?=$lp;?>468.gif')" class="btn-dark px-3 py-2">
            <i class="bi bi-clipboard"></i>
          </button>
        </div>
      </div>
    </div>
  </div>
</div>-->

<!-- Список рефералов -->
<div class="bubble-card p-6">
  <h3 class="text-lg font-semibold mb-4 flex items-center gap-2">
    <i class="bi bi-people text-lime-400"></i>
    Мои рефералы
  </h3>
  
  <?php if ($total_records > 0): ?>
    <div class="overflow-x-auto">
      <table class="table-dark">
        <thead>
          <tr>
            <th>Логин</th>
            <th>Дата регистрации</th>
            <th>Доход</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($ref_paginated as $r): ?>
            <tr>
              <td class="flex items-center gap-2">
                <i class="bi bi-person text-lime-400"></i>
                <?= htmlspecialchars($r['login']); ?>
              </td>
              <td><?= date("d.m.Y", $r['reg']); ?></td>
              <td class="text-lime-400"><?= number_format($r['ref_to'], 2, '.', ' '); ?> $</td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    
    <!-- Пагинация -->
    <?php if ($total_pages > 1): ?>
      <div class="flex justify-center gap-2 mt-6">
        <?php if ($page > 1): ?>
          <a href="?page=<?= $page - 1; ?>" class="btn-dark px-4 py-2">
            <i class="bi bi-chevron-left"></i>
          </a>
        <?php endif; ?>
        
        <?php for ($i = $start; $i <= $end; $i++): ?>
          <?php if ($i == $page): ?>
            <span class="btn-lime px-4 py-2"><?= $i; ?></span>
          <?php else: ?>
            <a href="?page=<?= $i; ?>" class="btn-dark px-4 py-2"><?= $i; ?></a>
          <?php endif; ?>
        <?php endfor; ?>
        
        <?php if ($page < $total_pages): ?>
          <a href="?page=<?= $page + 1; ?>" class="btn-dark px-4 py-2">
            <i class="bi bi-chevron-right"></i>
          </a>
        <?php endif; ?>
      </div>
    <?php endif; ?>
  <?php else: ?>
    <div class="text-center py-8">
      <div class="w-16 h-16 rounded-xl bg-lime-400/10 flex items-center justify-center mx-auto mb-4">
        <i class="bi bi-people text-lime-400 text-2xl"></i>
      </div>
      <h4 class="text-lg font-semibold mb-2">У вас пока нет рефералов</h4>
      <p class="text-gray-400 text-sm mb-4">Поделитесь вашей реферальной ссылкой с друзьями</p>
    </div>
  <?php endif; ?>
</div>

<script>
function copyRefLink(btn) {
    const refLink = document.getElementById('refLink');
    refLink.select();
    document.execCommand('copy');
    
    const originalHTML = btn.innerHTML;
    btn.innerHTML = '<i class="bi bi-check-lg"></i> Скопировано';
    btn.classList.add('bg-lime-500');
    
    setTimeout(() => {
        btn.innerHTML = originalHTML;
        btn.classList.remove('bg-lime-500');
    }, 2000);
}

function copyToClipboard(text) {
    const tempInput = document.createElement('input');
    tempInput.value = text;
    document.body.appendChild(tempInput);
    tempInput.select();
    document.execCommand('copy');
    document.body.removeChild(tempInput);
    
    Swal.fire({
        icon: 'success',
        title: 'Скопировано!',
        text: 'Ссылка скопирована в буфер обмена',
        timer: 1500,
        showConfirmButton: false
    });
}
</script>
