<?php if (!defined('FastCore')) {
    echo 'Выявлена попытка взлома!';
    exit();
}
$opt['title'] = 'Успешно';
?>

<!-- Заголовок -->
<div class="mb-6 text-center">
  <h1 class="text-2xl font-bold text-gradient mb-2">Успешное пополнение</h1>
  <p class="text-gray-400 text-sm">Ваш баланс пополнен</p>
</div>

<!-- Сообщение об успехе -->
<div class="max-w-md mx-auto">
  <div class="bubble-card p-8 text-center">
    <div class="w-20 h-20 rounded-full bg-lime-400/10 flex items-center justify-center mx-auto mb-6">
      <i class="bi bi-check-circle-fill text-lime-400 text-4xl"></i>
    </div>
    
    <p class="text-gray-300 mb-6">
      Вы успешно оплатили, и на баланс покупки начислены рубли.
    </p>

    <a href="/user/dashboard" class="btn-lime inline-flex items-center gap-2 px-8 py-3">
      <i class="bi bi-grid"></i>
      Перейти в кабинет
    </a>
  </div>
</div>
