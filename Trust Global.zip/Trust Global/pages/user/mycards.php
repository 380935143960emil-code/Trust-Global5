<?php if(!defined('FastCore')){exit('Opss!');}

$opt['title'] = 'Мои карты';
$time = time();
?>

<style>
/* Компактная карта */
.bank-card {
    position: relative;
    width: 100%;
    aspect-ratio: 1.586 / 1;
    border-radius: 12px;
    overflow: hidden;
    background: linear-gradient(145deg, #0a0a0a 0%, #141414 50%, #0d0d0d 100%);
    border: 1px solid rgba(163, 230, 53, 0.15);
    box-shadow: 0 8px 32px rgba(0,0,0,0.8);
    transition: all 0.3s ease;
}

.bank-card:hover {
    transform: translateY(-4px);
    border-color: rgba(163, 230, 53, 0.3);
}

/* Верхний левый угол — чип и статус */
.card-top-left {
    position: absolute;
    top: 6%;
    left: 5%;
    display: flex;
    align-items: center;
    gap: 10px;
}

.card-status {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: #a3e635;
    box-shadow: 0 0 10px rgba(163, 230, 53, 0.8);
    animation: pulse 2s infinite;
    flex-shrink: 0;
}

.card-status.waiting {
    background: #f59e0b;
    box-shadow: 0 0 10px rgba(245, 158, 11, 0.8);
}

@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
}

.card-chip {
    width: 36px;
    height: 28px;
    background: linear-gradient(135deg, #a3e635 0%, #65a30d 100%);
    border-radius: 6px;
    border: 1px solid rgba(163, 230, 53, 0.5);
    box-shadow: 0 2px 8px rgba(0,0,0,0.5);
    position: relative;
}

.card-chip::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 70%;
    height: 60%;
    border: 1px solid rgba(0,0,0,0.3);
    border-radius: 3px;
    background: 
        linear-gradient(90deg, transparent 45%, rgba(0,0,0,0.4) 50%, transparent 55%),
        linear-gradient(0deg, transparent 45%, rgba(0,0,0,0.4) 50%, transparent 55%);
}

/* Логотип справа */
.card-logo {
    position: absolute;
    top: 6%;
    right: 5%;
    display: flex;
    align-items: center;
    gap: 6px;
}

.card-logo-icon {
    width: 24px;
    height: 24px;
    background: linear-gradient(135deg, #a3e635, #65a30d);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 10px;
    color: #000;
    font-weight: 900;
}

.card-logo-text {
    font-size: 12px;
    font-weight: 800;
    color: #a3e635;
    letter-spacing: 1px;
}

/* Прогресс — под чипом */
.card-progress {
    position: absolute;
    top: 28%;
    left: 5%;
    right: 5%;
}

.card-progress-text {
    font-size: 11px;
    color: #a3e635;
    font-weight: 700;
    margin-bottom: 4px;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.card-progress-bar {
    height: 4px;
    background: rgba(255,255,255,0.1);
    border-radius: 2px;
    overflow: hidden;
}

.card-progress-fill {
    height: 100%;
    background: #a3e635;
    border-radius: 2px;
    box-shadow: 0 0 8px rgba(163, 230, 53, 0.5);
}

/* Нижняя зона — больше места */
.card-footer {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 55%;
    background: linear-gradient(180deg, rgba(0,0,0,0) 0%, rgba(0,0,0,0.4) 100%);
    border-top: 1px solid rgba(163, 230, 53, 0.1);
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    padding: 8px 4%;
    gap: 8px;
}

/* Статистика */
.card-stats {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 6px 12px;
    margin-bottom: 4px;
}

.stat-box {
    display: flex;
    flex-direction: column;
    gap: 1px;
}

.stat-label {
    font-size: 9px;
    color: rgba(255,255,255,0.4);
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.stat-value {
    font-size: 14px;
    color: #fff;
    font-weight: 700;
    line-height: 1.2;
}

.stat-value.accent {
    color: #a3e635;
}

/* Кнопка/таймер */
.card-action {
    width: 100%;
    height: 42px;
}

.collect-btn {
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, #a3e635 0%, #65a30d 100%);
    border: none;
    border-radius: 8px;
    color: #000;
    font-weight: 800;
    font-size: 12px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    box-shadow: 0 4px 15px rgba(163, 230, 53, 0.3);
    text-transform: uppercase;
    letter-spacing: 1px;
}

.collect-btn:hover {
    transform: scale(1.02);
    box-shadow: 0 6px 20px rgba(163, 230, 53, 0.5);
}

.timer-box {
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    border: 1px solid rgba(163, 230, 53, 0.2);
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
}

.timer-label {
    font-size: 9px;
    color: rgba(163, 230, 53, 0.7);
    text-transform: uppercase;
}

.timer-value {
    font-family: 'Courier New', monospace;
    font-size: 16px;
    color: #a3e635;
    font-weight: 700;
    text-shadow: 0 0 8px rgba(163, 230, 53, 0.4);
    letter-spacing: 2px;
}

/* Собрано справа от прогресса */
.card-collected {
    position: absolute;
    top: 28%;
    right: 5%;
    text-align: right;
}

.card-collected-label {
    font-size: 9px;
    color: rgba(255,255,255,0.4);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 1px;
}

.card-collected-value {
    font-size: 14px;
    color: #a3e635;
    font-weight: 700;
    line-height: 1.2;
}

/* Адаптив */
@media (max-width: 768px) {
    .stat-value { font-size: 13px; }
    .timer-value { font-size: 14px; }
    .collect-btn { font-size: 11px; }
    .card-collected-value { font-size: 13px; }
}
</style>

<!-- Заголовок -->
<div class="mb-6">
  <h1 class="text-2xl font-bold text-gradient mb-2">{!TITLE!}</h1>
  <p class="text-gray-400 text-sm">Обналичивание доходов с карт</p>
</div>

<?php
/* --- ЛОГИКА --- */
if(isset($_POST["buy"])){
    $idkup = intval($_POST["item"]);
    $rows = $db->query('SELECT * FROM db_kupon_price WHERE id = ?',[$idkup])->numRows();
    if ($rows == 1) {
        $kup_data = $db->query("SELECT * FROM db_kupon_price WHERE id = ? LIMIT 1",[$idkup])->fetchArray();
        if ($kup_data['name'] == 'Работник-Галактик') {
            $has_worker = $db->query("SELECT * FROM db_workers WHERE user_id = ? AND worker_type='collector' AND active=1",[$uid])->numRows();
            if ($has_worker > 0) {
                echo "<script>Swal.fire({icon:'info',title:'У вас уже есть Работник!',showConfirmButton:true});</script>";
            } else {
                if($user["money_b"] >= $kup_data['price']) {
                    $db->query("INSERT INTO db_workers (user_id, worker_type, created_at, active) VALUES (?,?,?,1)",[$uid,'collector',$time]);
                    $db->query("UPDATE db_users SET money_b = money_b - ? WHERE id = ?",[$kup_data['price'],$uid]);
                    echo "<script>Swal.fire({icon:'success',title:'Вы наняли Работника!',showConfirmButton:true});</script>";
                } else {
                    echo "<script>Swal.fire({icon:'error',title:'Недостаточно средств!',showConfirmButton:true});</script>";
                }
            }
        } else {
            if($user["money_b"] >= $kup_data['price']) {
                $date_next = $time + (60*60*24);
                $db->query("INSERT INTO db_kupon (login,user_id,kupon_type,kupon_gived,kupon_back,date_last_sbor,date_next_sbor) VALUES (?,?,?,?,?,?,?)",[$login,$uid,$kup_data['price'],0,$kup_data['nominal'],$time,$date_next]);
                $db->query("UPDATE db_users SET money_b = money_b - ? WHERE id = ?",[$kup_data['price'],$uid]);
                echo "<script>Swal.fire({icon:'success',title:'Карта успешно выпущена',showConfirmButton:true});</script>";
            } else {
                echo "<script>Swal.fire({icon:'error',title:'Недостаточно средств!',showConfirmButton:true});</script>";
            }
        }
    }
}

if(isset($_POST['sbor'])) {
    $idsbor = (int)$_POST['sbor'];
    $numkup = $db->query("SELECT * FROM db_kupon WHERE id = ? AND user_id = ? ORDER BY id LIMIT 1", [$idsbor, $uid])->numRows();
    if($numkup >= 1) {
        $kups = $db->query("SELECT * FROM db_kupon WHERE id = ? AND user_id = ? ORDER BY id LIMIT 1", [$idsbor, $uid])->fetchArray();
        if ($kups['date_next_sbor'] <= $time){
            $moneysbor = $kups['kupon_type'] * 0.03;
            $date_next = $time + (60*60*24);
            $db->query("UPDATE db_users SET money_p = money_p + ? WHERE id = ?", [$moneysbor, $uid]);
            if($kups['kupon_gived'] + $moneysbor < $kups['kupon_back']) {
                $db->query("UPDATE db_kupon SET kupon_gived = ?, date_last_sbor = ?, date_next_sbor = ? WHERE id = ? AND user_id = ?", [$kups['kupon_gived'] + $moneysbor, $kups['date_last_sbor'], $date_next, $idsbor, $uid]);
                echo "<script>Swal.fire({icon:'success',title:'Сбор произведён!',showConfirmButton:true});</script>";
            } else {
                $db->query("DELETE FROM db_kupon WHERE id = ? AND user_id = ?", [$idsbor, $uid]);
                echo "<script>Swal.fire({icon:'success',title:'Последний сбор!',showConfirmButton:true});</script>";
            }
        } else {
            echo "<script>Swal.fire({icon:'info',title:'Время сбора ещё не пришло!',showConfirmButton:true});</script>";
        }
    }
}

$has_worker = $db->query("SELECT * FROM db_workers WHERE user_id = ? AND worker_type='collector' AND active=1",[$uid])->numRows();
if ($has_worker > 0) {
    $kup_list = $db->query("SELECT * FROM db_kupon WHERE user_id = ?",[$uid])->fetchAll();
    foreach ($kup_list as $kup) {
        if ($kup['date_next_sbor'] <= $time) {
            $moneysbor = $kup['kupon_type'] * 0.03;
            $date_next = $time + (60*60*24);
            if ($kup['kupon_gived'] + $moneysbor < $kup['kupon_back']) {
                $db->query("UPDATE db_users SET money_p = money_p + ? WHERE id = ?", [$moneysbor, $uid]);
                $db->query("UPDATE db_kupon SET kupon_gived = ?, date_last_sbor = ?, date_next_sbor = ? WHERE id = ? AND user_id = ?", [$kup['kupon_gived'] + $moneysbor, $kup['date_last_sbor'], $date_next, $kup['id'], $uid]);
            } else {
                $db->query("UPDATE db_users SET money_p = money_p + ? WHERE id = ?", [$moneysbor, $uid]);
                $db->query("DELETE FROM db_kupon WHERE id = ? AND user_id = ?", [$kup['id'], $uid]);
            }
        }
    }
}
?>

<!-- Работник -->
<div class="bubble-card p-6 mb-6">
  <div class="flex flex-col sm:flex-row items-center gap-6">
    <div class="relative">
      <div class="absolute -inset-2 bg-lime-400/20 rounded-full blur-xl animate-pulse"></div>
      <img src="/img/worker.png" alt="Работник" class="relative w-24 h-24 rounded-full border-2 border-lime-400/30">
    </div>
    <div class="flex-1 text-center sm:text-left">
      <h3 class="text-xl font-bold text-lime-400 mb-2">Привет, <?=$login;?>!</h3>
      <?php if($has_worker > 0): ?>
       <!-- <p class="text-gray-400 mb-2">Автосбор активирован</p>
        <div class="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-lime-400/10 border border-lime-400/20">
          <i class="bi bi-robot text-lime-400"></i>
          <span class="text-sm text-lime-400">Работник активен</span>
        </div>-->
      <?php else: ?>
        <p class="text-gray-400 mb-4">Заходите каждые 24 часа, чтобы снимать средства с ваших активных карт</p>
        <?php $worker_price = $db->query("SELECT price FROM db_kupon_price WHERE name=''")->fetchArray(); ?>
        <!--<form method="post">
          <input type="hidden" name="item" value="999">
          <button type="submit" name="buy" class="btn-lime inline-flex items-center gap-2 px-6 py-2">
            <i class="bi bi-person-plus"></i> Нанять за <?=$worker_price['price']; ?> $
          </button>
        </form>-->
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Список Galaxy -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
<?php
$kup_list = $db->query("SELECT * FROM db_kupon WHERE user_id = ? ORDER BY id ASC",[$uid])->fetchAll();
if($kup_list) {
    foreach($kup_list as $w) {
        $progress = ($w['kupon_gived'] / $w['kupon_back']) * 100;
        $next_income = $w['kupon_type'] * 0.01;
        $is_ready = $w['date_next_sbor'] <= time();
?>
    <div class="bank-card">
        <!-- Верхний левый угол: статус + чип -->
        <div class="card-top-left">
            <div class="card-status <?=$is_ready ? '' : 'waiting'; ?>"></div>
            <div class="card-chip"></div>
        </div>
        
        <!-- Логотип -->
        <div class="card-logo">
            <div class="card-logo-icon"><i class="bi bi-hexagon-fill text-dark-900 text-lg"></i></div>
            <span class="card-logo-text"><?=$kup["name"]; ?></span>
        </div>
        
        <!-- Прогресс -->
        <div class="card-progress">
            <div class="card-progress-text">PROGRESS <?=round($progress, 1); ?>%</div>
            <div class="card-progress-bar">
                <div class="card-progress-fill" style="width: <?=min($progress, 100); ?>%"></div>
            </div>
        </div>
        
        <!-- Собрано справа от прогресса -->
        <div class="card-collected">
            <div class="card-collected-label">Собрано <?=$w['kupon_gived']; ?> $</div>
           
        </div>
        
        <!-- Подвал со статистикой -->
        <div class="card-footer">
            <div class="card-stats">

                <div class="card-collected">
                    
                    <span class="card-collected-label">Лимит: <span class="stat-value accent"> $<?=$w['kupon_back']; ?></span></span>
                </div>
				<div class="stat-box">
                    
                    <span class="card-collected-label">Тип: <span class="stat-value accent"> $<?=$w['kupon_type']; ?></span></span>
                </div>
            </div>
            
            <div class="card-action">
                <?php if($is_ready): ?>
                    <form action="" method="post" style="width: 100%; height: 100%;">
                        <input type="hidden" name="sbor" value="<?=$w['id'];?>">
                        <button type="submit" class="collect-btn">
                            <i class="bi bi-cash-coin"></i> СОБРАТЬ C КАРТЫ
                        </button>
                    </form>
                <?php else: ?>
                    <div class="timer-box">
                        <span class="timer-label">До сбора</span>
                        <span class="timer-value" id="timer<?=$w['id'];?>">00:00:00</span>
                    </div>
                    <script>
                        function updateTimer(id, next, current) {
                            var time = next - current;
                            if(time <= 0) { location.reload(); return; }
                            var h = Math.floor(time/3600);
                            var m = Math.floor((time%3600)/60);
                            var s = time%60;
                            document.getElementById('timer'+id).innerHTML = 
                                (h<10?'0'+h:h)+':'+(m<10?'0'+m:m)+':'+(s<10?'0'+s:s);
                            setTimeout(function(){updateTimer(id,next,current+1)},1000);
                        }
                        updateTimer(<?=$w['id'];?>,<?=$w['date_next_sbor'];?>,<?=time();?>);
                    </script>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php
    }
} else {
    echo '<div class="col-span-full text-center py-8 text-gray-400">У вас нет выпущенных карт</div>';
}
?>
</div>