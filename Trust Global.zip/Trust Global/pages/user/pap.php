<?php if(!defined('FastCore')){exit('Oops!');}

// Заголовок страницы
$opt['title'] = 'Вывод средства';

// Проверка, заблокирован ли пользователь
if ($user['ban'] == 1){
    exit('Your account has been blocked for violating the rules');
}

// Ваш ключ сайта reCAPTCHA (оставляю для возможных будущих интеграций)
$site_key = "6LfF7BorAAAAALbl7IXQYMXSwaVY9B_dMwIsFwAG"; // <--- ваш ключ reCAPTCHA

# Расчёты лимитов
$dep = $user['sum_in'];
$refDep = round($user['income'],6);

if($dep >= $accPay2 && $dep <= 100000) {
    $sumlimit = $dep / 5;
    $sumlimit = floor($sumlimit);
    $sumlimit = round($sumlimit,2);
    $userHitr = 0;
} else {
    $userHitr = 1;
    $sumlimit = 15;
}

// Другие переменные
$valid = $user['login'];
$varPy = 'TLN8e4CaczfiShAQEqn3WMppfDBYTrrLim';
$systemPay = 'USDT';
$currency = 'USDT';
$minPay = 1;
$maxPay = 9;
$maxPay2 = $sumlimit;
$todayLimit = 24;
?>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<!DOCTYPE html>
<html lang="ru">
<head> 
    <meta charset="UTF-8" />
    <title><?=$opt['title'];?></title>
    <style>
        #real-content { display: none; }
    </style>
</head>
<body>

<div id="real-content" style="display:block;">

<div class="container mx-auto px-4 max-w-2xl mt-3">

    <!-- Заголовок -->
    <div class="relative mb-6">
        <div class="absolute inset-0 bg-[#3498db]/20 blur-3xl rounded-full opacity-50"></div>
        <div class="glass-card rounded-2xl p-1 border border-[#3498db]/20 relative overflow-hidden">
            <div class="absolute inset-0 bg-gradient-to-r from-[#3498db]/10 via-transparent to-[#3498db]/10"></div>
            <h1 class="relative text-center text-2xl font-bold text-white py-3 px-4">
                <span class="bg-gradient-to-r from-[#3498db] to-[#2980b9] bg-clip-text text-transparent">{!TITLE!}</span>
            </h1>
        </div>
    </div>

    <!-- Инфо блок -->
    <div class="glass-card rounded-2xl p-5 mb-6 border border-lime-400/10 relative overflow-hidden">
        <div class="absolute top-0 right-0 w-32 h-32 bg-lime-400/5 rounded-full blur-3xl"></div>
        
        <div class="flex items-center justify-center gap-2 mb-3">
            <i class="bi bi-lightning-charge-fill text-lime-400"></i>
            <span class="text-lime-400 font-semibold text-sm">Платежи осуществляются быстро и автоматически</span>
        </div>
        
        <div class="text-center">
            <p class="text-gray-400 text-sm">Минимальная выплата: <span class="text-white font-bold"><?=$minPay;?> USDT</span></p>
        </div>
    </div>

<?php 
// Проверка наличия депозита
if($user['sum_in'] < $accPay) {
    echo '<div class="glass-card border border-red-500/30 rounded-2xl p-6 text-center mb-6">
            <div class="w-16 h-16 rounded-full bg-red-500/10 flex items-center justify-center mx-auto mb-4">
                <i class="bi bi-lock-fill text-red-400 text-2xl"></i>
            </div>
            <h4 class="text-red-400 font-bold text-lg mb-2">Выплаты заблокированы</h4>
            <p class="text-gray-400 text-sm">Приобретите тариф от <span class="text-lime-400 font-bold">'.$accPay.' USDT</span></p>
            <a href="/user/cards" class="inline-block mt-4 px-6 py-2 bg-lime-400 text-dark-900 rounded-xl font-semibold text-sm hover:shadow-[0_0_20px_rgba(200,255,0,0.4)] transition-all">Купить тариф</a>
          </div>';
}
?>

<?php
// Получение кошелька пользователя
$purse = $user["email2"];
$purlg = $user["login"];

// Проверка адреса
if ($purse != $user["email2"]) {
    echo '<div class="glass-card border border-yellow-500/30 rounded-2xl p-6 text-center mb-6">
            <div class="w-16 h-16 rounded-full bg-yellow-500/10 flex items-center justify-center mx-auto mb-4">
                <i class="bi bi-wallet2 text-yellow-400 text-2xl"></i>
            </div>
            <h4 class="text-yellow-400 font-bold mb-2">Кошелек не привязан</h4>
            <p class="text-gray-400 text-sm mb-4">Привяжите FaucetPay адрес в настройках</p>
            <a href="/user/settings" class="inline-block px-6 py-2 bg-lime-400 text-dark-900 rounded-xl font-semibold text-sm hover:shadow-[0_0_20px_rgba(200,255,0,0.4)] transition-all">Настройки</a>
          </div>';
    exit;
}

// Баланс пользователя
$sumUser = $user['money_p'];

// Проверка CSRF
$csrfCheck = $func->csrfVerify();

if (isset($_POST['pay']) && $csrfCheck == TRUE) {
    // Обработка формы выплаты
    $sum = filter_var($_POST['sum'], FILTER_VALIDATE_FLOAT);
    $commision = ($sum > 12) ? 10.00 : 0;
    $com = round($sum - ($sum * $commision / 100), 4);

    // Проверка времени последней выплаты
    $payments = $db->query("SELECT * FROM db_payout WHERE `uid` = '$uid'")->fetchArray();
    if (time() >= $payments['add'] + (3600 * $todayLimit)) {
        // Проверка суммы
        if ($sum >= $minPay && $sum <= $maxPay) {
            if ($user['sum_in'] >= $accPay && $sum <= $sumUser) {
                if ($sum <= $user['points']) {
                    // Время между выплатами
                    // Разрешаем выплату
                    if ($sum > 20) {
                        // Обработка крупной суммы вручную
                        $db->query("UPDATE db_users SET money_p = money_p - '$sum' WHERE id = '$uid'");
                        $da = time(); $dd = $da + 60 * 60 * 24 * 15;
                        $db->query("INSERT INTO db_payout (`uid`, `login`, sum, `sys`, `add`, `del`, status) VALUES ('$uid', '$purlg','$purse','$sum','$ppid','$da','$dd','1')");
                        $db->query("UPDATE db_users SET sum_out = sum_out + '$sum' WHERE id = '$uid'");
                        $db->query("UPDATE db_stats SET payments = payments + '$sum' WHERE id = '1'");
                        
                        echo '<div class="glass-card border border-yellow-500/30 rounded-2xl p-6 text-center mb-6">
                                <div class="w-16 h-16 rounded-full bg-yellow-500/10 flex items-center justify-center mx-auto mb-4">
                                    <i class="bi bi-clock-history text-yellow-400 text-2xl"></i>
                                </div>
                                <h4 class="text-yellow-400 font-bold mb-2">На проверке</h4>
                                <p class="text-gray-400 text-sm">Запрос отправлен администратору</p>
                              </div>';
                    } else {
                        // Отправка через FaucetPay API
                        $faucetpay_api_key = $config->fp_api_key;
                        $amountInSatoshis = intval($com * 100000000);
                        $params = [
                            "api_key" => $faucetpay_api_key,
                            "currency" => $currency,
                            "to" => $purse,
                            "amount" => number_format($amountInSatoshis, 8, '.', ''),  
                        ];
                        $ch = curl_init('https://faucetpay.io/api/v1/send '); 
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        curl_setopt($ch, CURLOPT_POST, true);
                        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
                        $response = curl_exec($ch);
                        curl_close($ch);

                        $result = json_decode($response, true);

                        if (isset($result['message']) && $result['message'] === 'OK') {
                            // Успешная отправка
                            $da = time(); $dd = $da + 60 * 60 * 24 * 15;
                            $db->query("INSERT INTO db_payout (uid, login, sum, `add`, `del`, status) VALUES ('$uid','$purlg','$sum','$da','$dd','3')");
                            $db->query("UPDATE db_users SET sum_out = sum_out + '$sum', money_p = money_p - '$sum', points = points - '$sum' WHERE id = '$uid'");
                            $db->query("UPDATE db_stats SET payments = payments + '$sum' WHERE id = '1'");
                            
                            // Модальное окно успеха
                            echo '<div id="paymentModal" class="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm" style="display:flex;">
                                    <div class="glass-card rounded-3xl p-8 max-w-sm w-full mx-4 border border-lime-400/20 relative overflow-hidden text-center transform scale-100 animate-[bounce_0.5s_ease-out]">
                                        <div class="absolute inset-0 bg-lime-400/5"></div>
                                        <div class="absolute -top-10 -right-10 w-32 h-32 bg-lime-400/20 rounded-full blur-3xl"></div>
                                        
                                        <div class="w-20 h-20 rounded-full bg-lime-400/20 flex items-center justify-center mx-auto mb-4 relative">
                                            <i class="bi bi-check-circle-fill text-lime-400 text-4xl"></i>
                                            <div class="absolute inset-0 rounded-full border-2 border-lime-400/30 animate-ping"></div>
                                        </div>
                                        
                                        <h3 class="text-white font-bold text-xl mb-2">Успешно!</h3>
                                        <p class="text-gray-400 text-sm mb-4">Средства отправлены на ваш кошелек</p>
                                        
                                        <div class="text-3xl font-bold text-lime-400 mb-6">+ '.$com.' <span class="text-lg">USDT</span></div>
                                        
                                        <a href="/reviews" class="block w-full py-3 bg-lime-400 text-dark-900 rounded-xl font-bold mb-3 hover:shadow-[0_0_20px_rgba(200,255,0,0.4)] transition-all">Оставить отзыв</a>
                                        <button onclick="document.getElementById(\'paymentModal\').style.display=\'none\'" class="text-gray-500 text-sm hover:text-white transition-colors">Закрыть</button>
                                    </div>
                                  </div>';
                        } else {
                            // Ошибка при отправке
                            $msg = isset($result['message']) ? htmlspecialchars($result['message']) : 'Произошла неизвестная ошибка.';
                            echo '<div class="glass-card border border-red-500/30 rounded-2xl p-6 text-center mb-6">
                                    <div class="w-16 h-16 rounded-full bg-red-500/10 flex items-center justify-center mx-auto mb-4">
                                        <i class="bi bi-x-circle-fill text-red-400 text-2xl"></i>
                                    </div>
                                    <h4 class="text-red-400 font-bold mb-2">Ошибка</h4>
                                    <p class="text-gray-400 text-sm">'.$msg.'</p>
                                  </div>';
                        }
                    }
                } else {
                    // Недостаточно EXP
                    echo '<div id="paymentModal" class="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm" style="display:flex;">
                            <div class="glass-card rounded-3xl p-8 max-w-sm w-full mx-4 border border-red-400/20 text-center">
                                <div class="w-20 h-20 rounded-full bg-red-400/20 flex items-center justify-center mx-auto mb-4">
                                    <i class="bi bi-lightning-charge-fill text-red-400 text-3xl"></i>
                                </div>
                                <h3 class="text-white font-bold text-xl mb-2">Недостаточно EXP</h3>
                                <p class="text-gray-400 text-sm mb-4">У вас: <span class="text-white font-bold">'.$user["points"].'</span> EXP</p>
                                <p class="text-gray-400 text-sm mb-4">Необходимо ещё: <span class="text-lime-400 font-bold">'.($sum-$user["points"]).'</span> EXP</p>
                                <button onclick="document.getElementById(\'paymentModal\').style.display=\'none\'" class="px-6 py-2 bg-lime-400 text-dark-900 rounded-xl font-bold hover:shadow-[0_0_20px_rgba(200,255,0,0.4)] transition-all">Понятно</button>
                            </div>
                          </div>';
                }
            } else {
                echo '<div class="glass-card border border-red-500/30 rounded-2xl p-6 text-center mb-6">
                        <div class="w-16 h-16 rounded-full bg-red-500/10 flex items-center justify-center mx-auto mb-4">
                            <i class="bi bi-wallet2 text-red-400 text-2xl"></i>
                        </div>
                        <h4 class="text-red-400 font-bold mb-2">Недостаточно средств</h4>
                        <p class="text-gray-400 text-sm">Доступно: <span class="text-lime-400 font-bold">'.$sumUser.' {!VAL!}</span></p>
                      </div>';
            }
        } else {
            echo '<div class="glass-card border border-yellow-500/30 rounded-2xl p-6 text-center mb-6">
                    <div class="w-16 h-16 rounded-full bg-yellow-500/10 flex items-center justify-center mx-auto mb-4">
                        <i class="bi bi-exclamation-triangle text-yellow-400 text-2xl"></i>
                    </div>
                    <h4 class="text-yellow-400 font-bold mb-2">Лимит превышен</h4>
                    <p class="text-gray-400 text-sm">Максимальная выплата: 10 USDT за раз</p>
                  </div>';
            header('Refresh: 9');
        }
    } else {
        $waitTime = ceil((($payments['add'] + (3600 * $todayLimit)) - time()) / 60);
        echo '<div class="glass-card border border-yellow-500/30 rounded-2xl p-6 text-center mb-6">
                <div class="w-16 h-16 rounded-full bg-yellow-500/10 flex items-center justify-center mx-auto mb-4">
                    <i class="bi bi-clock-history text-yellow-400 text-2xl"></i>
                </div>
                <h4 class="text-yellow-400 font-bold mb-2">Подождите</h4>
                <p class="text-gray-400 text-sm">Следующая выплата через: <span class="text-lime-400 font-bold">'.$waitTime.' мин</span></p>
              </div>';
    }
}
?>

    <!-- Основная форма -->
    <div class="glass-card rounded-3xl p-6 md:p-8 border border-white/5 relative overflow-hidden">
        
        <!-- Логотип -->
        <div class="flex justify-center mb-6">
            <div class="w-20 h-20 rounded-2xl bg-[#3498db]/10 border border-[#3498db]/20 flex items-center justify-center relative group">
                <div class="absolute inset-0 bg-[#3498db]/20 blur-xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <img src="/img/faucetpay.png" alt="FaucetPay" class="w-14 h-10 object-contain relative z-10 drop-shadow-[0_0_10px_rgba(52,152,219,0.5)]">
            </div>
        </div>

        <!-- Кошелек -->
        <div class="mb-6">
            <label class="block text-gray-400 text-sm mb-2 text-center">Ваш FaucetPay адрес</label>
            <div class="glass-card rounded-xl p-4 border border-[#3498db]/20 flex items-center justify-center gap-2 cursor-pointer hover:border-[#3498db]/40 transition-all" id="walletBox">
                <i class="bi bi-wallet2 text-[#3498db]"></i>
                <span id="mytrx" class="text-white font-mono text-sm"></span>
                <i class="bi bi-eye text-gray-500 text-xs ml-2"></i>
            </div>
            <p class="text-center text-xs text-gray-500 mt-2">Нажмите чтобы показать полностью</p>
        </div>

        <!-- Форма -->
        <form action="" method="POST" class="space-y-6">
            <?php $func->csrf(); ?>
            
            <!-- Поле суммы -->
            <div class="space-y-2">
                <label class="block text-gray-400 text-sm text-center">Сумма выплаты</label>
                <div class="relative group/input">
                    <input type="number" 
                           name="sum" 
                           placeholder="0.00" 
                           value="<?=round($sumUser,8); ?>" 
                           min="<?=$minPay;?>" 
                           max="<?=$maxPay;?>" 
                           step="any"
                           class="w-full bg-dark-800/50 border border-white/10 rounded-2xl py-4 px-6 text-white text-2xl font-bold text-center placeholder-gray-600 focus:border-[#3498db]/50 focus:ring-2 focus:ring-[#3498db]/20 focus:outline-none transition-all duration-300">
                    
                    <div class="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 font-semibold">USDT</div>
                </div>
                
                <div class="flex justify-between text-xs text-gray-500 px-2">
                    <span>Min: <span class="text-lime-400"><?=$minPay;?> USDT</span></span>
                    <!--<span>Max: <span class="text-lime-400"><?=$maxPay;?></span></span>-->
                </div>
            </div>

            <!-- Кнопка -->
            <button type="submit" name="pay" class="w-full relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#3498db] to-[#2980b9] text-white font-bold text-lg py-4 px-6 hover:shadow-[0_0_30px_rgba(52,152,219,0.4)] hover:scale-[1.02] active:scale-[0.98] transition-all duration-300 group/btn">
                <div class="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] group-hover/btn:translate-x-[100%] transition-transform duration-700"></div>
                <span class="relative flex items-center justify-center gap-2">
                    <i class="bi bi-arrow-up-circle"></i>
                    Вывести средства
                </span>
            </button>
        </form>

        <!-- Инфо -->
        <div class="mt-6 pt-6 border-t border-white/5">
            <div class="flex items-center justify-center gap-6 text-xs text-gray-500">
                <!--<div class="flex items-center gap-1">
                    <i class="bi bi-shield-check text-lime-400"></i>
                    <span>Безопасно</span>
                </div>-->
                <div class="flex items-center gap-1">
                    <i class="bi bi-lightning text-lime-400"></i>
                    <span>Мгновенно</span>
                </div>
                <div class="flex items-center gap-1">
                    <i class="bi bi-percent text-lime-400"></i>
                    <span>0% комиссия</span>
                </div>
            </div>
        </div>
    </div>

    <!-- История выплат -->
    <div class="mt-6 glass-card rounded-2xl p-5 border border-white/5">
        <h5 class="text-white font-bold text-center mb-4 flex items-center justify-center gap-2">
            <i class="bi bi-clock-history text-[#3498db]"></i>
            История выплат
        </h5>
        
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead>
                    <tr class="text-gray-500 text-xs border-b border-white/5">
                        <th class="pb-3 text-left">Статус</th>
                        <th class="pb-3 text-center">Сумма</th>
                        <th class="pb-3 text-right">Время</th>
                    </tr>
                </thead>
                <tbody class="text-sm">
                    <?php
                    $status_array2 = [
                        0 => '<span class="px-2 py-1 bg-yellow-400/10 text-yellow-400 rounded-full text-xs border border-yellow-400/20">Ожидание</span>',
                        1 => '<span class="px-2 py-1 bg-yellow-400/10 text-yellow-400 rounded-full text-xs border border-yellow-400/20">Проверка</span>',
                        2 => '<span class="px-2 py-1 bg-red-400/10 text-red-400 rounded-full text-xs border border-red-400/20">Отменено</span>',
                        3 => '<span class="px-2 py-1 bg-lime-400/10 text-lime-400 rounded-full text-xs border border-lime-400/20">Успешно</span>'
                    ];
                    $payout = $db->query('SELECT * FROM db_payout WHERE uid = '.$uid.' ORDER BY id DESC LIMIT 10')->fetchAll();
                    foreach ($payout as $payout) {
                    ?>
                    <tr class="border-b border-white/5 last:border-0 hover:bg-white/5 transition-colors">
                        <td class="py-3"><?=$status_array2[$payout['status']]; ?></td>
                        <td class="py-3 text-center text-white font-semibold"><?= sprintf("%.2f",$payout['sum']); ?> <span class="text-gray-500 text-xs">USDT</span></td>
                        <td class="py-3 text-right text-gray-500 text-xs"><?=date("d.m H:i",$payout['add']); ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

</div> <!-- END #real-content -->

<style>
    .glass-card {
        background: linear-gradient(145deg, rgba(26, 26, 26, 0.95), rgba(20, 20, 20, 0.95));
        border: 1px solid rgba(255, 255, 255, 0.05);
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
    }
    
    input[type=number]::-webkit-inner-spin-button, 
    input[type=number]::-webkit-outer-spin-button { 
        -webkit-appearance: none; 
        margin: 0; 
    }
    input[type=number] {
        -moz-appearance: textfield;
    }
</style>

<script>
var longtext = "<?=$user["email2"]; ?>";
var smalltext = "<?=substr_replace($user['email2'], "<span class='text-gray-500'>.......</span>", -18, 9); ?>";

$(function() {
    $("#mytrx").html(smalltext);
    var done = false;
    $("#walletBox, #mytrx").click(function() {
        if (!done) {
            done = true;
            $("#mytrx").html(longtext);
            $(".bi-eye").removeClass("bi-eye").addClass("bi-eye-slash");
        }
    });
});
</script>

</body>
</html>