<?php if(!defined('FastCore')){exit('Opss!');}
 
$opt['title'] = 'Карты';

?>

<style>
/* Банковская карта — чёрный стиль сайта */
.bank-card {
    position: relative;
    width: 100%;
    aspect-ratio: 1.586 / 1;
    border-radius: 16px;
    overflow: hidden;
    background: linear-gradient(145deg, #0a0a0a 0%, #141414 50%, #0d0d0d 100%);
    border: 1px solid rgba(163, 230, 53, 0.15);
    box-shadow: 
        0 8px 32px rgba(0,0,0,0.8),
        0 0 0 1px rgba(163, 230, 53, 0.05),
        inset 0 1px 0 rgba(255,255,255,0.03);
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    transform-style: preserve-3d;
    cursor: pointer;
}

/* Глянцевый блик */
.bank-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, 
        transparent 0%, 
        rgba(163, 230, 53, 0.03) 50%, 
        transparent 100%);
    transition: left 0.6s;
    pointer-events: none;
}

.bank-card:hover::before {
    left: 100%;
}

/* Металлический блик сверху */
.bank-card::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 40%;
    background: linear-gradient(180deg, 
        rgba(255,255,255,0.08) 0%, 
        transparent 100%);
    pointer-events: none;
}

.bank-card:hover {
    transform: translateY(-6px) scale(1.02);
    box-shadow: 
        0 20px 50px rgba(0,0,0,0.9),
        0 0 30px rgba(163, 230, 53, 0.15),
        inset 0 1px 0 rgba(255,255,255,0.05);
    border-color: rgba(163, 230, 53, 0.4);
}

/* Чип — золотисто-лаймовый */
.card-chip {
    position: absolute;
    top: 18%;
    left: 7%;
    width: 13%;
    height: 20%;
    background: linear-gradient(135deg, #a3e635 0%, #65a30d 50%, #4d7c0f 100%);
    border-radius: 6px;
    border: 1px solid rgba(163, 230, 53, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 
        0 2px 8px rgba(0,0,0,0.5),
        inset 0 1px 0 rgba(255,255,255,0.3),
        0 0 10px rgba(163, 230, 53, 0.2);
}

.card-chip::before {
    content: '';
    width: 68%;
    height: 58%;
    border: 1px solid rgba(0,0,0,0.3);
    border-radius: 3px;
    background: 
        linear-gradient(90deg, transparent 47%, rgba(0,0,0,0.4) 49%, rgba(0,0,0,0.4) 51%, transparent 53%),
        linear-gradient(0deg, transparent 47%, rgba(0,0,0,0.4) 49%, rgba(0,0,0,0.4) 51%, transparent 53%);
}

/* Бесконтактная оплата */
.card-contactless {
    position: absolute;
    top: 24%;
    left: 22%;
    font-size: clamp(0.7rem, 1.1vw, 0.9rem);
    color: rgba(163, 230, 53, 0.6);
}

/* Логотип карты */
.card-logo {
    position: absolute;
    top: 8%;
    right: 7%;
    display: flex;
    align-items: center;
    gap: 6px;
}

.card-logo-icon {
    width: 28px;
    height: 28px;
    background: linear-gradient(135deg, #a3e635, #65a30d);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 11px;
    color: #000;
    font-weight: 900;
    box-shadow: 0 0 15px rgba(163, 230, 53, 0.4);
}

.card-logo-text {
    font-size: clamp(0.65rem, 1vw, 0.85rem);
    font-weight: 800;
    color: #a3e635;
    text-transform: uppercase;
    letter-spacing: 1.5px;
    text-shadow: 0 0 10px rgba(163, 230, 53, 0.3);
}

/* Номер карты */
.card-number {
    position: absolute;
    top: 48%;
    left: 7%;
    right: 7%;
    font-family: 'Courier New', monospace;
    font-size: clamp(0.85rem, 1.4vw, 1.1rem);
    color: #e5e5e5;
    letter-spacing: 3px;
    text-shadow: 0 2px 4px rgba(0,0,0,0.9);
    font-weight: 600;
}

/* Инфо строка */
.card-info-row {
    position: absolute;
    bottom: 28%;
    left: 7%;
    right: 7%;
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
}

.card-holder {
    font-size: clamp(0.55rem, 0.9vw, 0.75rem);
}

.card-holder-label {
    font-size: clamp(0.4rem, 0.6vw, 0.55rem);
    color: rgba(163, 230, 53, 0.6);
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 2px;
}

.card-holder-name {
    color: #fff;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    text-shadow: 0 1px 2px rgba(0,0,0,0.8);
}

.card-expiry {
    text-align: right;
    font-size: clamp(0.55rem, 0.9vw, 0.75rem);
}

.card-expiry-label {
    font-size: clamp(0.4rem, 0.6vw, 0.55rem);
    color: rgba(163, 230, 53, 0.6);
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 2px;
}

.card-expiry-value {
    color: #a3e635;
    font-weight: 700;
    font-family: 'Courier New', monospace;
    text-shadow: 0 0 8px rgba(163, 230, 53, 0.4);
}

/* Нижняя панель с ценой и кнопкой */
.card-bottom {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 24%;
    background: linear-gradient(180deg, 
        rgba(163, 230, 53, 0) 0%,
        rgba(163, 230, 53, 0.05) 100%);
    border-top: 1px solid rgba(163, 230, 53, 0.2);
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 6%;
    gap: 10px;
}

.card-price-info {
    display: flex;
    flex-direction: column;
    gap: 2px;
}

.card-price-label {
    font-size: clamp(0.45rem, 0.7vw, 0.65rem);
    color: rgba(255,255,255,0.4);
    text-transform: uppercase;
    letter-spacing: 1px;
}

.card-price-value {
    font-size: clamp(0.9rem, 1.4vw, 1.2rem);
    color: #fff;
    font-weight: 800;
}

.card-price-value span {
    color: #a3e635;
    font-size: clamp(0.7rem, 1.1vw, 0.9rem);
}

/* Кнопка встроенная в карту */
.card-buy-btn {
    background: linear-gradient(135deg, #a3e635 0%, #65a30d 100%);
    border: none;
    border-radius: 8px;
    padding: 8px 16px;
    color: #000;
    font-weight: 800;
    font-size: clamp(0.65rem, 1vw, 0.85rem);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 5px;
    transition: all 0.2s ease;
    box-shadow: 0 4px 15px rgba(163, 230, 53, 0.3);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    white-space: nowrap;
    height: fit-content;
}

.card-buy-btn:hover {
    transform: scale(1.05);
    box-shadow: 0 6px 20px rgba(163, 230, 53, 0.5);
    background: linear-gradient(135deg, #b8f54d 0%, #7cb316 100%);
}

.card-buy-btn:active {
    transform: scale(0.98);
}

.card-buy-btn i {
    font-size: 0.9em;
}

/* Номинал справа от цены */
.card-nominal {
    text-align: right;
}

.card-nominal-label {
    font-size: clamp(0.4rem, 0.6vw, 0.6rem);
    color: rgba(163, 230, 53, 0.7);
    text-transform: uppercase;
    letter-spacing: 1px;
}

.card-nominal-value {
    font-size: clamp(0.8rem, 1.2vw, 1rem);
    color: #a3e635;
    font-weight: 700;
}

/* Голограмма */
.hologram {
    position: absolute;
    bottom: 30%;
    right: 7%;
    width: 10%;
    height: 15%;
    background: linear-gradient(135deg, 
        rgba(163, 230, 53, 0.1) 0%, 
        rgba(163, 230, 53, 0.3) 50%, 
        rgba(163, 230, 53, 0.1) 100%);
    border-radius: 3px;
    transform: skewX(-15deg);
    box-shadow: 0 0 10px rgba(163, 230, 53, 0.2);
}

/* Форма внутри карты */
.card-form {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 24%;
    margin: 0;
    padding: 0;
}

.card-form form {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    padding: 0 6%;
}

/* Адаптивность */
@media (max-width: 640px) {
    .bank-card {
        aspect-ratio: 1.586 / 1;
    }
    .card-buy-btn {
        padding: 6px 12px;
    }
}
</style>

<!-- Заголовок -->
<div class="mb-6">
  <h1 class="text-2xl font-bold text-gradient mb-2">{!TITLE!}</h1>
  <p class="text-gray-400 text-sm">пускайте карту и получайте пассивный доход</p>
</div>

<!-- Информация -->
<div class="bubble-card p-6 mb-6">
  <div class="flex items-start gap-4">
    <div class="w-12 h-12 rounded-xl bg-lime-400/10 flex items-center justify-center flex-shrink-0">
      <i class="bi bi-info-circle text-lime-400 text-xl"></i>
    </div>
    <div>
      <h3 class="font-semibold mb-2">Как работает карты?</h3>
      <p class="text-gray-400 text-sm leading-relaxed">
    Карты можно выпускать по цене от <span class="text-lime-400 font-semibold">5</span> до <span class="text-lime-400 font-semibold">500</span> $.  
    У каждой карты есть свой лимит, который нужно полностью собрать. Каждые <span class="text-lime-400 font-semibold">24 часа</span> начисляется 
    <span class="text-lime-400 font-semibold">3–4%</span> от стоимости карты. Деньги поступают на баланс для вывода.  
    После того как вы собрали весь лимит, карта исчезает. Ваш доход — это собранный вами лимит с карты.
</p>
      <div class="mt-3 inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-lime-400/10 border border-lime-400/20">
        <i class="bi bi-infinity text-lime-400"></i>
        <span class="text-sm text-lime-400">Количество выпука без ограничений</span>
      </div>
    </div>
  </div>
</div>

<?php
if(isset($_POST["buy"])){
    $idkup = intval($_POST["item"]);
    $rows = $db->query('SELECT * FROM db_kupon_price WHERE id = ?',array($idkup))->numRows();
    if ($rows ==1 ) {
        $kup_data = $db->query("SELECT * FROM db_kupon_price WHERE id = '$idkup' LIMIT 1")->fetchArray();
        if($user["money_b"] >= $kup_data['price']) {
            $time = time();
            $date_next = $time + (60*60*24);
            
            $db->query("INSERT INTO db_kupon (login,user_id,name,kupon_type,kupon_gived,kupon_back,date_last_sbor,date_next_sbor) VALUES ('$login','$uid','".$kup_data['id']."','".$kup_data['price']."','0','".$kup_data['nominal']."','$time', '$date_next')");
            $db->query("UPDATE db_users SET money_b = money_b - '".$kup_data['price']."' WHERE id = '$uid'");
            echo '<script>
                Swal.fire({
                    icon: "success",
                    title: "Карта успешно выпущена '.$kup_data['name'].'",
                    showConfirmButton: true
                });
            </script>';
            header('Refresh: 3; URL=/user/mycards'); return;
        } else {
            echo '<div class="bubble-card p-4 mb-4 border-red-400/30">
              <div class="flex items-center gap-3 text-red-400">
                <i class="bi bi-exclamation-triangle text-xl"></i>
                <span>Недостаточно средств на балансе депозита</span>
              </div>
            </div>';
        }
    } else {
        echo '<div class="bubble-card p-4 mb-4 border-red-400/30">
          <div class="flex items-center gap-3 text-red-400">
            <i class="bi bi-exclamation-triangle text-xl"></i>
            <span>Такого карты не существует!</span>
          </div>
        </div>';
    }
}
?> 

<!-- Список Galaxy -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
<?php
$bnum = $db->query("SELECT * FROM `db_kupon_price` WHERE `id` > 0")->numRows();
if($bnum >= 1) {
    $bon = $db->query("SELECT * FROM `db_kupon_price` ORDER BY `id` ASC LIMIT 10")->fetchAll();
    foreach ($bon as $kup) {
        $card_num = str_pad($kup['id'], 4, '0', STR_PAD_LEFT) . ' ' . rand(1100, 9999) . ' ' . rand(1000, 9999) . ' ' . rand(1000, 9999);
?>
    <!-- Карта с встроенной кнопкой -->
    <div class="bank-card" onclick="document.getElementById('form_<?=$kup['id']; ?>').submit();">
        <!-- Логотип -->
        <div class="card-logo">
            <div class="card-logo-icon"><i class="bi bi-hexagon-fill text-dark-900 text-lg"></i></div>
            <span class="card-logo-text"><?=$kup["name"]; ?></span>
        </div>
        
        <!-- Чип -->
        <div class="card-chip"></div>
        
        <!-- Бесконтактная оплата -->
        <div class="card-contactless">
            <i class="bi bi-wifi"></i>
        </div>
        
        <!-- Номер карты -->
        <!--<div class="card-number"><?=$card_num; ?></div>-->
        
        <!-- Инфо -->
        <div class="card-info-row">
            <div class="card-holder">
                <div class="card-holder-label"><i class="bi bi-bar-chart-fill"></i>Доходность</div>
				<div class="card-holder-name"> + <?=$kup["name2"]; ?></div>
            </div>
            <div class="card-expiry">
                <div class="card-expiry-label">Лимит</div>
                <div class="card-nominal-value">$ <?=$kup["nominal"]; ?></div>
            </div>
        </div>
        
        <!-- Голограмма -->
        <div class="hologram"></div>
		<!-- Нижняя панель с ценой, номиналом и кнопкой -->
        <div class="card-bottom">
            <button type="submit" form="form_<?=$kup['id']; ?>" class="card-buy-btn" onclick="event.stopPropagation();">
                <i class="bi bi-cart-plus"></i>
                Выпустить карту
            </button>
			<button type="submit" form="form_<?=$kup['id']; ?>" class="card-buy-btn" onclick="event.stopPropagation();">
                <?=$kup["price"]; ?> $
            </button>
        </div>
        
        <!-- Скрытая форма -->
        <form id="form_<?=$kup['id']; ?>" action="" method="post" style="display:none;">
            <input type="hidden" name="item" value="<?=$kup["id"]; ?>" />
            <input type="hidden" name="buy" value="1" />
        </form>
    </div>
<?php
    }
} else {
    echo '<div class="col-span-full text-center text-gray-500 py-8">Список пуст</div>';
}
?>
</div>