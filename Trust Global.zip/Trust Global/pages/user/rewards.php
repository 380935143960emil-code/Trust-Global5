<?php if(!defined('FastCore')){exit('Opss!');}
######################################
# Услуги по FastCore
# Разработка и продажа модулей и скриптов.
# Telegram: https://t.me/sistemconrol
# Email: vorobevnikolaj795@gmail.com
######################################

if (!isset($uid) || $uid <= 0) { exit('User not authorized'); }

$opt['title'] = 'Награды';
$time = time();

// ===== СЧЁТЧИК ИСТОРИИ =====
$history_count = (int)$db->query("
  SELECT COUNT(*) AS cnt
  FROM db_rewards_requests
  WHERE uid = '{$uid}'
")->fetchArray()['cnt'];

// ===== СТАТИСТИКА ПОЛЬЗОВАТЕЛЯ =====
$stats = $db->query("
  SELECT
    COUNT(*) as total,
    SUM(status = 2) as approved,
    SUM(CASE WHEN status = 2 THEN reward_usdt ELSE 0 END) as rewarded,
    SUM(status IN (0,1)) as pending
  FROM db_rewards_requests
  WHERE uid = '{$uid}'
")->fetchArray();

$stat_total    = (int)$stats['total'];
$stat_approved = (int)$stats['approved'];
$stat_rewarded = number_format((float)$stats['rewarded'], 2, '.', '');
$stat_pending  = (int)$stats['pending'];

$history = $db->query("
  SELECT *
  FROM db_rewards_requests
  WHERE uid = '{$uid}'
  ORDER BY id DESC
  LIMIT 20
")->fetchAll();

/* ===== ОБРАБОТКА ФОРМЫ ===== */
$form_msg = '';
$form_type = '';

if (isset($_POST['send_reward'])) {

  $type = $_POST['campaign'] ?? '';
  $url  = trim($_POST['content_url'] ?? '');

  if ($type !== 'youtube' && $type !== 'telegram') {
    $form_msg = 'Выберите тип контента';
    $form_type = 'err';
  }
  elseif ($url === '') {
    $form_msg = 'Введите ссылку на контент';
    $form_type = 'err';
  }
  else {

    $active = $db->query("
      SELECT id FROM db_rewards_requests
      WHERE uid='{$uid}' AND status IN (0,1)
      LIMIT 1
    ")->fetchArray();

    if ($active) {
      $form_msg = 'У вас уже есть активная заявка на проверке';
      $form_type = 'err';
    } else {

      $check = $time + 48 * 3600;
      $safe_url = htmlspecialchars($url, ENT_QUOTES);

      $db->query("
        INSERT INTO db_rewards_requests
        (uid, campaign_code, content_url, status, reward_usdt, created_at, check_available_at)
        VALUES
        ('{$uid}', '{$type}', '{$safe_url}', 0, 0, '{$time}', '{$check}')
      ");

      $form_msg = 'Заявка отправлена. Проверка до 48 часов.';
      $form_type = 'ok';
    }
  }
}
?>

<style>
:root{
  --bg:#0f141b;
  --card:#161d26;
  --card2:#1b2430;
  --border:rgba(255,255,255,.06);
  --text:#e6ebf2;
  --muted:#9aa4b2;
  --neon:#c9ff2f;
  --neon-glow:0 0 28px rgba(201,255,47,.4);
  --red:#ff5c5c;
}
body{background:var(--bg);}

.rew-page{max-width:1320px;margin:0 auto;padding:28px;color:var(--text);font-family:Inter,system-ui,sans-serif;}
.rew-head{display:flex;justify-content:space-between;margin-bottom:22px;}
.rew-title{font-size:32px;font-weight:800;}
.rew-desc{margin-top:6px;color:var(--muted);max-width:820px;}
.rew-rules-btn{background:transparent;border:1px solid var(--border);color:#fff;padding:9px 18px;border-radius:12px;cursor:pointer;}

.rew-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:18px;margin-bottom:26px;}
.rew-stat{background:linear-gradient(180deg,var(--card2),var(--card));border:1px solid var(--border);border-radius:18px;padding:20px;}
.rew-stat span{font-size:12px;color:var(--muted);}
.rew-stat b{display:block;font-size:36px;margin-top:8px;font-weight:800;}

.rew-main{display:grid;grid-template-columns:1fr 1fr;gap:26px;}
.rew-left{display:flex;flex-direction:column;gap:18px;}

.rew-campaign{background:linear-gradient(180deg,#1a2330,#141b24);border:1px solid var(--border);border-radius:20px;padding:22px;}
.rew-campaign h3{margin:0 0 14px;font-size:19px;}
.rew-rule{display:flex;gap:10px;margin:8px 0;font-size:14px;line-height:1.4;}
.rew-ok{color:var(--neon);}
.rew-no{color:var(--red);}

.rew-box{background:linear-gradient(180deg,var(--card2),var(--card));border:1px solid var(--border);border-radius:20px;padding:22px;}
.rew-select,.rew-input{width:100%;padding:15px 16px;border-radius:14px;border:1px solid var(--border);background:#0e141c;color:#fff;margin-bottom:14px;}
.rew-submit{
  width:100%;
  padding:16px;
  background:var(--neon);
  color:#000;                /* ← ВАЖНО */
  border:none;
  border-radius:16px;
  font-weight:900;
  cursor:pointer;
  box-shadow:var(--neon-glow);
}

.rew-alert{padding:14px;border-radius:14px;margin-bottom:14px;}
.rew-alert.ok{background:rgba(80,200,120,.15);color:#c9ff2f;}
.rew-alert.err{background:rgba(255,80,80,.15);color:#ff9a9a;}

.rew-modal-bg{display:none;position:fixed;inset:0;background:rgba(0,0,0,.75);z-index:9999;align-items:center;justify-content:center;}
.rew-modal{background:#10161f;border:1px solid var(--border);border-radius:20px;padding:26px;max-width:600px;width:92%;}
.rew-close{float:right;cursor:pointer;font-size:22px;}

@media(max-width:1100px){
  .rew-stats{grid-template-columns:repeat(2,1fr);}
  .rew-main{grid-template-columns:1fr;}
}
</style>
<style>
.camp-title{
  display:flex;
  align-items:center;
  gap:12px;
  font-size:18px;
  font-weight:800;
  margin-bottom:14px;
}

.camp-icon{
  width:34px;
  height:34px;
  display:flex;
  align-items:center;
  justify-content:center;
  border-radius:10px;
  background:rgba(255,255,255,.06);
}

.camp-icon svg{
  width:20px;
  height:20px;
  fill:#fff;
}

/* YouTube */
.camp-title.youtube .camp-icon{
  background:rgba(255,60,60,.15);
  box-shadow:0 0 14px rgba(255,60,60,.35);
}
.camp-title.youtube svg{
  fill:#ff4d4d;
}

/* Telegram */
.camp-title.telegram .camp-icon{
  background:rgba(60,160,255,.15);
  box-shadow:0 0 14px rgba(60,160,255,.35);
}
.camp-title.telegram svg{
  fill:#4da3ff;
}

.rew-history-head{
  display:flex;
  align-items:center;
  justify-content:space-between;
}

.rew-history-count{
  min-width:26px;
  height:26px;
  padding:0 8px;
  border-radius:50px;
  background:rgba(255,255,255,.08);
  color:#fff;
  font-size:13px;
  font-weight:700;
  display:flex;
  align-items:center;
  justify-content:center;
}

/* ===== МОБИЛЬНАЯ АДАПТАЦИЯ СТАТИСТИКИ ===== */
@media (max-width: 600px){

  /* контейнер статистики → список */
  .rew-stats{
    grid-template-columns: 1fr;
    gap: 10px;
  }

  /* каждая карточка → строка */
  .rew-stat{
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:14px 16px;
  }

  /* текст слева */
  .rew-stat span{
    font-size:13px;
    opacity:.85;
  }

  /* число справа */
  .rew-stat b{
    font-size:22px;
    margin:0;
  }

  /* подпись под числом убираем перенос */
  .rew-stat{
    flex-wrap:nowrap;
  }

  /* текст "Заявки / Награждено / Сумма бонуса / На проверке"
     ставим в одну строку */
  .rew-stat > *{
    white-space:nowrap;
  }
}

/* ===== ЧИСЛО В ПРАВОМ ВЕРХНЕМ УГЛУ КАРТОЧКИ ===== */
.rew-stat{
  position: relative;
  padding-top: 26px; /* место под число */
}

/* само число */
.rew-stat b{
  position: absolute;
  top: 24px;
  right: 18px;
  font-size: 26px;
  font-weight: 900;
  margin: 0;
  line-height: 1;
}

/* текст снизу */
.rew-stat span{
  display: block;
  font-size: 12px;
  color: var(--muted);
}

/* подпись под карточкой */
.rew-stat{
  font-size: 15px;
}

@media (max-width: 600px){
  .rew-stat b{
    font-size: 22px;
    top: 14px;
    right: 14px;
  }
}

</style>
<div class="container mx-auto mt-3 px-4">

    <div class="mb-6 bg-gray-800 rounded-md shadow-md">
        <h1 class="text-center text-2xl font-bold text-white py-3 ">
            Награды
        </h1>
		<div class="text-center" class="rew-desc">Размещайте контент о проекте в YouTube или Telegram и получайте вознаграждение.</div>
    </div> 

  <div class="rew-head">
    <div>
    </div>
    <!--<button class="rew-rules-btn" id="openRules">Правила</button>-->
  </div>

  <?php if($form_msg): ?>
    <div class="rew-alert <?=$form_type?>"><?=$form_msg?></div>
  <?php endif; ?>

  <div class="rew-stats">
    <div class="rew-stat"><span>🔄 ВСЕГО</span><b><?=$stat_total?></b></div>
    <div class="rew-stat"><span>✅ ОДОБРЕНО</span><b><?=$stat_approved?></b></div>
    <div class="rew-stat"><span>⚡ НАЧИСЛЕНО</span><b>+<?=$stat_rewarded?></b></div>
    <div class="rew-stat"><span>⏳ ОЖИДАНИЕ</span><b><?=$stat_pending?></b></div>
  </div>

  <div class="rew-main">

    <div class="rew-left">
      <div class="rew-campaign">
        <h3 class="camp-title youtube">
  <span class="camp-icon">
    <!-- YouTube SVG -->
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M23.5 6.2s-.2-1.6-.9-2.3c-.8-.9-1.7-.9-2.1-1C17.4 2.5 12 2.5 12 2.5h0s-5.4 0-8.5.4c-.4.1-1.3.1-2.1 1C.7 4.6.5 6.2.5 6.2S0 8.1 0 10v1.9c0 1.9.5 3.8.5 3.8s.2 1.6.9 2.3c.8.9 1.9.9 2.4 1 1.7.2 7.2.4 7.2.4s5.4 0 8.5-.4c.4-.1 1.3-.1 2.1-1 .7-.7.9-2.3.9-2.3s.5-1.9.5-3.8V10c0-1.9-.5-3.8-.5-3.8zM9.8 13.8V7.8l6.2 3-6.2 3z"/>
    </svg>
  </span>
  YouTube Кампания
</h3>
        <div class="rew-rule rew-ok">⏱ Проверка до 48 часов</div>
		</h4>✅ Требования</h4>
		<div class="rew-rule rew-ok">✔️Минимум 500 подписчиков</div>
        <div class="rew-rule rew-ok">✔️Разрешение минимум 720p</div>
        <div class="rew-rule rew-ok">✔️Публичный канал и видео</div>
		<div class="rew-rule rew-ok">✔️Высокое качество видео и звука</div>
		</h4>⛔ Правила</h4>
		<div class="rew-rule rew-no">🚫Не чаще 1 раза в 7 дней</div>
		<div class="rew-rule rew-no">🚫Без накрутки просмотров и ботов</div>
      </div>

      <div class="rew-campaign">
        <h3 class="camp-title telegram">
  <span class="camp-icon">
    <!-- Telegram SVG -->
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M22.5 2.4L1.9 10.4c-1.4.6-1.4 1.5-.3 1.9l5.3 1.7 2 6c.2.5.4.7.7.7.3 0 .5-.2.8-.5l2.9-2.8 6 4.4c1.1.6 1.9.3 2.2-1L24 4.4c.4-1.6-.6-2.3-1.5-2zM9.1 14.5l-.3 3.1-1.9-5.9 11.6-7.1"/>
    </svg>
  </span>
  Telegram Кампания
</h3>
        <div class="rew-rule rew-ok">⏱ Проверка до 48 часов</div>
        </h4>✅ Требования</h4>
		<div class="rew-rule rew-ok">✔️Минимум 500 подписчиков</div>
        <div class="rew-rule rew-ok">✔️Только посты в каналах (без групп)</div>
        <div class="rew-rule rew-ok">✔️Публичный канал</div>
		</h4>⛔ Правила</h4>
		<div class="rew-rule rew-no">🚫Не чаще 1 раза в 7 дней</div>
		<div class="rew-rule rew-no">🚫Без накрутки и ботов</div>
      </div>
    </div>

    <div>
      <div class="rew-box">
        <h3>Отправка контента</h3>
        <form method="post">
          <select class="rew-select" name="campaign" required>
            <option value="youtube">🎬 YouTube</option>
            <option value="telegram">✈️ Telegram</option>
          </select>
          <input class="rew-input" name="content_url" placeholder="Введите ссылку" required>
          <button class="rew-submit" type="submit" name="send_reward">Отправить контент</button>
        </form>
      </div>
	  <br>
	  <div class="rew-box rew-history">
  <div class="rew-history-head">
    <h3>🔄 История</h3>
    <span class="rew-history-count"><?=$history_count?></span>
  </div>
<br>
  <?php if(!$history): ?>
    <div class="rew-empty">Истории пока нет.</div>
  <?php else: ?>
    <?php foreach($history as $h): ?>
      <?php
        $status = (int)$h['status'];
        if ($status === 0) {
          $st = 'Проверка (48 часов)';
          $cl = '#f6d365';
        } elseif ($status === 1) {
          $st = 'Ожидает решения администратора';
          $cl = '#6fb1ff';
        } elseif ($status === 2) {
          $st = 'Одобрено';
          $cl = '#7dff7a';
        } else {
          $st = 'Отклонено';
          $cl = '#ff7a7a';
        }
      ?>
      <div style="
        padding:12px;
        border-radius:12px;
        margin-bottom:10px;
        background:#0e141c;
        border:1px solid rgba(255,255,255,.06);
      ">
        <div style="font-size:13px;opacity:.8">
          <?=date('d.m.Y H:i', $h['created_at'])?>
        </div>
        <div style="margin-top:4px">
          Тип: <b><?=htmlspecialchars($h['campaign_code'])?></b>
        </div>
        <div>
  Статус:
  <?php if ($status === 0): ?>
    <b style="color:#f6d365"
       class="hist-timer"
       data-end="<?=$h['check_available_at']?>">
       Проверка — 48:00:00
    </b>
  <?php else: ?>
    <b style="color:<?=$cl?>"><?=$st?></b>
  <?php endif; ?>
</div>
        <div>
          Ссылка:
          <a href="<?=htmlspecialchars($h['content_url'])?>" target="_blank" style="color:#8fc6ff">
            открыть
          </a>
        </div>
        <?php if($status === 2): ?>
          <div>
            Начислено: <b>+<?=number_format($h['reward_usdt'],2)?> RUB</b>
          </div>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

    </div>

  </div>
</div>

<div class="rew-modal-bg" id="rulesModal">
  <div class="rew-modal">
    <span class="rew-close" id="closeRules">×</span>
    <h3>Правила участия</h3>
    <ul>
      <li>Контент должен быть публичным</li>
      <li>Запрещено удалять контент 48 часов</li>
      <li>Запрещены накрутки и боты</li>
      <li>1 заявка раз в 7 дней</li>
    </ul>
  </div>
</div>

<script>
openRules.onclick=()=>rulesModal.style.display='flex';
closeRules.onclick=()=>rulesModal.style.display='none';
</script>
<script>
document.querySelectorAll('.hist-timer').forEach(el => {

  const end = parseInt(el.dataset.end, 10);

  function tick(){
    const now = Math.floor(Date.now() / 1000);
    let diff = end - now;

    if (diff <= 0) {
      el.textContent = 'Проверка завершена';
      return;
    }

    const h = String(Math.floor(diff / 3600)).padStart(2,'0');
    const m = String(Math.floor((diff % 3600) / 60)).padStart(2,'0');
    const s = String(diff % 60).padStart(2,'0');

    el.textContent = `Проверка — ${h}:${m}:${s}`;
  }

  tick();
  setInterval(tick, 1000);
});
</script>

