<?php if(!defined('FastCore')){ exit('Oops!'); }
$opt['title'] = 'Мои ссылки';
?>

<!-- Header -->
<div class="container mx-auto mt-3 px-4">
  
    <div class="mb-6 bg-gray-800 rounded-md shadow-md">
      <h1 class="text-center text-2xl font-bold text-white py-3 ">
       {!TITLE!}
      </h1>
    </div> 

<!-- Меню навигации -->
<div class="flex flex-col md:flex-row justify-center items-center md:space-x-4 space-y-3 md:space-y-0 mb-6">
  <a href="/user/surfing" class="bg-blue-600 hover:bg-blue-700 text-white uppercase font-semibold px-4 py-2 rounded flex items-center text-sm w-full md:w-auto justify-center">
    <i class="bi bi-mouse2-fill mr-2"></i> Сёрфинг
  </a>
  <a href="/user/surf/add" class="bg-blue-600 hover:bg-blue-700 text-white uppercase font-semibold px-4 py-2 rounded flex items-center text-sm w-full md:w-auto justify-center">
    <i class="bi bi-plus-lg mr-2"></i> Добавить
  </a>
  <a href="/user/surf/links" class="bg-blue-600 hover:bg-blue-700 text-white uppercase font-semibold px-4 py-2 rounded flex items-center text-sm w-full md:w-auto justify-center">
    <i class="bi bi-link-45deg mr-2"></i> Мои ссылки
  </a>
</div>

<?php
$numb =  $db->query("SELECT * FROM `db_surf` WHERE uid = '$uid'")->numRows();
if($numb < 1) {
  echo '<div class="bg-red-800 text-red-100 text-center py-2 px-4 rounded">Вы еще не добавили серфинг</div>';
}
?>

<?php
$list = $db->query("SELECT * FROM `db_surf` WHERE uid = '$uid' ORDER BY id DESC")->fetchAll();
foreach ($list as $surf) {
    $eye = round($surf['balance'] / $surf['price_click'], 0);
?>
<div class="bg-gray-800 bg-opacity-60 text-white rounded-lg shadow-lg mb-4 p-4" id="surf_<?= $surf['id']; ?>">
  <div class="bg-gray-900 text-white font-semibold px-4 py-2 border-b rounded-t">
    <span class="mr-2" title="Серфинг #<?=$surf['id'];?>">#<?=$surf['id'];?></span>
    <a href="<?=$surf['url'];?>" target="_blank" class="hover:text-yellow-400">
      <?=$surf['title'];?>
    </a>
  </div>

  <div class="p-4 bg-gray-900 rounded-b">
    <div class="grid grid-cols-2 md:grid-cols-4 text-center mb-3 text-sm">
      <div>Баланс:<br><strong><?=$surf['balance'];?> ₽</strong></div>
      <div>Переходов:<br><strong><?=$surf['views'];?></strong></div>
      <div>Осталось:<br><strong><?=$eye;?></strong></div>
      <div>Цена:<br><strong><?=$surf['price_click'];?> ₽</strong></div>
    </div>

    <div class="grid grid-cols-2 md:grid-cols-4 gap-2 mb-3">
      <button onclick="document.getElementById('bl_bal<?=$surf['id'];?>').classList.toggle('hidden');" class="bg-green-600 hover:bg-green-700 text-white py-2 rounded">
        Пополнить
      </button>

      <form method="POST">
        <?php if($surf['status'] == '1'): ?>
          <button class="bg-blue-500 hover:bg-blue-600 text-white w-full py-2 rounded status_surf" type="button" action="2" surf_id="<?=$surf['id'];?>">
            Остановить
          </button>
        <?php else: ?>
          <button class="bg-blue-500 hover:bg-blue-600 text-white w-full py-2 rounded status_surf" type="button" action="1" surf_id="<?=$surf['id'];?>">
            Запустить
          </button>
        <?php endif; ?>
      </form>

      <form method="POST">
        <button type="button" class="bg-red-600 hover:bg-red-700 text-white w-full py-2 rounded delete" surf_id="<?=$surf['id'];?>">
          Удалить
        </button>
      </form>

      <form method="POST" action="/user/surf/edit">
        <input type="hidden" name="surf_id" value="<?=$surf['id'];?>">
        <button type="submit" class="bg-gray-700 hover:bg-gray-800 text-white w-full py-2 rounded">
          Редактировать
        </button>
      </form>
    </div>

    <div class="hidden mt-3" id="bl_bal<?=$surf['id'];?>">
      <div class="bg-gray-700 p-4 rounded">
        <div class="text-center text-lg font-medium mb-3">Переходов: <span id="count<?=$surf['id'];?>">0</span></div>
        <form method="POST" class="balance_add">
          <div class="flex items-center gap-2">
            <input type="hidden" name="surf_id" value="<?=$surf['id']; ?>">
            <input type="hidden" id="type" value="add_balance">
            <input type="text" class="flex-1 p-2 rounded bg-gray-800 text-white placeholder-gray-400" name="money" placeholder="Мин/1 RUB" autocomplete="off" onkeyup="f_calc(<?=$surf['id'];?>,<?=$surf['price_click'];?>);" id="f_sum<?=$surf['id'];?>">
            <button class="bg-white text-gray-900 font-bold px-4 py-2 rounded">Пополнить</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php } ?>

<script>
function f_calc(id, price){
  var val = Number(document.getElementById("f_sum" + id).value);
  document.getElementById("count" + id).innerHTML = (val / price).toFixed(0);
}
</script>
</div>
