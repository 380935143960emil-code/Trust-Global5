<?php if(!defined('FastCore')){exit('Oops!');}

$opt['title'] = 'Добавление серфинга';
$configSurf = $db->query("SELECT * FROM `db_surf_config` WHERE id = 1")->fetchArray();
$timerr = $configSurf['timer'];
$timer = array($timerr, $timerr*2, $timerr*3, $timerr*4, $timerr*5, $timerr*6);
?>

<!-- Header -->
<div class="container mx-auto mt-3 px-4">
  
    <div class="mb-6 bg-gray-800 rounded-md shadow-md">
      <h1 class="text-center text-2xl font-bold text-white py-3 ">
       {!TITLE!}
      </h1>
    </div> 
 
<script>
  // Определим значения
  var bux_price = <?=$configSurf['price_click']; ?>;
  var bux_price_timer = <?=$configSurf['timer_pay']; ?>;
  var bux_price_high = <?=$configSurf['wind']; ?>;

  // Функция для вычисления стоимости в зависимости от выбранных опций
  function PlanChange(frm) {
    let lprice = bux_price;

    // Учитываем активное окно
    if (frm.wind.value == 1) {
      lprice += bux_price_high;
    }

    // Учитываем таймер
    switch (frm.timer.value) {
      case '10':
        lprice += bux_price_timer;
        break;
      case '20':
        lprice += bux_price_timer * 2;
        break;
      case '30':
        lprice += bux_price_timer * 3;
        break;
      case '40':
        lprice += bux_price_timer * 4;
        break;
      case '50':
        lprice += bux_price_timer * 5;
        break;
      case '60':
        lprice += bux_price_timer * 6;
        break;
    }

    // Обновляем поле с ценой
    frm.linkprice.value = number_format(lprice, 2, '.', '');
  }

  // Функция для форматирования числа
  function number_format(number, decimals, dec_point, thousands_sep) {
    var i, j, kw, kd, km;
    if (isNaN(decimals = Math.abs(decimals))) {
      decimals = 2;
    }
    if (dec_point === undefined) {
      dec_point = ",";
    }
    if (thousands_sep === undefined) {
      thousands_sep = ".";
    }

    i = parseInt(number = (+number || 0).toFixed(decimals)) + "";
    if ((j = i.length) > 3) {
      j = j % 3;
    } else {
      j = 0;
    }

    km = (j ? i.substr(0, j) + thousands_sep : "");
    kw = i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands_sep);
    kd = (decimals ? dec_point + Math.abs(number - i).toFixed(decimals).replace(/-/, 0).slice(2) : "");
    
    return km + kw + kd;
  }

  // Функция очистки формы
  function ClearForm() {
    let form = document.forms['surforder'];
    form.timer.value = <?=$configSurf['timer']; ?>;
    form.wind.value = 0;
    PlanChange(form);
  }

  // Инициализация
  $(document).ready(function() {
    ClearForm();
  });
</script>

<!-- Меню навигации -->
<div class="flex flex-col md:flex-row justify-center items-center md:space-x-4 space-y-3 md:space-y-0 mb-6">
  <a href="/user/surfing" class="bg-blue-600 hover:bg-blue-700 text-white uppercase font-semibold px-4 py-2 rounded flex items-center text-sm w-full md:w-auto justify-center">
    <i class="bi bi-mouse2-fill mr-2"></i> Сёрфинг
  </a>
  <a href="/user/surf/add" class="bg-blue-600 hover:bg-blue-700 text-white uppercase font-semibold px-4 py-2 rounded flex items-center text-sm w-full md:w-auto justify-center">
    <i class="bi bi-plus-lg mr-2"></i> Добавить
  </a>
  <a href="/user/surf/links" class="bg-blue-600 hover:bg-blue-700 text-white uppercase font-semibold px-4 py-2 rounded flex items-center text-sm w-full md:w-auto justify-center">
    <i class="bi bi-link-45deg mr-2"></i> Мои ссылки
  </a>
</div>

<!-- Форма -->
<div class="bg-gray-900 text-white shadow-md rounded px-6 pt-3 pb-6">
   
  <form name="surforder" method="POST" id="surf_add" class="space-y-4">
    <?php $func->csrf(); ?>

    <!-- Название -->
    <div>
      <label class="block text-sm font-medium mb-1">Название ссылки</label>
      <div class="flex items-center border border-gray-700 rounded bg-gray-800">
        <span class="px-3 text-gray-400"><i class="bi bi-pencil-fill"></i></span>
        <input type="text" name="title" id="title" class="flex-1 px-3 py-2 bg-gray-800 text-white focus:outline-none" placeholder="Название вашей ссылки" required>
      </div>
    </div>

    <!-- URL -->
    <div>
      <label class="block text-sm font-medium mb-1">URL</label>
      <div class="flex items-center border border-gray-700 rounded bg-gray-800">
        <span class="px-3 text-gray-400"><i class="bi bi-link-45deg"></i></span>
        <input type="url" name="url" id="url" class="flex-1 px-3 py-2 bg-gray-800 text-white focus:outline-none" placeholder="https://example.com" required>
      </div>
    </div>

    <!-- Таймер -->
    <div>
      <label class="block text-sm font-medium mb-1">Таймер</label>
      <div class="flex items-center border border-gray-700 rounded bg-gray-800">
        <span class="px-3 text-gray-400"><i class="bi bi-clock-fill"></i></span>
        <select name="timer" id="timer" class="flex-1 px-3 py-2 bg-gray-800 text-white focus:outline-none" onChange="PlanChange(this.form);" required>
          <?php
          $priceTimer = 0;
          foreach ($timer as $surf) {
              $priceTimer += $configSurf['timer_pay'];
              echo "<option value=\"$surf\">$surf секунд (+ $priceTimer руб.)</option>";
          }
          ?>
        </select>
      </div>
    </div>

    <!-- Опции -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <!-- Активное окно -->
      <div>
        <label class="block text-sm font-medium mb-1">Активное окно</label>
        <div class="flex items-center border border-gray-700 rounded bg-gray-800">
          <span class="px-3 text-gray-400"><i class="bi bi-display"></i></span>
          <select name="wind" id="wind" class="flex-1 px-3 py-2 bg-gray-800 text-white focus:outline-none" onChange="PlanChange(this.form);">
            <option value="0">Нет</option>
            <option value="1">Да (+ <?=$configSurf['wind'];?> руб.)</option>
          </select>
        </div>
      </div>
 
      <!-- Повтор -->
      <div>
        <label class="block text-sm font-medium mb-1">Период повтора</label>
        <div class="flex items-center border border-gray-700 rounded bg-gray-800">
          <span class="px-3 text-gray-400"><i class="bi bi-arrow-counterclockwise"></i></span>
          <select name="reply" id="reply" class="flex-1 px-3 py-2 bg-gray-800 text-white focus:outline-none">
            <option value="0">Каждые 24 часа</option>
            <option value="1">Каждые 12 часов</option>
          </select>
        </div>
      </div>
    </div>

    <!-- Footer -->
    <div class="flex justify-between items-center mt-6 flex-wrap">
      <div class="mb-3 sm:mb-0">
        <input type="hidden" name="add">
        <input type="hidden" name="type" id="type" value="add">
        <input type="hidden" name="request" value="/ajax.php?action=surf&type=add">
        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded text-lg">
          Добавить ссылку
        </button>
      </div>
      <div class="text-right w-full sm:w-auto">
        <label class="block text-sm font-medium mb-1">Цена 1 перехода:</label>
        <div class="flex items-center border border-gray-700 rounded px-3 py-2 bg-gray-800 font-bold text-xl text-green-400">
          <i class="bi bi-currency-ruble mr-2"></i>
          <input readonly name="linkprice" value="<?= $configSurf['price_click'] + $configSurf['timer_pay']; ?>" class="bg-transparent border-none focus:outline-none w-full text-right text-green-400">
        </div>
      </div>
    </div>
  </form>
</div>
 