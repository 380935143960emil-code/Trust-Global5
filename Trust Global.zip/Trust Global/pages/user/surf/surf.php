<?php if (!defined('FastCore')) { exit('Oops!'); }
$opt['title'] = 'Серфинг сайтов';
$time = time();
?>

<!-- Header -->
<div class="container mx-auto mt-3 px-4">

<!-- Блок капчи -->
<div id="captcha-block" class="captcha-card neon-card">
  <h2 class="captcha-title">🔒 Проверка</h2>
  <p>Для просмотра серфинга, пожалуйста, пройдита проверку на робота!</p>
  <button id="captcha-btn" class="captcha-btn neon-btn">
    Кликни сюда (<span id="max-clicks">5</span> раз)
  </button>
  <p class="captcha-text">Клики: <span id="click-count">0</span></p>
</div>

<!-- Блок с чекбоксом и кнопкой "Далее" -->
<div id="after-captcha" class="captcha-card neon-card" style="display:none;">
  <h2 class="captcha-title">✅ Подтверждение</h2>
  <div class="captcha-checkbox">
    <label>
      <input type="checkbox" id="check-confirm" disabled>
      Подтверждаю, что я сделал всё правильно
    </label>
  </div>
  <button id="continue-btn" class="continue-btn neon-btn" disabled>
    Далее 🚀
  </button>
</div>

<style>
  body {
    font-family: 'Trebuchet MS', sans-serif;
    background: radial-gradient(circle at top, #1a1a2e, #0f0f1e);
    color: #fff;
  }

  .captcha-card {
    max-width: 420px;
    margin: 50px auto;
    padding: 25px 30px;
    text-align: center;
    background: rgba(20, 20, 35, 0.85);
    border-radius: 15px;
    box-shadow: 0 0 15px rgba(0, 200, 255, 0.3);
    position: relative;
    overflow: hidden;
  }

  .neon-card::before {
    content: "";
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: conic-gradient(#00f2ff, #8e44ad, #ff0080, #00f2ff);
    animation: spin 6s linear infinite;
    z-index: 0;
    opacity: 0.3;
  }

  .neon-card > * {
    position: relative;
    z-index: 1;
  }

  @keyframes spin {
    100% { transform: rotate(360deg); }
  }

  .captcha-title {
    margin-bottom: 20px;
    font-size: 22px;
    font-weight: bold;
    text-shadow: 0 0 10px #00eaff, 0 0 20px #ff00f7;
  }

  .neon-btn {
    background: linear-gradient(135deg, #00f2ff, #007bff);
    color: #fff;
    padding: 14px 28px;
    font-size: 17px;
    font-weight: bold;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    transition: transform 0.25s, box-shadow 0.25s;
    box-shadow: 0 0 12px rgba(0, 242, 255, 0.6), 0 0 24px rgba(0, 242, 255, 0.3);
  }

  .neon-btn:hover:not(:disabled) {
    transform: scale(1.05);
    box-shadow: 0 0 20px rgba(0, 242, 255, 0.9), 0 0 40px rgba(255, 0, 200, 0.6);
  }

  .neon-btn:disabled {
    background: #555;
    color: #aaa;
    box-shadow: none;
    cursor: not-allowed;
  }

  .captcha-text {
    margin-top: 15px;
    font-size: 16px;
    color: #ccc;
    text-shadow: 0 0 8px #00eaff;
  }

  /* Анимация для числа */
  #click-count {
    display: inline-block;
    font-weight: bold;
    color: #00eaff;
    transition: transform 0.2s ease, color 0.2s ease;
  }

  #click-count.bump {
    transform: scale(1.5);
    color: #ff00ff;
    text-shadow: 0 0 12px #ff00ff, 0 0 20px #00eaff;
  }

  /* Анимация кнопки */
  .captcha-btn.bounce {
    animation: bounce 0.3s ease;
  }

  @keyframes bounce {
    0% { transform: scale(1); }
    30% { transform: scale(0.9); }
    60% { transform: scale(1.1); }
    100% { transform: scale(1); }
  }

  .captcha-checkbox {
    margin: 20px 0;
    font-size: 15px;
    color: #ddd;
    text-align: left;
  }
</style>



  
  <!-- Контент скрыт изначально -->
  <div id="content" style="display:none;">
    <!-- Ваш существующий код начинается здесь -->
    <div class="mb-6 bg-gray-800 rounded-md shadow-md">
      <h1 class="text-center text-2xl font-bold text-white py-3 ">
       {!TITLE!}
      </h1>
    </div> 
    <!-- Блок информации и бонусов -->
    <!--<div class="bg-gray-800 text-white p-6 rounded-lg shadow-md mb-6"> 
        <div class=" ">
            <strong class="block mb-1 text-yellow-400">Хотите больше прибыли?</strong>
            Покупайте <span class="font-semibold text-green-600">VIP</span> и получайте <span class="font-semibold">x2 серфинг!
        </div>
    </div> -->
	<div class="mb-5" style="display: flex; justify-content: center;">
      <a href="https://kupx.site" target="_blank"><img src="https://kupx.site/img/promo/468.gif"/></a>
    </div>  
<!-- Меню навигации -->
<div class="flex flex-col md:flex-row justify-center items-center md:space-x-4 space-y-3 md:space-y-0 mb-6">
  <a href="/user/surfing" class="bg-blue-600 hover:bg-blue-700 text-white uppercase font-semibold px-4 py-2 rounded flex items-center text-sm w-full md:w-auto justify-center">
    <i class="bi bi-mouse2-fill mr-2"></i> Сёрфинг
  </a>
  <a href="/user/surf/add" class="bg-blue-600 hover:bg-blue-700 text-white uppercase font-semibold px-4 py-2 rounded flex items-center text-sm w-full md:w-auto justify-center">
    <i class="bi bi-plus-lg mr-2"></i> Добавить
  </a>
  <a href="/user/surf/links" class="bg-blue-600 hover:bg-blue-700 text-white uppercase font-semibold px-4 py-2 rounded flex items-center text-sm w-full md:w-auto justify-center">
    <i class="bi bi-link-45deg mr-2"></i> Мои ссылки
  </a>
</div>
<script>
  function showFrame(card, link) {
    window.open('/view/' + link, '_blank');

    card.classList.add("opacity-40", "pointer-events-none", "grayscale");

    const overlay = document.createElement('div');
    overlay.className = "absolute inset-0 bg-black/70 flex items-center justify-center rounded-xl z-10";
    overlay.innerHTML = '<span class="text-white text-sm font-semibold tracking-wider">ПРОСМОТРЕНО</span>';
    card.appendChild(overlay);
  }
</script>

<?php
$rowViews = $db->query('SELECT link, uid FROM db_surf_views WHERE uid = ' . $uid . ' AND time_end > ' . time())->fetchAll();
$visitss = array_column($rowViews, null, 'link');

// Получаем все ссылки
$allLinks = $db->query("SELECT * FROM db_surf WHERE `balance` >= `price_click` and `status` = '1' ORDER BY price_click DESC, balance DESC")->fetchAll();

// Разделяем на просмотренные и не просмотренные
$available = [];
$viewedList = [];

foreach ($allLinks as $surf) {
    $viewed = isset($visitss[$surf['id']]);
    if ($viewed) {
        $viewedList[] = $surf;
    } else {
        $available[] = $surf;
    }
}

$finalList = array_merge($available, $viewedList);
$is = 0;

foreach ($finalList as $surf) {
    $viewed = isset($visitss[$surf['id']]);
    $eye = $surf['balance'] / $surf['price_click'];
    $cardClass = $viewed ? 'opacity-40 grayscale pointer-events-none' : '';

    $wind = ($surf['wind'] != 0) 
      ? '<span class="inline-flex items-center text-sm text-gray-400"><i class="bi bi-display ml-2"></i></span>' 
      : '';
      $uvip = $user['is_vip'];
?>

<div onclick="showFrame(this, '<?= $surf['id']; ?>')" class="relative cursor-pointer surf-card bg-gray-800/50 border border-gray-700 shadow-lg rounded-xl p-4 mb-4 backdrop-blur-md transition duration-300 hover:scale-[1.01] <?= $cardClass; ?>">

  <?php if ($viewed): ?>
    <div class="absolute inset-0 bg-black/80 flex items-center justify-center rounded-xl z-10">
      <span class="text-white font-semibold tracking-wider text-2xl">ПРОСМОТРЕНО</span>
    </div>
  <?php endif; ?>

  <div class="flex flex-col md:flex-row justify-between items-start gap-4 text-center md:text-left relative z-0">
    
    <!-- Левая часть -->
    <div class="flex flex-col items-center md:items-start gap-2 w-full">
      <div class="flex items-center gap-2">
        <img src="https://www.google.com/s2/favicons?domain=<?= $surf['url']; ?>" alt="icon" class="w-5 h-5">
        <span class="text-lg font-semibold text-white"><?= $surf['title']; ?></span>
      </div>

      <div class="flex justify-start flex-wrap w-full text-sm text-gray-400 mt-1">
        <div class="w-full sm:w-1/4">Серфинг: <strong>#<?= $surf['id']; ?></strong></div>
        <div class="w-full sm:w-1/4">Таймер: <strong><?= $surf['timer']; ?> сек.</strong></div>
        <div class="w-full sm:w-1/4">Осталось: <strong><?= sprintf("%.0f", $eye); ?> <i class="fa fa-eye"></i></strong></div>
        <div class="w-full sm:w-1/4"><?= $wind; ?></div>
      </div>
    </div>

    <!-- Цена -->
    <div class="flex justify-center md:justify-end items-center md:w-auto w-full text-center pb-0">
      <div class="bg-blue-700 text-white text-3xl font-semibold px-4 py-4 pb-3 rounded-md shadow-inner">
        <?php
                                        $price = $surf['per_click'];
                                        if ($uvip == 1) {
                                            $price *= 2;
                                        }
                                        echo number_format($price, 2, '.', '');
                                    ?>
      </div>
    </div>
  </div>
</div>

<?php
    $is++;
}

if ($is === 0) {
    echo '<div class="bg-red-600/80 text-white text-center py-3 px-4 rounded-xl shadow-lg">Нету ссылок для просмотра!</div>';
}
?>
</div>
<!-- Скрипт капчи и переключения контента -->
<script>
  // Генерируем случайное число кликов
  const maxClicksSpan = document.getElementById('max-clicks');
  const clickCountSpan = document.getElementById('click-count');
  const btn = document.getElementById('captcha-btn');
  const captchaBlock = document.getElementById('captcha-block');
  const afterCaptchaDiv = document.getElementById('after-captcha');
  const checkBox = document.getElementById('check-confirm');
  const continueBtn = document.getElementById('continue-btn');

  const minClicks = 1;
  const maxClicks = Math.floor(Math.random() * 10) + 1; // случайное число от 1 до 10
  maxClicksSpan.innerText = maxClicks;

  let currentClicks = 0;

  // Обработка кликов по кнопке капчи
  btn.addEventListener('click', () => {
    if (currentClicks < maxClicks) {
      currentClicks++;
      clickCountSpan.innerText = currentClicks;
      if (currentClicks >= maxClicks) {
        // После достижения нужного количества показываем чекбокс и кнопку "Далее"
        captchaBlock.style.display = 'none';
        document.getElementById('after-captcha').style.display = 'block';
        // Разрешаем чекбокс
        checkBox.disabled = false;
      }
    } else {
      alert('Вы уже достигли нужного количества кликов.');
    }
  });

  // Обработка чекбокса "Проверено"
  document.getElementById('check-confirm').addEventListener('change', () => {
    document.getElementById('continue-btn').disabled = !checkBox.checked;
  });

  // Нажатие на кнопку "Далее"
  document.getElementById('continue-btn').addEventListener('click', () => {
    document.getElementById('after-captcha').style.display = 'none';
    document.getElementById('content').style.display = 'block';
  });
</script>