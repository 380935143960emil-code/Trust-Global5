<?php if(!defined('FastCore')){exit('Oops!');}

$opt['title'] = 'Вывод средства';

 
?>
     <div class="container mx-auto mt-3 px-4 max-w-4xl">
  
  <!-- Заголовок -->
  <div class="mb-6 relative">
    <div class="absolute inset-0 bg-red-500/10 blur-3xl rounded-full"></div>
    <h1 class="relative text-center text-2xl font-bold text-white py-4">
      <span class="bg-gradient-to-r from-red-400 to-orange-400 bg-clip-text text-transparent">{!TITLE!}</span>
    </h1>
    <div class="w-24 h-1 bg-gradient-to-r from-transparent via-red-400 to-transparent mx-auto mt-2 rounded-full"></div>
  </div>

  <!-- Инфо-блок -->
  <div class="glass-card rounded-2xl p-6 mb-8 border border-red-400/10 relative overflow-hidden group">
    <div class="absolute top-0 right-0 w-32 h-32 bg-red-400/5 rounded-full blur-3xl group-hover:bg-red-400/10 transition-all duration-500"></div>
    
    <div class="flex items-start gap-4 relative z-10">
      <div class="w-12 h-12 rounded-xl bg-red-400/10 flex items-center justify-center flex-shrink-0">
        <i class="bi bi-arrow-up-circle text-red-400 text-xl"></i>
      </div>
      <div>
        <h3 class="text-white font-semibold mb-2 flex items-center gap-2">
          Вывод средств
          <span class="px-2 py-0.5 bg-red-400/20 text-red-400 text-[10px] rounded-full border border-red-400/20">Secure</span>
        </h3>
        <p class="text-gray-400 text-sm mb-3">Доступные платёжные системы: FaucetPay, Azvox</p>
        <div class="flex items-center gap-2 text-xs text-gray-500">
          <i class="bi bi-shield-check text-lime-400"></i>
          <span>Выберите удобный метод вывода ниже</span>
        </div>
      </div>
    </div>
  </div>

  <!-- Сетка платёжных систем -->
  <div class="grid grid-cols-1 md:grid-cols-2 gap-4">

    <!-- FaucetPay -->
    <a href="/user/pap" class="group relative">
      <div class="absolute inset-0 bg-gradient-to-r from-[#3498db]/20 to-[#2980b9]/20 rounded-2xl blur opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
      
      <div class="glass-card rounded-2xl p-5 border border-white/5 hover:border-[#3498db]/30 transition-all duration-300 relative overflow-hidden group-hover:transform group-hover:scale-[1.02]">
        
        <div class="absolute inset-0 bg-gradient-to-br from-[#3498db]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        
        <div class="flex items-center gap-4 relative z-10">
          <!-- Иконка -->
          <div class="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#3498db]/20 to-[#2980b9]/10 border border-[#3498db]/20 flex items-center justify-center group-hover:shadow-[0_0_30px_rgba(52,152,219,0.3)] transition-all duration-300">
            <img src="/img/faucetpay.png" class="w-10 h-10 object-contain group-hover:scale-110 transition-transform duration-300" alt="FaucetPay">
          </div>
          
          <!-- Информация -->
          <div class="flex-1">
            <div class="flex items-center gap-2 mb-1">
              <span class="text-lg font-bold text-white group-hover:text-[#3498db] transition-colors">FaucetPay</span>
              <span class="px-2 py-0.5 bg-lime-400/20 text-lime-400 text-[10px] font-bold rounded-full border border-lime-400/30">0%</span>
            </div>
            
            <div class="space-y-1">
              <div class="flex items-center gap-2 text-sm text-gray-400">
                <i class="bi bi-lightning-charge-fill text-lime-400 text-xs"></i>
                <span>Мгновенный вывод</span>
              </div>
              <div class="flex items-center gap-2 text-sm text-gray-400">
                <i class="bi bi-currency-dollar text-lime-400 text-xs"></i>
                <span>От: <span class="text-white font-semibold">1 USDT</span></span>
              </div>
            </div>
          </div>
          
          <!-- Стрелка -->
          <div class="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center group-hover:bg-[#3498db]/20 group-hover:translate-x-1 transition-all duration-300">
            <i class="bi bi-arrow-right text-gray-500 group-hover:text-[#3498db] transition-colors"></i>
          </div>
        </div>
        
        <!-- Прогресс-бар при наведении -->
        <div class="absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-[#3498db] to-[#2980b9] w-0 group-hover:w-full transition-all duration-500 rounded-b-2xl"></div>
      </div>
    </a>

    <!-- Azvox -->
    <a href="/user/pay" class="group relative">
      <div class="absolute inset-0 bg-gradient-to-r from-lime-400/20 to-lime-500/20 rounded-2xl blur opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
      
      <div class="glass-card rounded-2xl p-5 border border-white/5 hover:border-lime-400/30 transition-all duration-300 relative overflow-hidden group-hover:transform group-hover:scale-[1.02]">
        
        <div class="absolute inset-0 bg-gradient-to-br from-lime-400/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        
        <div class="flex items-center gap-4 relative z-10">
          <!-- Иконка -->
          <div class="w-16 h-16 rounded-2xl bg-gradient-to-br from-lime-400/20 to-lime-500/10 border border-lime-400/20 flex items-center justify-center group-hover:shadow-[0_0_30px_rgba(200,255,0,0.3)] transition-all duration-300">
            <img src="/assets/images/ps/azvox.png" class="w-10 h-10 object-contain group-hover:scale-110 transition-transform duration-300" alt="Azvox">
          </div>
          
          <!-- Информация -->
          <div class="flex-1">
            <div class="flex items-center gap-2 mb-1">
              <span class="text-lg font-bold text-white group-hover:text-lime-400 transition-colors">Azvox</span>
              <span class="px-2 py-0.5 bg-lime-400/20 text-lime-400 text-[10px] font-bold rounded-full border border-lime-400/30">0%</span>
              <!--<span class="px-2 py-0.5 bg-lime-400 text-dark-900 text-[10px] font-bold rounded-full animate-pulse">FAST</span>-->
            </div>
            
            <div class="space-y-1">
              <div class="flex items-center gap-2 text-sm text-gray-400">
                <i class="bi bi-clock-history text-lime-400 text-xs"></i>
                <span>Мгновенный вывод</span>
              </div>
              <div class="flex items-center gap-2 text-sm text-gray-400">
                <i class="bi bi-currency-dollar text-lime-400 text-xs"></i>
                <span>От: <span class="text-white font-semibold">1 USD</span></span>
              </div>
            </div>
          </div>
          
          <!-- Стрелка -->
          <div class="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center group-hover:bg-lime-400/20 group-hover:translate-x-1 transition-all duration-300">
            <i class="bi bi-arrow-right text-gray-500 group-hover:text-lime-400 transition-colors"></i>
          </div>
        </div>
        
        <!-- Прогресс-бар при наведении -->
        <div class="absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-lime-400 to-lime-500 w-0 group-hover:w-full transition-all duration-500 rounded-b-2xl"></div>
      </div>
    </a>

  </div>

  <!-- Предупреждение -->
  <div class="mt-8 glass-card rounded-2xl p-5 border border-red-400/10">
    <div class="flex items-start gap-3">
      <div class="w-8 h-8 rounded-lg bg-red-400/10 flex items-center justify-center flex-shrink-0 mt-0.5">
        <i class="bi bi-exclamation-triangle text-red-400"></i>
      </div>
      <div>
        <h4 class="text-white font-semibold text-sm mb-1">Важно</h4>
        <p class="text-gray-400 text-xs leading-relaxed">
          Перед выводом убедитесь в правильности реквизитов. Операции необратимы. 
          При возникновении проблем обратитесь в 
          <a href="/user/ticket" class="text-lime-400 hover:underline">техподдержку</a>.
        </p>
      </div>
    </div>
  </div>

</div>

<style>
  .glass-card {
    background: linear-gradient(145deg, rgba(26, 26, 26, 0.9), rgba(20, 20, 20, 0.9));
    border: 1px solid rgba(255, 255, 255, 0.05);
    box-shadow: 0 4px 24px rgba(0, 0, 0, 0.4);
  }
</style>


