<?php 
if(!defined('FastCore')){exit('Oops!');}
 
$opt['title'] = 'Вывод средств';
 
if ($user['ban'] == 1){
    exit('Ваш аккаунт был заблокирован за нарушение правил');
}

# Конфигурация
$db->query("SELECT * FROM db_conf WHERE id = '1' LIMIT 1");
$cnf = $db->fetchArray();

# Кошельки и платежный пароль
$ps = $db->query('SELECT * FROM db_purse WHERE uid = ?',$uid)->fetchArray();
$pSys = '1136053';

$paymentSystems = [
    //'payeer' => [
     //   'name' => 'Payeer',
      //  'image' => '/assets/images/ps/payeer.png',
      //  'min' => 1,
     //   'currency' => 'RUB',
     //   'commission' => '0%',
      //  'pSys' => '1136053',
      //  'wallet_field' => 'payeer',
   // ],
    'azvox' => [
        'name' => 'Azvox',
        'image' => '/assets/images/ps/azvox.png', // убедись, что картинка есть
        'min' => 1,
        'currency' => 'USD',
        'commission' => '0%',
        'pSys' => '9999999',
        'wallet_field' => 'azvox',
    ],    
    //'yandex' => [
     //   'name' => 'YooMoney',
    //    'image' => '/assets/images/ps/yom.png',  // Убедитесь, что изображение существует
     //   'min' => 1,
    //    'currency' => 'RUB',
    //    'commission' => '0%',
     //   'wallet_field' => 'yandex',
   // ],
];

# Фильтрация кошельков
$wallet = new wallets();

# Ищем выплату
$payments = $db->query("SELECT * FROM db_payout WHERE uid = '$uid'")->fetchArray();

# Параметры лимитов
$maxPay = 100;
$todayLimit = 24;
$comPercent = 0.00;

if ($user['is_vip'] == 1) {
    $todayLimit = 1;
    $comPercent = 0;
    $maxPay = 2000;
}

$accPay = $cnf['acc_pay'];
?>

<!-- Заголовок -->
<div class="mb-6">
  <h1 class="text-2xl font-bold text-gradient mb-2">{!TITLE!}</h1>
  <p class="text-gray-400 text-sm">Выводите заработанные средства на ваш кошелёк</p>
</div>

<!-- Информация -->
<div class="bubble-card p-6 mb-6">
  <div class="flex items-start gap-4">
    <div class="w-12 h-12 rounded-xl bg-lime-400/10 flex items-center justify-center flex-shrink-0">
      <i class="bi bi-info-circle text-lime-400 text-xl"></i>
    </div>
    <div>
      <h3 class="font-semibold mb-1">Информация о выводе</h3>
      <p class="text-gray-400 text-sm">Моментальные выплаты каждые <?= $todayLimit; ?> часов. Комиссия при выводе средств составляет до <?= $comPercent; ?>%.</p>
      <?php if ($user['is_vip'] == 1): ?>
        <div class="mt-2 inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-lime-400/10 border border-lime-400/20">
          <i class="bi bi-star-fill text-lime-400 text-xs"></i>
          <span class="text-xs text-lime-400">VIP статус активирован</span>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php 
$csrfCheck = $func->csrfVerify();
if (isset($_POST['pay']) && $csrfCheck == TRUE) {
    $psystem = $_POST['ps'];

    if (isset($paymentSystems[$psystem])) {
        $pWallet = $paymentSystems[$psystem]['wallet_field'] . '_wallet';
        $purse = $ps[$paymentSystems[$psystem]['wallet_field']];
   
        $sum = filter_var($_POST['sum'], FILTER_VALIDATE_FLOAT);
        $com = $sum - ($sum * $commission);
        
        if ($user['sum_in'] >= $accPay) {
            if (time() >= $payments['add'] + (3600 * $todayLimit)) {
                if ($sum <= $maxPay) {
                    if ($sum >= $paymentSystems[$psystem]['min']) {
                        if ($sum <= $user['money_p']) {
                            if ($psystem == 'payeer') {
                                if ($sum <= $maxPay) {
                                    $payeer = new rfs_payeer($config->py_NUM, $config->py_apiID, $config->py_apiKEY);
                                    if ($payeer->isAuth()) {
                                        $arBalance = $payeer->getBalance();
                                        if ($arBalance["auth_error"] == 0) {
                                            $balance = $arBalance["balance"]["USD"]["DOSTUPNO"];
                                            if ($balance >= $sum) {
                                                $array = array(
                                                    'action' => 'output',
                                                    'ps' => $pSys,
                                                    'curIn' => 'USD',
                                                    'sumOut' => $com,
                                                    'curOut' => 'USD',
                                                    'param_ACCOUNT_NUMBER' => $purse,                                                       
                                                    'comment' => iconv('utf-8', 'utf-8', "Выплата пользователю {$login} с проекта ".$config->sitename)
                                                );
                                                $initOutput = $payeer->initOutput($array);
                                                if ($initOutput) {
                                                    $historyId = $payeer->output();
                                                    if (!empty($historyId)) {
                                                        $db->query("UPDATE db_users SET money_p = money_p - '$sum' WHERE id = '$uid'");
                                                        $da = time();
                                                        $dd = $da + 60 * 60 * 24 * 15;
                                                        $pyid = $historyId;
                                                        $db->query("INSERT INTO db_payout (uid, login, purse, sum, sys, `add`, `del`, status, systems) VALUES ('$uid','$login','$purse','$sum','$pyid','$da','$dd','3', 'payeer')");
                                                        $db->query("UPDATE db_users SET sum_out = sum_out + '$sum' WHERE id = '$uid'");   
                                                        $db->query("UPDATE db_stats SET payments = payments + '$sum' WHERE id = '1'");       

                                                        echo '<div class="bubble-card p-4 mb-4 border-lime-400/30">
                                                          <div class="flex items-center gap-3 text-lime-400">
                                                            <i class="bi bi-check-circle text-xl"></i>
                                                            <span>Выплата прошла успешно! <a href="/reviews" class="underline">Оставить отзыв</a></span>
                                                          </div>
                                                        </div>';
                                                    } else {
                                                        echo '<div class="bubble-card p-4 mb-4 border-red-400/30">
                                                          <div class="flex items-center gap-3 text-red-400">
                                                            <i class="bi bi-exclamation-triangle text-xl"></i>
                                                            <span>Внутренняя ошибка - сообщите администратору!</span>
                                                          </div>
                                                        </div>';
                                                    }
                                                } else {
                                                    echo '<div class="bubble-card p-4 mb-4 border-red-400/30">
                                                      <div class="flex items-center gap-3 text-red-400">
                                                        <i class="bi bi-exclamation-triangle text-xl"></i>
                                                        <span>Ошибка - попробуйте через 20-30 секунд или сообщите администратору!</span>
                                                      </div>
                                                    </div>';
                                                }
                                            } else {
                                                echo '<div class="bubble-card p-4 mb-4 border-red-400/30">
                                                  <div class="flex items-center gap-3 text-red-400">
                                                    <i class="bi bi-exclamation-triangle text-xl"></i>
                                                    <span>Ошибка. Не удалось выплатить! Попробуйте позже</span>
                                                  </div>
                                                </div>';
                                            }
                                        } else {
                                            echo '<div class="bubble-card p-4 mb-4 border-red-400/30">
                                              <div class="flex items-center gap-3 text-red-400">
                                                <i class="bi bi-exclamation-triangle text-xl"></i>
                                                <span>Ошибка. Не удалось выплатить! Попробуйте позже</span>
                                              </div>
                                            </div>';
                                        }
                                    } else {
                                        echo '<div class="bubble-card p-4 mb-4 border-red-400/30">
                                          <div class="flex items-center gap-3 text-red-400">
                                            <i class="bi bi-exclamation-triangle text-xl"></i>
                                            <span>Система выплат временно недоступна</span>
                                          </div>
                                        </div>';
                                    }
                                }
                            }
                        } else {
                            echo '<div class="bubble-card p-4 mb-4 border-red-400/30">
                              <div class="flex items-center gap-3 text-red-400">
                                <i class="bi bi-exclamation-triangle text-xl"></i>
                                <span>Вы указали больше, чем имеется на вашем счету</span>
                              </div>
                            </div>';
                        }
                    } else {
                        echo '<div class="bubble-card p-4 mb-4 border-red-400/30">
                          <div class="flex items-center gap-3 text-red-400">
                            <i class="bi bi-exclamation-triangle text-xl"></i>
                            <span>Минимальная сумма для выплаты составляет '.$paymentSystems[$psystem]['min'].' $</span>
                          </div>
                        </div>';
                    }
                } else {
                    echo '<div class="bubble-card p-4 mb-4 border-red-400/30">
                      <div class="flex items-center gap-3 text-red-400">
                        <i class="bi bi-exclamation-triangle text-xl"></i>
                        <span>Максимальная сумма для выплаты составляет '.$maxPay.' $, за '.$todayLimit.' часов</span>
                      </div>
                    </div>';
                }
            } else {
                echo '<div class="bubble-card p-4 mb-4 border-red-400/30">
                  <div class="flex items-center gap-3 text-red-400">
                    <i class="bi bi-exclamation-triangle text-xl"></i>
                    <span>Вы уже заказывали выплату за последний '.$todayLimit.' час</span>
                  </div>
                </div>';
            }
        } else {
            echo '<div class="bubble-card p-4 mb-4 border-red-400/30">
              <div class="flex items-center gap-3 text-red-400">
                <i class="bi bi-exclamation-triangle text-xl"></i>
                <span>Вам нужно приобрести Galaxy от '.$accPay.' $! После этого выплаты будут доступны.</span>
              </div>
            </div>';
        }
    } else {
        echo '<div class="bubble-card p-4 mb-4 border-red-400/30">
          <div class="flex items-center gap-3 text-red-400">
            <i class="bi bi-exclamation-triangle text-xl"></i>
            <span>Платежная система не существует!</span>
          </div>
        </div>';
    }
}
?>

<!-- Форма вывода -->
<div class="bubble-card p-6">
  <form method="POST" id="form">
    <?php $func->csrf(); ?>
    <input type="hidden" id="sum" name="sum">
    <input type="hidden" id="ps" name="ps">
    <input type="hidden" name="pay">
  </form>

  <!-- Ввод суммы -->
  <div class="mb-6">
    <label class="block text-gray-400 text-sm mb-2">Сумма вывода</label>
    <div class="relative">
      <i class="bi bi-currency-ruble absolute left-4 top-1/2 -translate-y-1/2 text-gray-500"></i>
      <input type="number" id="sumval" name="sum" placeholder="Введите сумму" min="1" step="0.01"
             class="input-dark w-full pl-11 text-lg" onkeyup="input_sum();">
    </div>
    <div class="mt-2 text-xs text-gray-500">
      Доступно: <span class="text-lime-400"><?= sprintf("%.2f", $user['money_p']); ?> $</span> | 
      Минимум: <span class="text-lime-400">1 $</span> | 
      Максимум: <span class="text-lime-400"><?= $maxPay; ?> $</span>
    </div>
  </div>

  <!-- Ошибка -->
  <div id="warningMessage" class="hidden bubble-card p-4 mb-4 border-red-400/30">
    <div class="flex items-center gap-3 text-red-400">
      <i class="bi bi-exclamation-triangle"></i>
      <span id="warningText"></span>
    </div>
  </div>

  <!-- Платежные системы -->
  <div class="space-y-3">
    <div class="text-sm text-gray-400 mb-3">Выберите способ вывода:</div>
    
    <?php foreach ($paymentSystems as $key => $system): ?>
      <?php
      $walletField = $system['wallet_field'];
      $hasWallet = !empty($ps[$walletField]);
      $walletValue = $ps[$walletField] ?? '';
      ?>
      <div class="flex items-center justify-between p-4 rounded-xl bg-dark-700 <?= $hasWallet ? 'border border-transparent hover:border-lime-400/30' : 'opacity-60' ?> transition">
        <div class="flex items-center gap-4">
          <div class="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center">
            <img src="<?= $system['image'] ?>" alt="<?= $system['name'] ?>" class="w-8 h-8 object-contain">
          </div>
          <div>
            <div class="font-semibold"><?= $system['name'] ?></div>
            <div class="text-sm text-gray-400">
              <?php if ($hasWallet && $walletValue != '0'): ?>
                <?= $walletValue; ?>
              <?php else: ?>
                Кошелёк не настроен
              <?php endif; ?>
            </div>
            <div class="text-xs text-gray-500">Комиссия: <?= $system['commission'] ?> | Мин: <?= $system['min'] ?> $</div>
          </div>
        </div>
        <?php if (!$hasWallet || $walletValue == '0'): ?>
          <a href="/user/settings" class="btn-dark px-4 py-2 text-sm">
            Настроить
          </a>
        <?php else: ?>
          <button onclick="send('<?= $key ?>')" class="btn-lime px-6 py-2 text-sm">
            Вывести
          </button>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<script>
function send(ps) {
    const sumVal = document.getElementById("sumval").value.trim();
    const warningBox = document.getElementById("warningMessage");
    const warningText = document.getElementById("warningText");

    warningBox.classList.add("hidden");

    if (!sumVal) {
        warningText.textContent = "Пожалуйста, введите сумму.";
        warningBox.classList.remove("hidden");
        return false;
    }

    document.getElementById("ps").value = ps;
    document.getElementById("sum").value = parseFloat(sumVal);
    document.getElementById("form").submit();
}
</script>
