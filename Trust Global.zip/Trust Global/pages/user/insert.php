<?php if (!defined('FastCore')) { exit('Oops!'); }

$opt['title'] = 'Пополнение баланса';
 
// Получаем конфигурацию
$db->query("SELECT * FROM db_conf WHERE id = '1' LIMIT 1");
$cnf = $db->fetchArray();

?>
 
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Получаем данные из формы
    $sum = round(floatval($_POST["sum"]), 2);
    $sys = $_POST["pays"];
    $sum_x = '0';

    if ($sum <= 0 || !$sys) {
        echo "Ошибка: Некорректная сумма или не выбрана платежная система.";
        exit;
    }
 

    // Платежные системы
    else {
        // Заносим в БД
        $db->query("INSERT INTO db_insert (uid, login, sum, sum_x, sys, `add`, status) VALUES ('$uid', '$login', '$sum', '$sum_x', '$sys', '" . time() . "', '0')");
        // Получаем ID последней вставленной записи
        $last_insert_id = $db->LastInsert();  
    
        // Обработка выбранной платежной системы
        
        // Платежная система ЮМАНИ
        if ($sys == 'yoomoney') {
            $receiver = $config->YandexPurse;
            $quickpay = 'button';
            $sumin = number_format($sum, 2, ".", "");
            $targets = 'Пополнение рекламного баланса $login';
            $label = $last_insert_id;
            $successURL = 'https://'.$config->siteurl.'/user/success';
    
            // Формируем URL для перехода на ЮМАНИ
            $url = "https://yoomoney.ru/quickpay/confirm/?receiver=$receiver&quickpay-form=$quickpay&sum=$sumin&targets=$targets&label=$label&successURL=$successURL";           
            
            // Редирект на URL
            header("Location: $url");
            exit; 
        }

        // Платежная система ЮМАНИ
        if ($sys == 'mir') {
            $receiver = $config->YandexPurse;
            $quickpay = 'button';
            $sumin = number_format($sum, 2, ".", "");
            $targets = 'Пополнение рекламного баланса $login';
            $label = $last_insert_id;
            $successURL = 'https://'.$config->siteurl.'/user/success';
    
            // Формируем URL для перехода на ЮМАНИ
            $url = "https://yoomoney.ru/quickpay/confirm/?receiver=$receiver&quickpay-form=$quickpay&sum=$sumin&targets=$targets&label=$label&successURL=$successURL";           
            
            // Редирект на URL
            header("Location: $url");
            exit; 
        }
 
        // Платежная система Payeer
        elseif ($sys == 'payeer') {
            $desc = base64_encode("Пополнение рекламного баланса $login");
            $m_shop = $config->py_shop;
            $m_orderid = $last_insert_id;
            $m_amount = number_format($sum, 2, ".", "");
            $m_curr = 'RUB';
            $m_desc = $desc;
            $m_key = $config->py_secret;
    
            $arHash = array($m_shop, $m_orderid, $m_amount, $m_curr, $m_desc, $m_key);
            $sign = strtoupper(hash('sha256', implode(":", $arHash)));
    
            // Формируем URL для перехода на Payeer
            $url = "https://payeer.com/api/merchant/m.php?m_shop=$m_shop&m_orderid=$m_orderid&m_amount=$m_amount&m_curr=RUB&m_desc=$desc&m_sign=$sign";
            
            // Редирект на URL
            header("Location: $url");
            exit; 
        }
     
        // Платежная система FreeKassa
        elseif ($sys == 'freekassa') {
            $order_id = $last_insert_id;
            $merchant_id = $config->fk_id;
            $secret_word = $config->fk_key;
            $currency = 'RUB';
            $hash = md5($merchant_id.':'.$sum.':'.$secret_word.':'.$currency.':'.$order_id);
            
            // Формируем URL для перехода на FreeKassa
            $url = "https://pay.fk.money/?m=$merchant_id&oa=$sum&o=$order_id&s=$hash&us_id=$uid&currency=$currency&lang=ru";
            
            // Редирект на URL
            header("Location: $url");
            exit; 
        }
        
        // Платежная система Azvox
        elseif ($sys == 'azvox') {
            $m_shop = $config->az_shop;
            $m_key = $config->az_secret;
            $m_amount = number_format($sum, 2, ".", "");
            $m_curr = 'USD';
            $m_orderid = $last_insert_id;
            $m_desc = base64_encode("Пополнение рекламного баланса " . $login);
            $m_params = base64_encode(json_encode(false));
            $arHash = array($m_shop, $m_orderid, $m_amount, $m_curr, $m_desc, $m_params, $m_key);
            $m_sign = strtoupper(hash('sha256', implode(':', $arHash)));
    
            // Формируем URL для Azvox
            $url = "https://azvox.cash/pay/?m_shop=$m_shop&m_orderid=$m_orderid&m_amount=$m_amount&m_curr=$m_curr&m_desc=$m_desc&m_sign=$m_sign&m_params=$m_params";
        
            // Редирект на URL
            header("Location: $url");
            exit; 
        }  
    }
}
?>

<!-- Заголовок -->
<div class="mb-6">
  <h1 class="text-2xl font-bold text-gradient mb-2">{!TITLE!}</h1>
  <p class="text-gray-400 text-sm">Пополните баланс удобным способом</p>
</div>

<!-- Информация -->
<div class="bubble-card p-6 mb-6">
  <div class="flex items-start gap-4">
    <div class="w-12 h-12 rounded-xl bg-lime-400/10 flex items-center justify-center flex-shrink-0">
      <i class="bi bi-info-circle text-lime-400 text-xl"></i>
    </div>
    <div>
      <h3 class="font-semibold mb-1">Информация о пополнении</h3>
      <p class="text-gray-400 text-sm">Введите сумму и выберите удобный способ оплаты. Средства поступят на баланс покупки автоматически.</p>
    </div>
  </div>
</div>

<!-- Форма пополнения -->
<div class="bubble-card p-6">
  <form id="paymentForm" action="" method="POST">
    <?php $func->csrf(); ?>
    <input type="hidden" name="pays" id="payment_system">

    <!-- Ввод суммы -->
    <div class="mb-6">
      <label class="block text-gray-400 text-sm mb-2">Сумма пополнения</label>
      <div class="relative">
        <i class="bi bi-currency-ruble absolute left-4 top-1/2 -translate-y-1/2 text-gray-500"></i>
        <input type="number" id="amount" name="sum" required placeholder="Введите сумму" min="1" step="0.01"
               class="input-dark w-full pl-11 text-lg">
      </div>
    </div>

    <!-- Ошибка -->
    <div id="paymentError" class="hidden bubble-card p-4 mb-4 border-red-400/30">
      <div class="flex items-center gap-3 text-red-400">
        <i class="bi bi-exclamation-triangle"></i>
        <span id="errorText"></span>
      </div>
    </div>

    <!-- Платежные системы -->
    <div class="space-y-3">
      <div class="text-sm text-gray-400 mb-3">Выберите способ:</div>
      
      <!-- Payeer -->
      <!--<div class="flex items-center justify-between p-4 rounded-xl bg-dark-700 hover:bg-dark-600 transition cursor-pointer border border-transparent hover:border-lime-400/30" onclick="submitPayment('payeer', 1)">
        <div class="flex items-center gap-4">
          <div class="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center">
            <img src="/assets/images/ps/payeer.png" alt="Payeer" class="w-8 h-8 object-contain">
          </div>
          <div>
            <div class="font-semibold">Payeer</div>
            <div class="text-sm text-gray-400">от 1 $</div>
          </div>
        </div>
        <button type="button" class="btn-lime px-4 py-2 text-sm">
          Выбрать
        </button>
      </div>-->

      <!-- Azvox -->
      <div class="flex items-center justify-between p-4 rounded-xl bg-dark-700 hover:bg-dark-600 transition cursor-pointer border border-transparent hover:border-lime-400/30" onclick="submitPayment('azvox', 50)">
        <div class="flex items-center gap-4">
          <div class="w-12 h-12 rounded-xl bg-purple-500/10 flex items-center justify-center">
            <img src="/assets/images/ps/azvox.png" alt="Azvox" class="w-8 h-8 object-contain">
          </div>
          <div>
            <div class="font-semibold">Azvox</div>
            <div class="text-sm text-gray-400">от 1 $</div>
          </div>
        </div>
        <button type="button" class="btn-lime px-4 py-2 text-sm">
          Выбрать
        </button>
      </div>
      
    </div>
  </form>
</div>
<!-- Инфо -->
    <div class="mt-6 pt-6 border-t border-white/5">
      <div class="flex items-center justify-center gap-4 text-xs text-gray-500">
        <div class="flex items-center gap-1">
          <i class="bi bi-shield-check text-lime-400"></i>
          <span>Безопасно</span>
        </div>
        <div class="flex items-center gap-1">
          <i class="bi bi-lightning text-lime-400"></i>
          <span>Мгновенно</span>
        </div>
        <div class="flex items-center gap-1">
          <i class="bi bi-percent text-lime-400"></i>
          <span>Комиссия 0%</span>
        </div>
      </div>
    </div>
<!-- Скрипт обработки -->
<script>
function submitPayment(system, minAmount) {
  var sum = parseFloat(document.getElementById('amount').value);
  var errorBox = document.getElementById('paymentError');
  var errorText = document.getElementById('errorText');

  errorBox.classList.add('hidden');

  if (isNaN(sum) || sum <= 0) {
    errorText.innerText = 'Пожалуйста, введите сумму пополнения.';
    errorBox.classList.remove('hidden');
    return;
  }

  if (sum < minAmount) {
    errorText.innerText = 'Минимальная сумма для ' + system + ' — ' + minAmount + ' $';
    errorBox.classList.remove('hidden');
    return;
  }

  document.getElementById('payment_system').value = system;
  document.getElementById('paymentForm').submit();
}
</script>
