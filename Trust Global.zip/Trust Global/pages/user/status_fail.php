<?php if (!defined('FastCore')) {
    echo 'Выявлена попытка взлома!';
    exit();
}
$opt['title'] = 'Отмена';
?>

<!-- Заголовок -->
<div class="mb-6 text-center">
  <h1 class="text-2xl font-bold text-gradient mb-2">Отмена пополнения</h1>
  <p class="text-gray-400 text-sm">Пополнение не выполнено</p>
</div>

<!-- Сообщение об ошибке -->
<div class="max-w-md mx-auto">
  <div class="bubble-card p-8 text-center">
    <div class="w-20 h-20 rounded-full bg-red-400/10 flex items-center justify-center mx-auto mb-6">
      <i class="bi bi-x-octagon-fill text-red-400 text-4xl"></i>
    </div>
    
    <p class="text-gray-300 mb-6">
      По какой-то причине ваше пополнение не сработало, либо вы его отменили.
    </p>

    <a href="/user/insert" class="btn-dark inline-flex items-center gap-2 px-8 py-3 border-red-400/30 text-red-400 hover:bg-red-400/10">
      <i class="bi bi-arrow-repeat"></i>
      Попробовать снова
    </a>
  </div>
</div>
