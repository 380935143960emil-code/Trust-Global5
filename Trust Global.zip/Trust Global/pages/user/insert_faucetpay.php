<?php if(!defined('FastCore')){exit('Oops!');}

$opt['title'] = 'Пополненить баланс';

$username = $user['login'];
?>
<!-- Заголовок -->
<div class="container mx-auto px-4 max-w-2xl mt-6">
  <div class="relative mb-6">
    <div class="absolute inset-0 bg-[#3498db]/20 blur-3xl rounded-full opacity-50"></div>
    <div class="glass-card rounded-2xl p-1 border border-[#3498db]/20 relative overflow-hidden">
      <div class="absolute inset-0 bg-gradient-to-r from-[#3498db]/10 via-transparent to-[#3498db]/10"></div>
      <h3 class="relative text-center text-white font-bold text-lg py-3 px-4">
        СПОСОБ ПОПОЛНЕНИЯ - 
        <span class="text-[#3498db] glow-text">FAUCETPAY</span>
      </h3>
    </div>
  </div>

<?php

# Способ платежа
$py = $pg->segment[2] ?? NULL;

# Выбран способ оплаты
if ($py) {

$selectPS = mb_strtoupper($py);
$systemPay = $db->query('SELECT * FROM db_paysystem WHERE name = ? LIMIT 1',$selectPS)->fetchArray();
$minDep = $systemPay['mindep'];
$currencyPS = $systemPay['currency'];
$psTitle = $systemPay['title'];

$opt['title'] = 'Deposit method '.$psTitle.'';

# Оплата через FaucetPay.IO
$csrfCheck = $func->csrfVerify();
if (isset($_POST['sum']) && $py == 'faucetpay' && $csrfCheck == TRUE) {

$sum = round(floatval($_POST["sum"]),2);
$sys = 'Faucetpay';
$sum_x = '0';

if ($sum > $minDep-0.10) {
# Заносим в БД
$db->query("INSERT INTO db_insert (uid, login, sum, sum_x, sys, `add`, status) VALUES ('$uid','$username','$sum','$sum_x','$sys','".time()."','0')");
 
$m_orderid = $db->LastInsert();
$m_amount = number_format($sum, 2, ".", ""); 
 
$setURI = 'https://faucetpay.io/merchant/webscr';
$m_username = $config->fp_username;
$m_desc = urlencode('insert user: '.$uid.' - '.$login);

$m_callback_url = urlencode("https://".$_SERVER['HTTP_HOST']."/faucetpay.php");
$m_success_url = urlencode("https://".$_SERVER['HTTP_HOST']."/user/success");
$m_cancel_url = urlencode("https://".$_SERVER['HTTP_HOST']."/user/fail");

$location = $setURI."?merchant_username=$m_username&item_description=$m_desc&amount1=$m_amount&currency1=$currencyPS&custom=$m_orderid&callback_url=$m_callback_url&success_url=$m_success_url&cancel_url=$m_cancel_url&completed=0";

// Перенаправление на страницу FaucetPay
header("Location: $location");
 
}
 else {
	echo '<div class="alert alert-danger h5 p-3 text-center"><b>СУММА ОШИБКИ</b><br/>Способ оплаты <span class="text-uppercase">'.$py.'</span> <br/> Для этой системы минимальная сумма депозита составляет <b>'.$minDep.' DOGE.</b></div>';
}
	return;
}

if ($py == 'faucetpay') {

?>

  <!-- Основная карточка -->
  <div class="glass-card rounded-3xl p-6 md:p-8 border border-white/5 relative overflow-hidden group">
    
    <!-- Фоновый эффект -->
    <div class="absolute top-0 right-0 w-64 h-64 bg-[#3498db]/5 rounded-full blur-3xl group-hover:bg-[#3498db]/10 transition-all duration-700"></div>
    <div class="absolute bottom-0 left-0 w-48 h-48 bg-lime-400/5 rounded-full blur-3xl"></div>
    
    <!-- Ссылка на регистрацию FaucetPay -->
    <a href="https://faucetpay.io/?r=982803" target="_blank" 
       class="block w-full mb-6 relative overflow-hidden rounded-xl bg-gradient-to-r from-[#3498db]/20 to-[#2980b9]/20 border border-[#3498db]/30 p-3 text-center group/link hover:border-[#3498db]/50 transition-all duration-300">
      <div class="absolute inset-0 bg-gradient-to-r from-transparent via-[#3498db]/10 to-transparent translate-x-[-100%] group-hover/link:translate-x-[100%] transition-transform duration-700"></div>
      <span class="relative text-[#3498db] text-sm font-medium flex items-center justify-center gap-2">
        <i class="bi bi-wallet2"></i>
        Ещё нет FaucetPay кошелька?
        <i class="bi bi-arrow-right group-hover/link:translate-x-1 transition-transform"></i>
      </span>
    </a>

    <!-- Логотип -->
    <div class="flex justify-center mb-6">
      <div class="w-24 h-24 rounded-2xl bg-[#3498db]/10 border border-[#3498db]/20 flex items-center justify-center relative">
        <div class="absolute inset-0 bg-[#3498db]/20 blur-xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
        <img src="/img/faucetpay.png" alt="FaucetPay" class="w-16 h-12 object-contain relative z-10 drop-shadow-[0_0_10px_rgba(52,152,219,0.5)]">
      </div>
    </div>

    <!-- Заголовок -->
    <div class="text-center mb-6">
      <h2 class="text-2xl font-bold text-white mb-2">Пополните баланс</h2>
      <p class="text-gray-500 text-sm">Мгновенное зачисление средств</p>
    </div>

    <!-- Форма -->
    <form action="" method="post" class="space-y-6">
      <?php $func->csrf(); ?>
      
      <!-- Поле суммы -->
      <div class="space-y-2">
        <label for="getsum" class="block text-sm font-medium text-gray-400 ml-1">
          Укажите сумму пополнения
        </label>
        
        <div class="relative group/input">
          <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
            <span class="text-[#3498db] font-bold text-lg">$</span>
          </div>
          
          <input type="number" 
                 name="sum" 
                 id="getsum" 
                 placeholder="0.00" 
                 min="<?=$minDep;?>" 
                 max="50000" 
                 step="any"
                 onkeyup="generateThis();"
                 class="w-full bg-dark-800/50 border border-white/10 rounded-2xl py-4 pl-10 pr-20 text-white text-2xl font-bold placeholder-gray-600 focus:border-[#3498db]/50 focus:ring-2 focus:ring-[#3498db]/20 focus:outline-none transition-all duration-300 text-center"
                 required>
          
          <div class="absolute inset-y-0 right-0 pr-4 flex items-center pointer-events-none">
            <span class="text-gray-500 text-sm font-semibold">USDT</span>
          </div>
          
          <!-- Glow эффект при фокусе -->
          <div class="absolute inset-0 rounded-2xl bg-[#3498db]/20 blur-xl opacity-0 group-focus-within/input:opacity-100 transition-opacity duration-300 -z-10"></div>
        </div>
        
        <div class="flex justify-between text-xs text-gray-500 px-1">
          <span>Минимум: <span class="text-lime-400 font-semibold"><?=$minDep;?> USDT</span></span>
          <span>Максимум: <span class="text-gray-400">5000</span></span>
        </div>
      </div>

      <!-- Кнопка пополнения -->
      <button type="submit" 
              class="w-full relative overflow-hidden rounded-2xl bg-gradient-to-r from-lime-400 to-lime-500 text-dark-900 font-bold text-lg py-4 px-6 hover:shadow-[0_0_30px_rgba(200,255,0,0.4)] hover:scale-[1.02] active:scale-[0.98] transition-all duration-300 group/btn">
        <div class="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] group-hover/btn:translate-x-[100%] transition-transform duration-700"></div>
        <span class="relative flex items-center justify-center gap-2">
          <i class="bi bi-lightning-charge-fill"></i>
          Пополнить баланс
        </span>
      </button>

    </form>

  </div>

<!-- Инфо -->
    <div class="mt-6 pt-6 border-t border-white/5">
      <div class="flex items-center justify-center gap-4 text-xs text-gray-500">
        <div class="flex items-center gap-1">
          <i class="bi bi-shield-check text-lime-400"></i>
          <span>Безопасно</span>
        </div>
        <div class="flex items-center gap-1">
          <i class="bi bi-lightning text-lime-400"></i>
          <span>Мгновенно</span>
        </div>
        <div class="flex items-center gap-1">
          <i class="bi bi-percent text-lime-400"></i>
          <span>Комиссия 0%</span>
        </div>
      </div>
    </div>
</div>

<style>
  .glass-card {
    background: linear-gradient(145deg, rgba(26, 26, 26, 0.95), rgba(20, 20, 20, 0.95));
    border: 1px solid rgba(255, 255, 255, 0.05);
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
  }
  
  .glow-text {
    text-shadow: 0 0 10px rgba(52, 152, 219, 0.5);
  }
  
  /* Убираем стрелки у number input */
  input[type=number]::-webkit-inner-spin-button, 
  input[type=number]::-webkit-outer-spin-button { 
    -webkit-appearance: none; 
    margin: 0; 
  }
  input[type=number] {
    -moz-appearance: textfield;
  }
</style>

<?php
return;
} else {
	echo '<div class="glass-card border border-yellow-500/30 rounded-2xl p-6 text-center">
            <div class="w-16 h-16 rounded-full bg-yellow-500/10 flex items-center justify-center mx-auto mb-4">
              <i class="bi bi-exclamation-circle text-yellow-400 text-2xl"></i>
            </div>
            <h4 class="text-yellow-400 font-bold mb-2">ERROR</h4>
            <p class="text-gray-400 text-sm">Платежная система не определена!</p>
          </div>';
}
return;
}
?>