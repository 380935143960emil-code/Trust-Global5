<style>
.akcia {
  font-weight: normal;
  position: relative;
  background: #F8463F;
  width: 60%;
  color: #fff;
  text-align: center;
  padding: 6px 20px;
  margin: 10px auto 10px;
  text-transform: uppercase;
  border-radius: 2px;
  font-size: 18px;margin-bottom: -27px;z-index: 99;
}
.akcia:before, 
.akcia:after {
  content: "";
  position: absolute;
  top: -7px;
  border: 18px solid #d8332c;
}
.akcia:before {
  left: -35px;
  border-right-width: 18px;
  border-left-color: transparent;
}
.akcia:after {
  right: -35px;
  border-left-width: 18px;
  border-right-color: transparent;
}
.akcia span:before, 
.akcia span:after {
  content: "";
  position: absolute;
  border-style: solid;
  border-color: #b8130c transparent transparent transparent;
  top: -7px;
  transform: rotate(180deg);
}
.akcia span:before {
  left: 0;
  border-width: 8px 0 0 8px;
}
.akcia span:after {
  right: 0;
  border-width: 8px 8px 0 0;
}
.alerto {
  padding: 7px 2px;font-size: 107%;background: none; border: 0;
  border-left: 0px dashed rgba(245,155,55,0.7);border-radius: 0;
}
.nav-pills div + div {
  border-left: 1px dashed rgba(245,155,55,0.7);
}

.block-1 {
  border1: 2px dashed rgba(245,155,55,0.7);padding-top: 30px !important;

}
</style>

<div class="akcia"><span>ПОПОЛНИ БАЛАНС И ПОЛУЧИ <b style="color: #fe3;">ДОПОЛНИТЕЛЬНЫЙ БОНУС</b>!</span></div>

<div class="mb-2 alert alert-primary p-1 block-1 ">
<div class="nav nav-pills nav-fill text-uppercase">
<?php
$bon_p= $db->query('SELECT * FROM db_percent WHERE type = 1  ORDER BY sum_a < sum_a DESC LIMIT 7')->fetchAll();
foreach ($bon_p as $bon_p) {
?>
<div class="nav-item nav-link p-1">
	<div class="alert alert-light alerto text-dark text-center mb-0">ПОПОЛНИ<br/>
от <b class="text-primary"><?=$bon_p['sum_a']; ?></b> до <b class="text-primary"><?=floor($bon_p['sum_b']); ?></b> руб. <br/> <b>
	<span class="text-white" style="font-size: 18px;background: #e34;padding: 1px 7px 1px; border-radius: 6px;">бонус <span style="color: #ffef02;">+<?=$bon_p['sum_x']*100; ?>%</span></span></b></div>
</div>
<?php
	}
?>
	</div>
</div>