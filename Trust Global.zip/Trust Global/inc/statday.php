<?php
    $ipGet = $func->ipGet();
$ip = $func->ipValid($ipGet);
	$tmptime=time();
	$timeonline=time()-300;
	$usid = $_SESSION["uid"];
	$login = $_SESSION["login"];
	$db->Query("DELETE FROM db_statday WHERE time <$timeonline ");
	$db->Query("SELECT * FROM db_statday WHERE login = '$login' LIMIT 1");
	if($db->NumRows() == 0) {
	if (!empty($login)) {$login = $_SESSION["login"];}
	else {$login='Гость';}
	$db->Query("INSERT INTO db_statday(ip,login, time) VALUES ('$ip','$login','$tmptime') ");
	}
	else
	{
	$db->Query("UPDATE db_statday SET time = '$tmptime' WHERE login = '$login' ");
	}
	?>