<?php if(!defined('FastCore')){exit();} $current = $_SERVER['REQUEST_URI']; ?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />  
  <title>Trust Global - {!TITLE!}</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="apple-touch-icon" sizes="180x180" href="/assets/favicons/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="/assets/favicons/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="/assets/favicons/favicon-16x16.png">
  <link rel="manifest" href="/assets/favicons/site.webmanifest">  
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            lime: {
              400: '#a3e635',
              500: '#84cc16',
              600: '#65a30d',
            },
            dark: {
              900: '#0a0a0a',
              800: '#141414',
              700: '#1a1a1a',
              600: '#242424',
              500: '#2a2a2a',
            }
          },
          fontFamily: {
            sans: ['Inter', 'sans-serif'],
          },
          boxShadow: {
            'neon': '0 0 20px rgba(163, 230, 53, 0.3)',
            'neon-strong': '0 0 30px rgba(163, 230, 53, 0.5)',
            'card': '0 4px 30px rgba(0, 0, 0, 0.5)',
          }
        }
      }
    }
  </script>
  
  <style>
    * {
      font-family: 'Inter', sans-serif;
    }
    
    body {
      background: #0a0a0a;
      color: #ffffff;
      min-height: 100vh;
    }
    
    /* Градиентный текст */
    .text-gradient {
      background: linear-gradient(135deg, #a3e635 0%, #84cc16 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }
    
    /* Неоновое свечение */
    .neon-glow {
      box-shadow: 0 0 20px rgba(163, 230, 53, 0.3);
    }
    
    .neon-glow-strong {
      box-shadow: 0 0 30px rgba(163, 230, 53, 0.5);
    }
    
    /* Карточки - отдельные блоки с отступами */
    .bubble-card {
      background: linear-gradient(145deg, #1a1a1a 0%, #141414 100%);
      border: 1px solid rgba(163, 230, 53, 0.1);
      border-radius: 16px;
      transition: all 0.3s ease;
      margin-bottom: 12px;
    }
    
    .bubble-card:last-child {
      margin-bottom: 0;
    }
    
    .bubble-card:hover {
      border-color: rgba(163, 230, 53, 0.3);
    }
    
    /* Маленькие карточки для меню */
    .menu-card {
      background: linear-gradient(145deg, #1a1a1a 0%, #141414 100%);
      border: 1px solid rgba(163, 230, 53, 0.08);
      border-radius: 12px;
      padding: 16px;
      margin-bottom: 12px;
      transition: all 0.3s ease;
    }
    
    .menu-card:hover {
      border-color: rgba(163, 230, 53, 0.2);
    }
    
    /* Кнопки */
    .btn-lime {
      background: linear-gradient(135deg, #a3e635 0%, #84cc16 100%);
      color: #0a0a0a;
      font-weight: 600;
      border-radius: 12px;
      transition: all 0.3s ease;
    }
    
    .btn-lime:hover {
      box-shadow: 0 0 25px rgba(163, 230, 53, 0.5);
      transform: translateY(-1px);
    }
    
    .btn-dark {
      background: #1a1a1a;
      border: 1px solid rgba(163, 230, 53, 0.2);
      color: #a3e635;
      font-weight: 500;
      border-radius: 12px;
      transition: all 0.3s ease;
    }
    
    .btn-dark:hover {
      border-color: rgba(163, 230, 53, 0.5);
      background: #242424;
    }
    
    /* Меню */
    .menu-item {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 10px 12px;
      border-radius: 10px;
      color: #9ca3af;
      transition: all 0.3s ease;
      text-decoration: none;
      font-size: 14px;
    }
    
    .menu-item:hover {
      background: rgba(163, 230, 53, 0.1);
      color: #a3e635;
    }
    
    .menu-item.active {
      background: rgba(163, 230, 53, 0.15);
      color: #a3e635;
      border: 1px solid rgba(163, 230, 53, 0.3);
    }
    
    /* Шапка */
    .header-glass {
      background: rgba(10, 10, 10, 0.95);
      backdrop-filter: blur(20px);
      border-bottom: 1px solid rgba(163, 230, 53, 0.1);
    }
    
    /* Скроллбар */
    ::-webkit-scrollbar {
      width: 6px;
    }
    
    ::-webkit-scrollbar-track {
      background: #0a0a0a;
    }
    
    ::-webkit-scrollbar-thumb {
      background: #2a2a2a;
      border-radius: 3px;
    }
    
    ::-webkit-scrollbar-thumb:hover {
      background: #a3e635;
    }
    
    /* Анимации */
    @keyframes pulse-lime {
      0%, 100% { box-shadow: 0 0 20px rgba(163, 230, 53, 0.3); }
      50% { box-shadow: 0 0 30px rgba(163, 230, 53, 0.6); }
    }
    
    .pulse-lime {
      animation: pulse-lime 2s infinite;
    }
    
    /* Бейджи */
    .badge-lime {
      background: rgba(163, 230, 53, 0.15);
      color: #a3e635;
      border: 1px solid rgba(163, 230, 53, 0.3);
      border-radius: 20px;
      padding: 2px 10px;
      font-size: 11px;
      font-weight: 600;
    }
    
    .badge-vip {
      background: linear-gradient(135deg, #a3e635 0%, #84cc16 100%);
      color: #0a0a0a;
      border-radius: 20px;
      padding: 2px 10px;
      font-size: 11px;
      font-weight: 700;
    }
    
    /* Формы */
    .input-dark {
      background: #1a1a1a;
      border: 1px solid rgba(163, 230, 53, 0.2);
      border-radius: 12px;
      color: #ffffff;
      padding: 12px 16px;
      transition: all 0.3s ease;
    }
    
    .input-dark:focus {
      outline: none;
      border-color: #a3e635;
      box-shadow: 0 0 15px rgba(163, 230, 53, 0.2);
    }
    
    /* Таблицы */
    .table-dark {
      width: 100%;
      border-collapse: separate;
      border-spacing: 0;
    }
    
    .table-dark th {
      background: #141414;
      color: #9ca3af;
      font-weight: 500;
      padding: 16px;
      text-align: left;
    }
    
    .table-dark td {
      padding: 16px;
      border-bottom: 1px solid rgba(163, 230, 53, 0.05);
    }
    
    .table-dark tr:hover td {
      background: rgba(163, 230, 53, 0.03);
    }
    
    /* Логотип */
    .logo-text {
      font-size: 24px;
      font-weight: 800;
      background: linear-gradient(135deg, #a3e635 0%, #84cc16 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }
    
    /* Статистика */
    .stat-card {
      background: linear-gradient(145deg, #1a1a1a 0%, #141414 100%);
      border: 1px solid rgba(163, 230, 53, 0.1);
      border-radius: 16px;
      padding: 20px;
      position: relative;
      overflow: hidden;
    }
    
    .stat-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 2px;
      background: linear-gradient(90deg, transparent, #a3e635, transparent);
    }
    
    /* Аватар */
    .avatar-bubble {
      width: 60px;
      height: 60px;
      border-radius: 50%;
      border: 2px solid #a3e635;
      object-fit: cover;
    }
    
    /* Мобильное меню */
    .mobile-menu {
      background: rgba(10, 10, 10, 0.98);
      backdrop-filter: blur(20px);
    }
    
    /* Разделитель секций */
    .section-divider {
      height: 1px;
      background: linear-gradient(90deg, transparent, rgba(163, 230, 53, 0.2), transparent);
      margin: 12px 0;
    }
    
    /* Заголовок секции */
    .section-title {
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: #6b7280;
      margin-bottom: 10px;
      padding-left: 4px;
    }
  </style>
</head>
<body>

<!-- Шапка -->
<header class="header-glass fixed top-0 left-0 right-0 z-50">
  <div class="max-w-[1400px] mx-auto px-4 sm:px-6">
    <div class="flex items-center justify-between h-16">
      
      <!-- Логотип -->
      <a href="/" class="flex items-center gap-2">
        <div class="w-9 h-9 rounded-xl bg-gradient-to-br from-lime-400 to-lime-600 flex items-center justify-center">
          <i class="bi bi-hexagon-fill text-dark-900 text-lg"></i>
        </div>
        <span class="logo-text">Trust Global</span>
      </a>
      
      <!-- Десктопное меню -->
      <nav class="hidden md:flex items-center gap-1">
        <a href="/" class="px-3 py-2 rounded-lg text-sm font-medium transition-all <?= $current == '/' ? 'bg-lime-400/15 text-lime-400 border border-lime-400/30' : 'text-gray-400 hover:text-lime-400 hover:bg-lime-400/10' ?>">
          <i class="bi bi-house-door mr-1"></i>Главная
        </a>
        <a href="/stats" class="px-3 py-2 rounded-lg text-sm font-medium transition-all <?= $current == '/stats' ? 'bg-lime-400/15 text-lime-400 border border-lime-400/30' : 'text-gray-400 hover:text-lime-400 hover:bg-lime-400/10' ?>">
          <i class="bi bi-bar-chart mr-1"></i>Выплаты
        </a>
        <a href="/reviews" class="px-3 py-2 rounded-lg text-sm font-medium transition-all <?= $current == '/reviews' ? 'bg-lime-400/15 text-lime-400 border border-lime-400/30' : 'text-gray-400 hover:text-lime-400 hover:bg-lime-400/10' ?>">
          <i class="bi bi-chat-heart mr-1"></i>Отзывы
        </a>
        <a href="/rules" class="px-3 py-2 rounded-lg text-sm font-medium transition-all <?= $current == '/rules' ? 'bg-lime-400/15 text-lime-400 border border-lime-400/30' : 'text-gray-400 hover:text-lime-400 hover:bg-lime-400/10' ?>">
          <i class="bi bi-clipboard-check mr-1"></i>Правила
        </a>
        <a href="/help" class="px-3 py-2 rounded-lg text-sm font-medium transition-all <?= $current == '/help' ? 'bg-lime-400/15 text-lime-400 border border-lime-400/30' : 'text-gray-400 hover:text-lime-400 hover:bg-lime-400/10' ?>">
          <i class="bi bi-envelope mr-1"></i>Контакты
        </a>
      </nav>
      
      <!-- Бургер меню -->
      <button id="burger-menu" class="md:hidden text-gray-400 hover:text-lime-400 transition">
        <i class="bi bi-list text-2xl"></i>
      </button>
    </div>
  </div>
  
  <!-- Мобильное меню -->
  <div id="mobile-menu" class="mobile-menu hidden md:hidden border-t border-lime-400/10">
    <div class="px-4 py-4 space-y-1">
      <a href="/" class="block px-4 py-3 rounded-xl <?= $current == '/' ? 'bg-lime-400/15 text-lime-400 border border-lime-400/30' : 'text-gray-400' ?>">
        <i class="bi bi-house-door mr-2"></i>Главная
      </a>
      <a href="/stats" class="block px-4 py-3 rounded-xl <?= $current == '/stats' ? 'bg-lime-400/15 text-lime-400 border border-lime-400/30' : 'text-gray-400' ?>">
        <i class="bi bi-bar-chart mr-2"></i>Выплаты
      </a>
      <a href="/reviews" class="block px-4 py-3 rounded-xl <?= $current == '/reviews' ? 'bg-lime-400/15 text-lime-400 border border-lime-400/30' : 'text-gray-400' ?>">
        <i class="bi bi-chat-heart mr-2"></i>Отзывы
      </a>
      <a href="/rules" class="block px-4 py-3 rounded-xl <?= $current == '/rules' ? 'bg-lime-400/15 text-lime-400 border border-lime-400/30' : 'text-gray-400' ?>">
        <i class="bi bi-clipboard-check mr-2"></i>Правила
      </a>
      <a href="/help" class="block px-4 py-3 rounded-xl <?= $current == '/help' ? 'bg-lime-400/15 text-lime-400 border border-lime-400/30' : 'text-gray-400' ?>">
        <i class="bi bi-envelope mr-2"></i>Контакты
      </a>
    </div>
  </div>
</header>

<!-- Основной контент -->
<div class="pt-16 min-h-screen">
  <div class="max-w-[1400px] mx-auto px-4 sm:px-6 py-6">
    <div class="flex flex-col lg:flex-row gap-6">
      
      <!-- Левая панель -->
      <aside class="w-full lg:w-[280px] flex-shrink-0">
        <div class="sticky top-24">
          
          <?php if (isset($_SESSION['uid'])): ?>
            <!-- Меню авторизованного пользователя -->
            <?php include 'inc/menu.php'; ?>
            
          <?php else: ?>
            <!-- Меню гостя - отдельные карточки -->
            <div class="menu-card">
              <h3 class="text-base font-semibold mb-3 text-gradient">Добро пожаловать</h3>
              <p class="text-gray-400 text-sm mb-4">Войдите или зарегистрируйтесь</p>
              
              <div class="space-y-2">
                <a href="/login" class="btn-lime w-full py-2.5 flex items-center justify-center gap-2 text-sm">
                  <i class="bi bi-box-arrow-in-right"></i>
                  Войти
                </a>
                <a href="/signup" class="btn-dark w-full py-2.5 flex items-center justify-center gap-2 text-sm">
                  <i class="bi bi-person-plus"></i>
                  Регистрация
                </a>
              </div>
            </div>
            
            <!-- Статистика - отдельная карточка -->
            <div class="menu-card">
              <?php include('inc/stats.php'); ?>
            </div>
            
            <!-- Приложение - отдельная карточка -->
            <a href="/base.apk" download class="menu-card flex items-center gap-3 hover:border-lime-400/30 transition">
              <div class="w-10 h-10 rounded-lg bg-lime-400/10 flex items-center justify-center flex-shrink-0">
                <i class="bi bi-android2 text-lime-400 text-lg"></i>
              </div>
              <div class="flex-1 min-w-0">
                <div class="font-medium text-sm">Android App</div>
                <div class="text-xs text-gray-400">Скачать приложение</div>
              </div>
              <i class="bi bi-download text-lime-400"></i>
            </a>
            
          <?php endif; ?>
        </div>
      </aside>
      
      <!-- Правая часть - контент -->
      <main class="flex-1 min-w-0">
        <?php if ($uid): ?>
        <div class="bubble-card p-5">
        <?php endif; ?>
