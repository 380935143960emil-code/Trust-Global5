<?php if ($uid): ?></div><?php endif; ?>
      </main>
    </div>
  </div>
</div>

<!-- Футер -->
<footer class="border-t border-lime-400/10 mt-8 bg-dark-800/50">
  <!-- Основная часть футера -->
  <div class="max-w-[1400px] mx-auto px-4 sm:px-6 py-10">
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
      
      <!-- Колонка 1 - О проекте -->
      <div>
        <div class="flex items-center gap-2 mb-4">
          <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-lime-400 to-lime-600 flex items-center justify-center">
            <i class="bi bi-hexagon-fill text-dark-900 text-sm"></i>
          </div>
          <span class="text-lg font-bold text-gradient">Trust Global</span>
        </div>
        <p class="text-gray-400 text-sm leading-relaxed mb-4">
          Инвестиционная платформа с пассивным доходом. Начните зарабатывать уже сегодня!
        </p>
        <div class="flex items-center gap-3">
          <a href="https://t.me/TrustMintSupportbot" target="_blank" class="w-9 h-9 rounded-lg bg-dark-700 flex items-center justify-center text-gray-400 hover:bg-lime-400/10 hover:text-lime-400 transition">
            <i class="bi bi-telegram"></i>
          </a>
          <a href="mailto:<?=$config->email;?>" class="w-9 h-9 rounded-lg bg-dark-700 flex items-center justify-center text-gray-400 hover:bg-lime-400/10 hover:text-lime-400 transition">
            <i class="bi bi-envelope"></i>
          </a>
        </div>
      </div>
      
      <!-- Колонка 2 - Навигация -->
      <div>
       <!-- <h4 class="font-semibold mb-4 text-sm uppercase tracking-wider text-gray-300">Навигация</h4>
        <nav class="space-y-2">
          <a href="/" class="block text-gray-400 hover:text-lime-400 transition text-sm">
            <i class="bi bi-chevron-right text-xs mr-1"></i>Главная
          </a>
          <a href="/stats" class="block text-gray-400 hover:text-lime-400 transition text-sm">
            <i class="bi bi-chevron-right text-xs mr-1"></i>Выплаты
          </a>
          <a href="/reviews" class="block text-gray-400 hover:text-lime-400 transition text-sm">
            <i class="bi bi-chevron-right text-xs mr-1"></i>Отзывы
          </a>
          <a href="/rules" class="block text-gray-400 hover:text-lime-400 transition text-sm">
            <i class="bi bi-chevron-right text-xs mr-1"></i>Правила
          </a>
          <a href="/help" class="block text-gray-400 hover:text-lime-400 transition text-sm">
            <i class="bi bi-chevron-right text-xs mr-1"></i>Контакты
          </a>
        </nav>-->
      </div>
      
      <!-- Колонка 3 - Личный кабинет -->
      <div>
        <!--<h4 class="font-semibold mb-4 text-sm uppercase tracking-wider text-gray-300">Личный кабинет</h4>
        <nav class="space-y-2">
          <a href="/user/dashboard" class="block text-gray-400 hover:text-lime-400 transition text-sm">
            <i class="bi bi-chevron-right text-xs mr-1"></i>Кабинет
          </a>
          <a href="/user/galaxy" class="block text-gray-400 hover:text-lime-400 transition text-sm">
            <i class="bi bi-chevron-right text-xs mr-1"></i>Покупка Galaxy
          </a>
          <a href="/user/insert" class="block text-gray-400 hover:text-lime-400 transition text-sm">
            <i class="bi bi-chevron-right text-xs mr-1"></i>Пополнить
          </a>
          <a href="/user/pay" class="block text-gray-400 hover:text-lime-400 transition text-sm">
            <i class="bi bi-chevron-right text-xs mr-1"></i>Вывести
          </a>
          <a href="/user/refs" class="block text-gray-400 hover:text-lime-400 transition text-sm">
            <i class="bi bi-chevron-right text-xs mr-1"></i>Рефералы
          </a>
        </nav>-->
      </div>
      
      <!-- Колонка 4 - Платежные системы -->
      <div>
        <h4 class="font-semibold mb-4 text-sm uppercase tracking-wider text-gray-300">Платёжные системы</h4>
        <div class="flex flex-wrap gap-2">
          <div class="w-10 h-10 rounded-lg bg-dark-700 flex items-center justify-center hover:bg-lime-400/10 transition">
            <img src="/img/azvox.png" class="w-6 h-6 object-contain" alt="Azvox">
          </div>
          <div class="w-10 h-10 rounded-lg bg-dark-700 flex items-center justify-center hover:bg-lime-400/10 transition">
            <img src="/img/pay/faucetpay.png" class="w-6 h-6 object-contain" alt="Faucetpay">
          </div>
          <div class="w-10 h-10 rounded-lg bg-dark-700 flex items-center justify-center hover:bg-lime-400/10 transition">
            <img src="/img/pay/bitcoin.png" class="w-6 h-6 object-contain" alt="Bitcoin">
          </div>
          <div class="w-10 h-10 rounded-lg bg-dark-700 flex items-center justify-center hover:bg-lime-400/10 transition">
            <img src="/img/pay/tron.png" class="w-6 h-6 object-contain" alt="Tron">
          </div>
          <div class="w-10 h-10 rounded-lg bg-dark-700 flex items-center justify-center hover:bg-lime-400/10 transition">
            <img src="/img/pay/tron_trc20.png" class="w-6 h-6 object-contain" alt="Tron_trc20">
          </div>
        </div>
        
        <div class="mt-4 p-3 rounded-lg bg-lime-400/5 border border-lime-400/10">
          <div class="flex items-center gap-2 text-xs text-gray-400">
            <i class="bi bi-shield-check text-lime-400"></i>
            <span>Безопасные платежи</span>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <!-- Нижняя часть футера -->
  <div class="border-t border-lime-400/10">
    <div class="max-w-[1400px] mx-auto px-4 sm:px-6 py-4">
      <div class="flex flex-col md:flex-row items-center justify-between gap-4">
        <div class="text-gray-500 text-sm">
          © 2026 Trust Global. Все права защищены.
        </div>
        <div class="flex items-center gap-6 text-sm">
          <a href="/rules" class="text-gray-500 hover:text-lime-400 transition">Правила</a>
          <a href="/help" class="text-gray-500 hover:text-lime-400 transition">Поддержка</a>
        </div>
      </div>
    </div>
  </div>
</footer>

<?PHP
if (!empty($pg->segment[1] === 'task')) {
?>
<script src="/assets/js/task.js"></script>
<? } ?>
<?php 
if (!empty($pg->segment[1] === 'surf')) {
?>
<script src="/assets/js/surf.js"></script>
<? } ?>
<?PHP
if (!empty($pg->segment[1] === 'vsurf')) {
?>
<script src="/assets/js/surfv.js"></script>
<? } ?>

<script>
  // Бургер меню
  const burgerMenu = document.getElementById('burger-menu');
  const mobileMenu = document.getElementById('mobile-menu');
  
  if (burgerMenu && mobileMenu) {
    burgerMenu.addEventListener('click', () => {
      mobileMenu.classList.toggle('hidden');
    });
  }
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
