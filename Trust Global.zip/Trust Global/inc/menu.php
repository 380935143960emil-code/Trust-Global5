<?php
// Получаем данные пользователя
$users = $db->query("SELECT login, money_p, money_b, refs FROM db_users WHERE id = ?", [$uid])->fetchArray();

$login       = htmlspecialchars($users['login']);
$balanceMain = number_format($users['money_p'], 2, '.', ' ');
$balanceAds  = number_format($users['money_b'], 2, '.', ' ');
$refs        = number_format($users['refs'], 0, '', ' ');

// Проверка активного URL
function isActiveMenu($url) {
    return strpos($_SERVER['REQUEST_URI'], $url) !== false ? 'active' : '';
}

$rowView = $db->query('SELECT link, uid FROM db_surf_views WHERE uid = '.$uid.' AND time_end > '.time().' LIMIT 50')->fetchAll();

$visits = array();
foreach ($rowView as $rv) {
    $visits[$rv['link']] = $rv;
}

$numm = $db->query("SELECT * FROM db_surf WHERE `balance` >= `price_click` AND `status` = '1'")->fetchAll();

$i = 0;
foreach ($numm as $row) {
    if (isset($visits[$row['id']])) continue;
    $i++;
}


$uploadError = '';
$uploadSuccess = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['avatar'])) {
    $targetDir = "avatars/";
    
    
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }
    
    $file = $_FILES['avatar'];
    
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $uploadError = 'Ошибка загрузки файла: ' . $file['error'];
    } else {
        $fileName = basename($file["name"]);
        $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        
        $allowedTypes = array('jpg', 'jpeg', 'png', 'gif');
        if (!in_array($fileType, $allowedTypes)) {
            $uploadError = 'Неверный формат файла. Поддерживаются JPG, JPEG, PNG, GIF';
        } else {
            $check = getimagesize($file["tmp_name"]);
            if ($check === false) {
                $uploadError = 'Файл не является изображением.';
            } elseif ($file["size"] > 5000000) {
                $uploadError = 'Размер файла слишком большой. Максимальный размер: 5MB.';
            } else {
                $uniqueFileName = md5(uniqid('', true));
                $newFileName = $uniqueFileName . "_u" . $uid . '.' . $fileType;
                $targetFile = $targetDir . $newFileName;
                
                if (move_uploaded_file($file["tmp_name"], $targetFile)) {
                    $query = "UPDATE db_users SET avatar = ? WHERE id = ?";
                    $db->query($query, [$newFileName, $uid]);  // <-- Исправлено: массив параметров
                    
                    if ($db->affectedRows() > 0) {
                        header('Location: ' . $_SERVER['REQUEST_URI']);
                        exit;
                    } else {
                        $uploadError = 'Ошибка обновления базы данных!';
                        unlink($targetFile); // Удаляем загруженный файл
                    }
                } else {
                    $uploadError = 'Ошибка перемещения файла. Проверьте права на папку avatars/';
                }
            }
        }
    }
}


if (!empty($uploadError)) {
    echo '<script>Swal.fire("' . addslashes($uploadError) . '", "", "error");</script>';
}

$us = $db->query('SELECT avatar FROM db_users WHERE id = ?', $uid)->fetchArray();
$avatarPath = '/avatars/' . htmlspecialchars($us['avatar']);
$defaultAvatar = '/avatars/4.png';
$avatarToShow = (!empty($us['avatar']) && file_exists($_SERVER['DOCUMENT_ROOT'] . $avatarPath)) ? $avatarPath : $defaultAvatar;

// Подсчёт новых сообщений поддержки
$nickticket = 'Поддержка';
$new_support_msgs = $db->query("
    SELECT COUNT(*) as cnt
    FROM db_support s
    JOIN db_ot_sup o ON o.id_mes = s.id
    WHERE s.uid = '$uid'
      AND o.user = '$nickticket'
      AND o.date > s.last_read
")->fetchArray();
$new_count = intval($new_support_msgs['cnt']);

$shortLogin = mb_strlen($login) > 12 ? mb_substr($login, 0, 12) . '...' : $login;
?>

<!-- Карточка профиля -->
<div class="menu-card">
  <div class="flex items-center gap-3 mb-4">
    <div class="relative">
      <img src="<?= $avatarToShow; ?>" alt="Avatar" class="avatar-bubble" id="avatarImage">
      <button onclick="document.getElementById('avatarInput').click()" class="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-lime-400 text-dark-900 flex items-center justify-center hover:bg-lime-500 transition">
        <i class="bi bi-camera text-[10px]"></i>
      </button>
      <form method="POST" enctype="multipart/form-data" class="hidden">
        <input type="file" name="avatar" id="avatarInput" accept="image/*" onchange="this.form.submit()">
      </form>
    </div>
    <div class="flex-1 min-w-0">
      <div class="flex items-center gap-2">
        <span class="font-semibold text-sm truncate"><?= htmlspecialchars($shortLogin) ?></span>
        <?php if ($user['is_vip'] == 1): ?>
          <span class="badge-vip">VIP</span>
        <?php endif; ?>
      </div>
      <div class="text-xs text-gray-400">Investor</div>
    </div>
  </div>
  
          <!-- Иконки действий -->
    <div class="flex items-center justify-center gap-6 w-full mt-2">
      <!-- Telegram канал -->
      <a href="https://t.me/your_channel" target="_blank" class="w-8 h-8 rounded-lg bg-[#229ED9]/10 hover:bg-[#229ED9]/20 border border-[#229ED9]/20 flex items-center justify-center transition-all hover:scale-110 group relative">
        <i class="bi bi-telegram text-[#229ED9] text-sm group-hover:scale-110 transition-transform"></i>
        <span class="absolute -bottom-6 left-1/2 -translate-x-1/2 text-[9px] text-gray-500 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">Канал</span>
      </a>
      
      <!-- Telegram чат -->
      <a href="https://t.me/your_chat" target="_blank" class="w-8 h-8 rounded-lg bg-lime-400/10 hover:bg-lime-400/20 border border-lime-400/20 flex items-center justify-center transition-all hover:scale-110 group relative">
        <i class="bi bi-chat-dots text-lime-400 text-sm group-hover:scale-110 transition-transform"></i>
        <span class="absolute -bottom-6 left-1/2 -translate-x-1/2 text-[9px] text-gray-500 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">Чат</span>
      </a>
      
      <!-- Техподдержка -->
      <a href="/user/ticket" class="w-8 h-8 rounded-lg bg-cyan-400/10 hover:bg-cyan-400/20 border border-cyan-400/20 flex items-center justify-center transition-all hover:scale-110 group relative">
        <i class="bi bi-headset text-cyan-400 text-sm group-hover:scale-110 transition-transform"></i>
        <?php if($new_count > 0): ?>
          <span class="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[8px] font-bold rounded-full flex items-center justify-center animate-pulse border-2 border-dark-800">
            <?= $new_count > 9 ? '9+' : $new_count ?>
          </span>
        <?php endif; ?>
        <span class="absolute -bottom-6 left-1/2 -translate-x-1/2 text-[9px] text-gray-500 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">Поддержка</span>
      </a>
      
      <!-- Уведомления (колокольчик) -->
      <button onclick="toggleNotifications()" class="w-8 h-8 rounded-lg bg-yellow-400/10 hover:bg-yellow-400/20 border border-yellow-400/20 flex items-center justify-center transition-all hover:scale-110 group relative">
        <i class="bi bi-bell text-yellow-400 text-sm group-hover:scale-110 transition-transform"></i>
        <span class="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full animate-pulse border border-dark-800"></span>
        <span class="absolute -bottom-6 left-1/2 -translate-x-1/2 text-[9px] text-gray-500 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">Alerts</span>
      </button>
    </div>
  <br>
  <!-- Балансы -->
  <div class="space-y-2">
    <a href="/user/paymentes" class="flex items-center justify-between p-2.5 rounded-lg bg-dark-700/50 hover:bg-dark-600 transition">
      <div class="flex items-center gap-2">
        <div class="w-8 h-8 rounded-lg bg-red-500/10 flex items-center justify-center">
          <i class="bi bi-wallet2 text-red-400 text-sm"></i>
        </div>
        <div>
          <div class="text-[10px] text-gray-400">Баланс вывода</div>
          <div class="font-semibold text-red-400 text-sm"><?= $balanceMain ?> $</div>
        </div>
      </div>
      <i class="bi bi-chevron-right text-gray-500 text-xs"></i>
    </a>
    
    <a href="/user/insertts" class="flex items-center justify-between p-2.5 rounded-lg bg-dark-700/50 hover:bg-dark-600 transition">
      <div class="flex items-center gap-2">
        <div class="w-8 h-8 rounded-lg bg-lime-400/10 flex items-center justify-center">
          <i class="bi bi-wallet text-lime-400 text-sm"></i>
        </div>
        <div>
          <div class="text-[10px] text-gray-400">Баланс депозита</div>
          <div class="font-semibold text-lime-400 text-sm"><?= $balanceAds ?> $</div>
        </div>
      </div>
      <i class="bi bi-chevron-right text-gray-500 text-xs"></i>
    </a>
  </div>
  
  <!-- Кнопки действий -->
  <div class="grid grid-cols-2 gap-2 mt-3">
    <a href="/user/insertts" class="btn-lime py-2 flex items-center justify-center gap-1 text-xs">
      <i class="bi bi-arrow-up-circle"></i>
      Пополнить
    </a>
    <a href="/user/paymentes" class="btn-dark py-2 flex items-center justify-center gap-1 text-xs">
      <i class="bi bi-arrow-down-circle"></i>
      Вывести
    </a>
  </div>
</div>

<!-- Карточка меню навигации - Основное -->
<div class="menu-card">
  <div class="section-title">Основное</div>
  <nav class="space-y-1">
    <a href="/user/dashboard" class="menu-item <?= isActiveMenu('/user/dashboard') ?>">
      <i class="bi bi-house-door-fill"></i>
      <span>Личный кабинет</span>
    </a>
    <a href="/user/cards" class="menu-item <?= isActiveMenu('/user/cards') ?>">
      <i class="bi bi-credit-card-fill text-cyan-400"></i>
      <span>Карты</span>
    </a>
    <a href="/user/mycards" class="menu-item <?= isActiveMenu('/user/mycards') ?>">
      <i class="bi bi-credit-card-2-back-fill text-lime-400"></i>
      <span>Мои карты</span>
    </a>
    <!--<a href="/user/surfing" class="menu-item <?= isActiveMenu('/user/surfing') ?>">
      <i class="bi bi-eye-fill text-cyan-400"></i>
      <span>Серфинг</span>
      <?php if($countViews > 0): ?>
        <span class="ml-auto badge-lime"><?= $countViews ?></span>
      <?php endif; ?>
    </a>-->
  </nav>
</div>

<!-- Карточка меню - Бонусы -->
<div class="menu-card">
  <div class="section-title">Бонусы</div>
  <nav class="space-y-1">
    <a href="/user/rewards" class="menu-item <?= isActiveMenu('/user/rewards') ?>">
      <i class="bi bi-trophy-fill text-cyan-400"></i>
      <span>Награды</span>
    </a>
  </nav>
</div>

<!-- Карточка меню - Финансы -->
<!--<div class="menu-card">
  <div class="section-title">Финансы</div>
  <nav class="space-y-1">
    <a href="/user/insert" class="menu-item <?= isActiveMenu('/user/insert') ?>">
      <i class="bi bi-plus-circle text-lime-400"></i>
      <span>Пополнить</span>
    </a>
    <a href="/user/pay" class="menu-item <?= isActiveMenu('/user/pay') ?>">
      <i class="bi bi-dash-circle text-red-400"></i>
      <span>Вывести</span>
    </a>
  </nav>
</div>-->

<!-- Карточка меню - Партнёры -->
<div class="menu-card">
  <div class="section-title">Партнёры</div>
  <nav class="space-y-1">
    <a href="/user/refs" class="menu-item <?= isActiveMenu('/user/refs') ?>">
      <i class="bi bi-people-fill text-blue-400"></i>
      <span>Мои рефералы</span>
      <span class="ml-auto badge-lime"><?= $refs ?></span>
    </a>
  </nav>
</div>

<!-- Карточка меню - Поддержка -->
<!--<div class="menu-card">
  <div class="section-title">Поддержка</div>
  <nav class="space-y-1">
    <a href="/user/ticket" class="menu-item <?= isActiveMenu('/user/ticket') ?> relative">
      <i class="bi bi-headset text-cyan-400"></i>
      <span>Тех. поддержка</span>
      <?php if($new_count > 0): ?>
        <span class="absolute right-2 top-1/2 -translate-y-1/2 w-5 h-5 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse">
          <?= $new_count ?>
        </span>
      <?php endif; ?>
    </a>
    <a href="https://t.me/luckgalaxy" target="_blank" class="menu-item">
      <i class="bi bi-telegram text-blue-400"></i>
      <span>Telegram чат</span>
      <span class="ml-auto text-[10px] bg-lime-400 text-dark-900 px-2 py-0.5 rounded-full font-bold animate-pulse">NEW</span>
    </a>
  </nav>
</div>-->

<!-- Карточка меню - Система -->
<div class="menu-card">
  <div class="section-title">Система</div>
  <nav class="space-y-1">
    <a href="/user/settings" class="menu-item <?= isActiveMenu('/user/settings') ?>">
      <i class="bi bi-gear text-gray-400"></i>
      <span>Настройки</span>
    </a>
    <a href="/user/logout" class="menu-item text-red-400 hover:text-red-300 hover:bg-red-400/10">
      <i class="bi bi-box-arrow-right"></i>
      <span>Выйти</span>
    </a>
  </nav>
</div>
