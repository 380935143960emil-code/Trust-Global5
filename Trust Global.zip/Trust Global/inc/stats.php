<?php
# Статистика
$stats = $db->query("SELECT * FROM db_stats WHERE id = '1'")->fetchArray();

# Количество 24 часа
$times = time() - 60*60*24;
$users_rows = $db->query("SELECT reg FROM `db_users` WHERE `reg` > '$times'")->numRows();
$users24 = $users_rows;

function num2word($num = 0, $words = array())
{
    $num     = (int) $num;
    $cases   = array(2, 0, 1, 1, 1, 2);
    return $num . '' . $words[($num % 100 > 4 && $num % 100 < 20) ? 2 : $cases[min($num % 10, 5)]];
}
$prworks = intval(((time() - $config->start_time) / 86400 ) +1)+1;
 
session_start(); 
$activeUsersFile = 'active_users.txt'; 
$sessionTimeout = 5 * 60; 
$currentTime = time(); 
$activeUsers = file_exists($activeUsersFile) ? unserialize(file_get_contents($activeUsersFile)) : [];

foreach ($activeUsers as $ip => $timestamp) {
    if ($currentTime - $timestamp > $sessionTimeout) {
        unset($activeUsers[$ip]);
    }
}

$activeUsers[$_SERVER['REMOTE_ADDR']] = $currentTime; 
file_put_contents($activeUsersFile, serialize($activeUsers)); 
$activeCount = count($activeUsers);
?>

<div class="text-center mb-4">
  <div class="flex items-center justify-center gap-2 mb-4">
    <i class="bi bi-bar-chart-fill text-lime-400 text-lg"></i>
    <span class="text-lg font-semibold">Онлайн</span>
  </div>

  <div class="grid grid-cols-1 gap-3">
    <!-- Онлайн -->
    <div class="bubble-card p-2 text-center">
      <div class="text-2xl font-bold text-lime-400 mb-1"><?= $activeCount+124 ?></div>
      <!--<div class="text-xs text-gray-400">Онлайн</div>-->
    </div>

    <!-- Пополнено -->
    <!--<div class="bubble-card p-4 text-center">
      <div class="text-2xl font-bold text-lime-400 mb-1"><?= number_format(round($stats['inserts'], 2), 0, '.', ' ') ?> ₽</div>
      <div class="text-xs text-gray-400">Пополнено</div>
    </div>

    <!-- Выплачено -->
    <!--<div class="bubble-card p-4 text-center">
      <div class="text-2xl font-bold text-red-400 mb-1"><?= number_format(round($stats['payments'], 2), 0, '.', ' ') ?> ₽</div>
      <div class="text-xs text-gray-400">Выплачено</div>
    </div>

    <!-- Пользователей -->
    <!--<div class="bubble-card p-4 text-center">
      <div class="text-2xl font-bold text-blue-400 mb-1"><?= number_format(round($stats['users'], 2), 0, '.', ' ') ?></div>
      <div class="text-xs text-gray-400">Пользователей</div>
    </div>

    <!-- Работаем дней -->
    <!--<div class="bubble-card p-4 text-center col-span-2">
      <div class="text-2xl font-bold text-cyan-400 mb-1"><?= num2word($prworks)+2; ?> дн</div>
      <div class="text-xs text-gray-400">Работаем</div>
    </div>-->
  </div>
</div>
