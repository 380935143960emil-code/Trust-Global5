<?php
//session_start();
$id = intval($pg->params[1]);

if (!isset($_SESSION['uid'])) { exit(); }

$nums = $db->query("SELECT * FROM db_surfv WHERE id = '".$id."' and balance >= price_click and status = '1' LIMIT 1")->numRows();
if ($nums >= 1){
$list = $db->query("SELECT * FROM db_surfv WHERE id = '$id'")->fetchArray();
$price = $list['price_click'];

	$_SESSION['view']['cnt'] = md5(session_id().$list['uid'].$list['id']);
	$_SESSION['view']['id'] = $list['id'];
	$_SESSION['view']['timer'] = $list['timer'];
	$_SESSION['view']['timestart'] = time();

$opt = array('title' => false,'description' => false);
 
$url = $list['url2'];
 
preg_match('/(?:https?:\/\/(?:www\.)?youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=|\S*?\/)([a-zA-Z0-9_-]{11}))/i', $url, $matches);
 
$videoId = isset($matches[1]) ? $matches[1] : null; 
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="robots" content="none" />
	<title>Просмотр: <?=$list['title'];?></title>
	<link href="https://fonts.googleapis.com/css?family=Play" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Pangolin" rel="stylesheet">
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<link href="/assets/css/framev.css?v2" rel="stylesheet" type="text/css">
	<link href="/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
</head>
	<body>

<style type="text/css">
.video {
  height: 0;
  position: relative;
  padding-bottom: 56.25%;
}
.video iframe {
 position: absolute;
 width: 100%;min-height: 77%;
}
</style>

<script type="text/javascript">
		var vtime = stattime = <?=$_SESSION['view']['timer']?>;
		var cnt = '<?=$_SESSION['view']['cnt'];?>';
		startClock();
		
        function startClock() {
            if (vtime == stattime) {
                document.getElementById('blockwait').style.display = 'none';
                document.getElementById('blocktimer').style.display = '';
            }
            if (vtime >= 0) {
                document.forms['frm'].clock.value = vtime;
                vtime --;
                tm = setTimeout("startClock()", 1000);
                cptfix=1;
            } else {
                if (tm)
                    clearTimeout(tm);
                nextstep(0, cnt);
                cptfix=1;
            }
        }
	</script>
	
	
	
<script>
        // Load the IFrame Player API code asynchronously.
  var tag = document.createElement('script');
  tag.src = "https://www.youtube.com/player_api";
  var firstScriptTag = document.getElementsByTagName('script')[0];
  firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
      var player;
      function onYouTubeIframeAPIReady() {
        player = new YT.Player('player', {
          height: $(document).outerHeight(true)-80,
          width: $(document).width(),
          videoId: '<?=$videoId?>',
          playerVars: {'autoplay': 0},
          events: {
            'onReady': onPlayerReady,
            'onStateChange': onPlayerStateChange,
          }
        });
      }

      // 4. The API will call this function when the video player is ready.
        vpstatus = false;
      function onPlayerReady(event) {
        player.mute();
        vpstatus = (event.data == YT.PlayerState.PLAYING) ? true : false;
        event.target.setVolume(84);
		document.getElementById("check").innerHTML='<span style="color:#fff;">Запустите видео!</span>';
        //event.target.playVideo();
      }


      function onPlayerStateChange(event) {
          vpstatus = (event.data == YT.PlayerState.PLAYING) ? true : false;
        if (event.data === YT.PlayerState.ENDED) {
           // player.playVideo(); 
        }
      }
    </script>
	
	

	<script type="text/javascript">
function stopVideo(){alert('stop');}	
//function stopVideo(){clearTimeout(TTimer);document.getElementById("check").innerHTML='<span style="color:#be0525;">Включите видео!</span>';focus=0;}
//	function onPlayerStateChange(event) {console.log("ass");document.getElementById("check").innerHTML='Дождитесь окончания таймера:<div class="timer notranslate" id="timer">'+time+'</div>';timerStart();focus=1;}

	
	
  function getXMLHTTP() {
    var xmlhtmp=null;
    if(window.XMLHttpRequest) {
      xmlhtmp=new XMLHttpRequest();
    } 
    else if(window.ActiveXObject) {
      xmlhtmp=new ActiveXObject("Microsoft.XMLHTTP");
    }
    return xmlhtmp;
  }
  var cptfix=0;
  var cptcode=0;
  var focus=1;
  var focuscheck=1;
  var time=<?=$_SESSION['view']['timer']?>;
  var TTimer;
  function timerStep() {
    if(time<0) {
      time=0;
      cptfix=1;
      checkClick();
      return;
    }
    else
    {
      if(document.getElementById("timer")!=null) {
        time--;
        document.getElementById("timer").innerHTML=time;
        if(time==0) {
          clearTimeout(TTimer);
          cptfix=1;
          getCaptcha();
        }
        else
        {
          TTimer=setTimeout(timerStep, 1000);
        }
      }
    }
  }

  
  
   function hasIsFocus() {
    if(cptfix==0) {
      if(document.hasFocus() && vpstatus == true) {
        if(focus==0) {
          console.log("ass");
          document.getElementById("check").innerHTML='Дождитесь окончания таймера:<div class="timer notranslate" id="timer">'+time+'</div>';
          timerStart();
          focus=1;
        }
      }
      else
      {
        if(focus==1) {
          clearTimeout(TTimer);
          document.getElementById("check").innerHTML='<span style="color:#be0525;">Окно не активно! Не уходите с вкладки!</span>';
          focus=0;
        }
      }
	  
    }
  }

  function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  function changeCpt(num) {
    cptcode=num;
    checkClick();
  }

  function loadArguments() {
    var xmlh=getXMLHTTP();
    xmlh.onreadystatechange=function() {
      if(xmlh.readyState==4 && xmlh.status==200) {
        if(xmlh.responseText!='') {
          $("#check").append(xmlh.responseText);
        }
      }
    };
    xmlh.open("GET", "/ajax/surfv/coin.php", true);
    xmlh.setRequestHeader("Content-Type", "text/xml")
    xmlh.send(null);
  }

  function getCaptcha() {
    document.getElementById('check').style.display = 'none';
    nextstep(0, cnt);
  }

  function checkFocus() {
    setInterval(hasIsFocus, 100);
  }

  function timerStart() {
    clearTimeout(TTimer);
    TTimer=setTimeout(timerStep, 1000);
  }

  function checkClick() {
    var xmlh=getXMLHTTP();
    xmlh.onreadystatechange=function() {
      if(xmlh.readyState==4 && xmlh.status==200) {
        if(xmlh.responseText!='time_error' && xmlh.responseText!='create_error' && xmlh.responseText!='captcha_error') {
          window.location.href = '';
        }
        else if(xmlh.responseText=='captcha_error') {
          getCaptcha();
        }
        else
        {
          document.getElementById("check").innerHTML='Просмотр не засчитан! Повторите позже';
        }
      }
    };
    //xmlh.open("GET", "", true);
    //xmlh.setRequestHeader("Content-Type", "text/xml")
    //xmlh.send(null);
    document.getElementById("check").innerHTML='Подождите, загрузка сайта...';
  }

  setTimeout(function() {
    timerStart();
    if (focuscheck == 1) {
      checkFocus();
    }
    document.getElementById('blockwait').style.display = 'none';
  }, 1000);

 //});
 //});
 
 
 
 
 
 function getHTTPRequest()
{
    var req = false;
    try {
        req = new XMLHttpRequest();
    } catch(err) {
        try {
            req = new ActiveXObject("MsXML2.XMLHTTP");
        } catch(err) {
            try {
                req = new ActiveXObject("Microsoft.XMLHTTP");
            } catch(err) {
                req = false;
            }
        }
    }
    return req;
}

function vernum(vnum) {
    nextstep(vnum, cnt);
    return false;
}
                        
function nextstep(num, cnt)
{
    var myReq = getHTTPRequest();
	 var params = "num="+num+"&cnt="+cnt;
    // var params = "num="+num+"&cnt="+cnt; 
	 //&recaptchaResponse="+recaptchaResponse;

    function setstate()
    {
        if ((myReq.readyState == 4)&&(myReq.status == 200)) {
            var resvalue = myReq.responseText;
            
            if (resvalue != '') {
                //console.log("->"+resvalue);
                if (resvalue.substr(0, 2) == 'OK') { 
                    vars = resvalue.split(";"); 
                    //console.log("->"+vars+"->"+vars[2]);
                    document.getElementById("blockverify").innerHTML = '<div class="blocksuccess">Спасибо за посещение!<br /><span>Плата за просмотр ('+vars[1]+' руб.) зачислена</span></div>';
                    if ((vars[2] != '0')&&(vars[2].length > 1)) {
                        setTimeout("top.location = '"+vars[2]+"'", 500);
                    }
                } else
                if (resvalue == '0')
                    //alert(resvalue);
                    document.getElementById("blockverify").innerHTML = '<div class="blockerror">Действие не произведено</div>';
                else
                    document.getElementById("blockverify").innerHTML = resvalue;
                    if(resvalue=='Успех!'){
                        setTimeout(function(){
							window.location.href = "https://www.youtube.com/watch?v=<?=$videoId?>";
						}, 4000);
                    }
            }
        } else {
            document.getElementById("blockverify").innerHTML = "<span class='loading' title='Подождите пожалуйста...'></span>";
        }
    }
    myReq.open("POST", "/ajax/surfv/coin.php", true);
    myReq.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    myReq.setRequestHeader("Content-lenght", params.length);
    //myReq.setRequestHeader("Connection", "close");
    myReq.onreadystatechange = setstate;
    myReq.send(params);
    return false;
}
  </script>
 
<div class="center">
	<div class="table-row">
		<div class="table-col col-left"> 
			<div class="loadwait">
				<div id="check">Дождитесь окончания таймера:<div class="timer notranslate" id="timer"><?=$_SESSION['view']['timer']?></div></div>
				<div id="blockverify">
					<div id="blockwait">Подождите, сайт загружается...</div>
					<div id="blocktimer" style="display: none;">
						<form class="clockalert" name="frm" method="post" action="" onsubmit="return false;">
							<!--<input type="hidden" name="recaptchaResponse" id="recaptchaResponse">-->
							<input name="clock" size="3" readonly="readonly" type="text" value=""/><br />
							<span></span>
						</form>
					</div>
				</div>
			</div>
		</div> 
		<div class="table-col col-right">
			<a href="<?=$list['url'];?>" class="btn btn-primary m-2" target="_blank">Перейти</a>
			</div>
		</div>		
	</div>
</div>

<div id="player"></div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 
</body>
</html>
<?php
} else {
	exit('Не существует или закончились просмотры');
}
?> 