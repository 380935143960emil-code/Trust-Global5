function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

$(function(){
    function showAlert(title, text, icon) {
        Swal.fire({
            title: title,
            text: text,
            icon: icon, // success | error | warning | info | question
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'ОК'
        });
    }

    $('#task_add').submit(function(){
        var url = '/ajax.php?action=task&type=' + $("#type").val();
        var data = $(this).serialize() + '&ajax=1';
        $.post(url, data, function(result){
            if(result['id'] != ''){
                $('#' + result['id']).addClass('is-invalid');
            }
            showAlert(result['title'], result['error'], result['status']);
            if(result['status'] === 'success' && result['redirect'] != ''){
                setTimeout(function(){
                    window.location.replace(result['redirect']);
                }, 1000);
            }
        }, 'json');
        return false;
    });

    $('#task_edit').submit(function(){
        var url = '/ajax.php?action=task&type=' + $("#type").val();
        var data = $(this).serialize() + '&ajax=1';
        $.post(url, data, function(result){
            if(result['id'] != ''){
                $('#' + result['id']).addClass('is-invalid');
            }
            showAlert(result['title'], result['error'], result['status']);
            if(result['status'] === 'success' && result['redirect'] != ''){
                setTimeout(function(){
                    window.location.replace(result['redirect']);
                }, 1000);
            }
        }, 'json');
        return false;
    });

    $('.balance_add').submit(function(){
        var url = '/ajax.php?action=task&type=' + $("#type").val();
        var number_count = $('#number_count').html();
        var data = $(this).serialize() + '&number_count=' + number_count + '&ajax=1';
        $.post(url, data, function(result){
            if(result['id'] != ''){
                $('#' + result['id']).addClass('is-invalid');
            }
            showAlert(result['title'], result['error'], result['status']);
            if(result['status'] === 'success'){
                $('#number_count').html(result['number_count']);
                if(result['redirect'] != ''){
                    setTimeout(function(){
                        window.location.replace(result['redirect']);
                    }, 1000);
                }
            }
        }, 'json');
        return false;
    });

    $('#send_check').submit(function(){
        var url = '/ajax.php?action=task&type=' + $("#type").val();
        var data = $(this).serialize() + '&ajax=1';
        $.post(url, data, function(result){
            if(result['id'] != ''){
                $('#' + result['id']).addClass('is-invalid');
            }
            showAlert(result['title'], result['error'], result['status']);
            if(result['status'] === 'success' && result['redirect'] != ''){
                setTimeout(function(){
                    window.location.replace(result['redirect']);
                }, 1000);
            }
        }, 'json');
        return false;
    });

    $(document).on('click', '.delete_task', function() {
        var task_id = $(this).attr('task_id');
        var money = $(this).attr('money');
        $.post('/ajax.php?action=task&type=delete', {task_id: task_id, money: money}, function(result){
            showAlert(result['title'], result['error'], result['status']);
            if(result['status'] === 'success'){
                $('#task_' + task_id).remove();
            }
        }, 'json');
        return false;
    });

     
    $(document).on('click', '.status_task', function() {
        var button = $(this);
        var task_id = button.attr('task_id');
        var status = button.attr('action');
        $.post('/ajax.php?action=task&type=status', {task_id: task_id, status: status}, function(result){
            showAlert(result['title'], result['error'], result['status']);
            if(result['status'] === 'success'){
                if(status === 'active'){
                    button.attr('action', 'deactive');
                    button.html('<i class="bi bi-pause-fill"></i>');
                    button.removeClass('btn-success').addClass('btn-warning');
                } else if(status === 'deactive'){
                    button.attr('action', 'active');
                    button.html('<i class="bi bi-play-fill"></i>');
                    button.removeClass('btn-warning').addClass('btn-success');
                }
            }
        }, 'json');
        return false;
    });

    $(document).on('click', '.task_rating', function() {
        var button = $(this);
        var task_id = button.attr('task_id');
        var rating = button.attr('rating');
        var this_rating = $('#' + rating).html();
        $.post('/ajax.php?action=task&type=rating', {task_id: task_id, rating: rating, this_rating: this_rating}, function(result){
            showAlert(result['title'], result['error'], result['status']);
            if(result['status'] === 'success'){
                $('#' + rating).html(result['update']);
            }
        }, 'json');
        return false;
    });

    $(document).on('click', '.approve_task', function() {
        var task_id = $(this).attr('task_id');
        $.post('/ajax.php?action=task&type=approve', {task_id: task_id}, function(result){
            showAlert(result['title'], result['error'], result['status']);
            if(result['status'] === 'success'){
                $('#task_' + task_id).remove();
            }
        }, 'json');
        return false;
    });

    $(document).on('click', '.run_task', function() {
        var task_id = $(this).attr('task_id');
        $.post('/ajax.php?action=task&type=run', {task_id: task_id}, function(result){
            showAlert(result['title'], result['error'], result['status']);
            if(result['status'] === 'success'){
                setTimeout(function(){
                    window.open(result['redirect']);
                }, 1000);
            }
        }, 'json');
        return false;
    });

    $(document).on('click', '.do_progress', function() {
        var task_id = $(this).attr('task_id');
        $('#do_progress_' + task_id).submit();
    });

    $(document).on('click', '.bi-arrow-up', function() {
        var task_id = $(this).attr('task_id');
        $.post('/ajax.php?action=task&type=up', {task_id: task_id}, function(result){
            showAlert(result['title'], result['error'], result['status']);
        }, 'json');
        return false;
    });

    $(document).on('click', '.details', function() {
        var task_id = $(this).attr('task_id');
        var detailsBlock = $('.details-' + task_id);
        detailsBlock.toggle();
    });

    $(document).on('click', '.check-progress', function() {
        var progress_id = $(this).attr('progress_id');
        var action = $(this).attr('action');
        var remake = '';

        if(action === 'remake'){
            var display = $('#form-remake-' + progress_id).css('display');
            if(display === 'none'){
                $('#form-remake-' + progress_id).show();
                $('#btn-remake-' + progress_id).html('Отправить');
                return false;
            } else {
                remake = $('#remake').val();
                if(remake === ''){
                    showAlert('Ошибка', 'Заполните поле "Замечание"', 'error');
                    return false;
                }
            }
        }

        $.post('/ajax.php?action=task&type=check', {
            progress_id: progress_id,
            action: action,
            remake: remake
        }, function(result){
            showAlert(result['title'], result['error'], result['status']);
            if(result['status'] === 'success'){
                $('#progress_' + progress_id).remove();
            }
        }, 'json');

        return false;
    });
});
