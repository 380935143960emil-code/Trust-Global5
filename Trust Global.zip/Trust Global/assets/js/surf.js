$(function() {
    function showAlert(result) {
        Swal.fire({
            title: result['title'] || 'Оповещение',
            text: result['error'] || '',
            icon: result['status'] || 'info',
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'ОК'
        });
    }

    function handleRedirect(result) {
        if (result['status'] === 'success' && result['redirect']) {
            setTimeout(function() {
                window.location.replace(result['redirect']);
            }, 1000);
        }
    }

    $('#surf_add').submit(function() {
        var url = '/ajax.php?action=surf&type=' + $("#type").val();
        var data = $(this).serialize() + '&ajax=1';

        $.post(url, data, function(result) {
            if (result['id']) {
                $('#' + result['id']).addClass('is-invalid');
            }
            showAlert(result);
            handleRedirect(result);
        }, 'json');

        return false;
    });

    $('.balance_add').submit(function() {
        var url = '/ajax.php?action=surf&type=' + $("#type").val();
        var balance = $('#balance').html();
        var data = $(this).serialize() + '&balance=' + balance + '&ajax=1';

        $.post(url, data, function(result) {
            if (result['id']) {
                $('#' + result['id']).addClass('is-invalid');
            }
            showAlert(result);
            handleRedirect(result);
        }, 'json');

        return false;
    });

    $('#surf_edit').submit(function() {
        var url = '/ajax.php?action=surf&type=' + $("#type").val();
        var data = $(this).serialize() + '&ajax=1';

        $.post(url, data, function(result) {
            if (result['id']) {
                $('#' + result['id']).addClass('is-invalid');
            }
            showAlert(result);
            handleRedirect(result);
        }, 'json');

        return false;
    });

    $(document).on('click', '.status_surf', function () {
        var button = $(this);
        var surf_id = button.attr('surf_id');
        var status = button.attr('action');
    
        $.post('/ajax.php?action=surf&type=status', { 'surf_id': surf_id, 'status': status }, function (result) {
            if (result['status'] === 'success') {
                if (status === '1') {
                    // меняем на паузу
                    button.attr('action', '2');
                    button.html('Остановить');
                    button
                        .removeClass('bg-blue-500 hover:bg-blue-600')
                        .addClass('bg-blue-600 hover:bg-blue-700');  
                } else if (status === '2') {
                    // меняем на старт
                    button.attr('action', '1');
                    button.html('Запустить');
                    button
                        .removeClass('bg-blue-500 hover:bg-blue-600')
                        .addClass('bg-blue-600 hover:bg-blue-700'); 
                }
            }
        }, 'json');
    
        return false;
    });



    $(document).on('click', '.delete', function() {
        var surf_id = $(this).attr('surf_id');

        $.post('/ajax.php?action=surf&type=delete', { 'surf_id': surf_id }, function(result) {
            showAlert(result);
            if (result['status'] === 'success') {
                $('#surf_' + surf_id).remove();
            }
        }, 'json');

        return false;
    });
});
