$(function() {
    // Обработчик для формы добавления видео
    $('#surf_add').submit(function() {
        var url = '/ajax.php?action=surfv&type=' + $("#type").val(); // URL для отправки запроса
        var data = $(this).serialize() + '&ajax=1'; // Серилизованные данные формы
        $.post(url, data, function(result) {
            if (result['id'] != '') {
                $('#' + result['id']).addClass('is-invalid');
            }

            // Использование Swal.fire для отображения уведомлений
            Swal.fire({
                title: result['title'],
                text: result['error'],
                icon: result['status'],
                timer: 2000,
                showConfirmButton: true
            });

            if (result['status'] == 'success') {
                if (result['redirect'] != '') {
                    setTimeout(function() {
                        window.location.replace(result['redirect']);
                    }, 1000);
                }
            }
        }, 'json');
        return false;
    });

    // Обработчик для формы пополнения баланса
    $('.balance_add').submit(function() {
        var url = '/ajax.php?action=surfv&type=' + $("#type").val();
        var balance = $('#balance').html();
        var data = $(this).serialize() + '&balance=' + balance + '&ajax=1';
        $.post(url, data, function(result) {
            if (result['id'] != '') {
                $('#' + result['id']).addClass('is-invalid');
            }

            // Использование Swal.fire для отображения уведомлений
            Swal.fire({
                title: result['title'],
                text: result['error'],
                icon: result['status'],
                timer: 2000,
                showConfirmButton: true
            });

            if (result['status'] == 'success') {
                if (result['redirect'] != '') {
                    setTimeout(function() {
                        window.location.replace(result['redirect']);
                    }, 1000);
                }
            }
        }, 'json');
        return false;
    });

    // Обработчик для формы редактирования видео
    $('#surf_edit').submit(function() {
        var url = '/ajax.php?action=surfv&type=' + $("#type").val();
        var data = $(this).serialize() + '&ajax=1';
        $.post(url, data, function(result) {
            if (result['id'] != '') {
                $('#' + result['id']).addClass('is-invalid');
            }

            // Использование Swal.fire для отображения уведомлений
            Swal.fire({
                title: result['title'],
                text: result['error'],
                icon: result['status'],
                timer: 2000,
                showConfirmButton: true
            });

            if (result['status'] == 'success') {
                if (result['redirect'] != '') {
                    setTimeout(function() {
                        window.location.replace(result['redirect']);
                    }, 1000);
                }
            }
        }, 'json');
        return false;
    });

// Обработчик для изменения статуса видео
$(document).on('click', '.status_surf', function() {
    var button = $(this);
    var surf_id = button.attr('surf_id');
    var status = button.attr('action');

    $.post('/ajax.php?action=surfv&type=status', { 'surf_id': surf_id, 'status': status }, function(result) {
        if (result['status'] == 'success') {
            if (status === '1') {
                button.attr('action', '2');
                button.html('<i class="bi bi-pause-fill"></i>'); // Меняем иконку на "пауза"
                button.removeClass('bg-green-500 hover:bg-green-600');
                button.addClass('bg-yellow-500 hover:bg-yellow-600'); // Изменяем цвета кнопки
            } else if (status === '2') {
                button.attr('action', '1');
                button.html('<i class="bi bi-play-fill"></i>'); // Меняем иконку на "играть"
                button.removeClass('bg-yellow-500 hover:bg-yellow-600');
                button.addClass('bg-green-500 hover:bg-green-600'); // Изменяем цвета кнопки
            }
        }
    }, 'json');
    return false;
});


    // Обработчик для удаления видео
    $(document).on('click', '.delete', function() {
        var surf_id = $(this).attr('surf_id');
        Swal.fire({
            title: 'Вы уверены?',
            text: "Вы хотите удалить это видео?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Да, удалить!'
        }).then((result) => {
            if (result.isConfirmed) {
                $.post('/ajax.php?action=surfv&type=delete', { 'surf_id': surf_id }, function(result) {
                    Swal.fire({
                        title: result['title'],
                        text: result['error'],
                        icon: result['status'],
                        timer: 2000,
                        showConfirmButton: true
                    });
                    if (result['status'] == 'success') {
                        $('#surf_' + surf_id).remove(); // Удаление элемента с ID
                    }
                }, 'json');
            }
        });
        return false;
    });
});
